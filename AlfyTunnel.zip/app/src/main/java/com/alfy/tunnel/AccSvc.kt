package com.alfy.tunnel

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Layanan aksesibilitas kosong: hanya dipakai agar overlay speedometer bisa tampil di atas panel notifikasi/pengaturan. */
class AccSvc : AccessibilityService() {
    companion object {
        @Volatile var inst: AccSvc? = null
    }

    override fun onServiceConnected() {
        inst = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }

    override fun onInterrupt() { }

    override fun onUnbind(intent: Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        inst = null
        super.onDestroy()
    }
}
