package com.alfy.tunnel

import android.net.TrafficStats
import android.os.Build
import android.os.SystemClock
import java.util.Locale

/**
 * Uji akurasi manual: tekan Mulai, unduh/unggah file yang ukurannya diketahui di aplikasi lain
 * (lalu lewat VPN), tekan Selesai. Hasilnya berupa log teks yang bisa disalin.
 */
object AccTest {
    private class S(
        val t: Long, val mrx: Long, val mtx: Long, val sn: NetSrc.Snap?, val trx: Long, val ttx: Long
    )

    private var b: S? = null

    private fun grab() = S(
        SystemClock.elapsedRealtime(), Mon.rx.get(), Mon.tx.get(), NetSrc.snap(),
        TrafficStats.getTotalRxBytes(), TrafficStats.getTotalTxBytes()
    )

    fun running() = b != null

    fun begin(): Boolean {
        if (Bus.status.value != St.CONNECTED) return false
        b = grab()
        return true
    }

    fun cancel() {
        b = null
    }

    private fun f(x: Long): String = String.format(Locale.US, "%d B (%s)", x, Usage.fmtBytes(x))

    private fun sp(x: Long, sec: Float): String =
        if (sec <= 0f) "-" else String.format(Locale.US, "%.1f KB/s", x / 1024f / sec)

    fun end(): String {
        val a = b ?: return "Belum dimulai."
        b = null
        val e = grab()
        val sec = (e.t - a.t) / 1000f
        val sb = StringBuilder()
        sb.append("UJI AKURASI ALFYTUNNEL\n")
        sb.append("Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append(String.format(Locale.US, "Durasi: %.1f detik\n\n", sec))
        val dr = e.mrx - a.mrx
        val dx = e.mtx - a.mtx
        sb.append("Hitungan TUN internal (sumber kecepatan, tanpa root)\n")
        sb.append("  unduh ${f(dr)}  rata-rata ${sp(dr, sec)}\n")
        sb.append("  unggah ${f(dx)}  rata-rata ${sp(dx, sec)}\n\n")
        val s0 = a.sn
        val s1 = e.sn
        if (s0 != null && s1 != null) {
            val kr = s1.rx - s0.rx
            val kx = s1.tx - s0.tx
            sb.append("Kernel tun (root, pembanding)\n")
            sb.append("  unduh ${f(kr)}  rata-rata ${sp(kr, sec)}\n")
            sb.append("  unggah ${f(kx)}  rata-rata ${sp(kx, sec)}\n")
            if (kr > 0) sb.append(String.format(Locale.US, "  selisih TUN internal vs kernel (unduh): %+.2f%%\n", (dr - kr) * 100.0 / kr))
            if (kx > 0) sb.append(String.format(Locale.US, "  selisih TUN internal vs kernel (unggah): %+.2f%%\n", (dx - kx) * 100.0 / kx))
            sb.append("\n")
            if (s1.phy) {
                val pr = s1.pRx - s0.pRx
                val px = s1.pTx - s0.pTx
                sb.append("Kernel fisik rmnet/wlan (root, dipakai pemakaian harian)\n")
                sb.append("  unduh ${f(pr)}\n")
                sb.append("  unggah ${f(px)}\n")
                if (kr > 0) sb.append(String.format(Locale.US, "  overhead tunnel unduh: %+.2f%% terhadap tun\n", (pr - kr) * 100.0 / kr))
                if (kx > 0) sb.append(String.format(Locale.US, "  overhead tunnel unggah: %+.2f%% terhadap tun\n", (px - kx) * 100.0 / kx))
                sb.append("\n")
            }
        } else {
            sb.append("Kernel (root): tidak tersedia (tanpa root / izin su ditolak)\n\n")
        }
        val tr = e.trx - a.trx
        val tt = e.ttx - a.ttx
        sb.append("TrafficStats total sistem (pembanding, bisa ganda saat VPN)\n")
        sb.append("  unduh ${f(tr)}\n")
        sb.append("  unggah ${f(tt)}\n\n")
        sb.append("Sumber meter saat uji: ${if (Prefs.noRoot.value) "TUN internal (dipaksa tanpa root)" else if (s1 != null) "kernel root" else "TUN internal (root tidak tersedia)"}\n")
        sb.append("Cara pakai: bandingkan angka di atas dengan ukuran file asli yang kamu unduh/unggah.")
        return sb.toString()
    }
}
