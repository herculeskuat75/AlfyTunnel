package com.alfy.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.widget.RemoteViews

/**
 * Notifikasi info (IP \u2022 dBm \u2022 Band) saat aplikasi DIBUKA tapi VPN belum terhubung.
 * Memakai ID & channel yang sama dengan notifikasi VpnSvc, jadi otomatis digantikan saat tunnel jalan.
 */
object AppNotif {
    private const val CH = "alfy_status"
    private const val NID = 1
    @Volatile var active = false
    private var last = ""

    fun reset() { last = "" }

    @Synchronized
    fun refresh(c: Context) {
        if (!active || Hud.svcOn || VpnSvc.inst != null) return
        try {
            val ctx = c.applicationContext
            val (d, w, m) = Usage.totals()
            val l1 = Mon.infoLine()
            val l3 = "Data hari ini: ${Usage.fmtBytes(d)}"
            val l4 = "Minggu ini: ${Usage.fmtBytes(w)} \u2022 Bulan ini: ${Usage.fmtBytes(m)}"
            val sig = "$l1|$l3|$l4"
            if (sig == last) return
            last = sig
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val b: Notification.Builder
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel(CH, "Status VPN", NotificationManager.IMPORTANCE_LOW))
                b = Notification.Builder(ctx, CH)
            } else b = Notification.Builder(ctx)
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            )
            val rs = RemoteViews(ctx.packageName, R.layout.notif_small)
            rs.setTextViewText(R.id.n_speed, "AlfyTunnel")
            rs.setTextViewText(R.id.n_info, l1)
            rs.setTextViewText(R.id.n_usage, l3)
            val n = b.setSmallIcon(R.drawable.ic_stat_reconnect)
                .setContentTitle("AlfyTunnel")
                .setContentText(l1)
                .setStyle(Notification.DecoratedCustomViewStyle())
                .setCustomContentView(rs)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .build()
            nm.notify(NID, n)
        } catch (e: Throwable) { }
    }

    fun cancel(c: Context) {
        active = false
        last = ""
        try { if (VpnSvc.inst == null) c.getSystemService(NotificationManager::class.java).cancel(NID) } catch (e: Throwable) { }
    }
}
