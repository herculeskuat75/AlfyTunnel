package com.alfy.tunnel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.View

/** Panah unduh (meluncur ke bawah) / unggah (meluncur ke atas). Animasi hanya jalan saat ada data. */
class ArrowView(c: Context, private val down: Boolean) : View(c) {
    var active = false
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }
    var color = Color.WHITE
        set(v) {
            field = v
            invalidate()
        }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val d = resources.displayMetrics.density
        setMeasuredDimension((12 * d).toInt(), (16 * d).toInt())
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = SystemClock.uptimeMillis() / 1000f
        val slide = Prefs.slideSp.value * 0.4f // siklus per detik
        val blink = Prefs.blinkSp.value * 0.8f // Hz
        var off = 0f
        var alpha = 255
        if (active) {
            if (slide > 0f) {
                val p = (t * slide) % 1f
                off = (p * 2f - 1f) * h * (if (down) 1f else -1f)
            }
            if (blink > 0f) alpha = if (((t * blink * 2f).toInt() and 1) == 0) 255 else 70
        }
        paint.color = color
        paint.alpha = alpha
        val cx = w / 2f
        val sw = w * 0.16f
        path.reset()
        if (down) {
            path.addRect(cx - sw, h * 0.08f, cx + sw, h * 0.55f, Path.Direction.CW)
            path.moveTo(w * 0.1f, h * 0.5f)
            path.lineTo(w * 0.9f, h * 0.5f)
            path.lineTo(cx, h * 0.95f)
        } else {
            path.addRect(cx - sw, h * 0.45f, cx + sw, h * 0.92f, Path.Direction.CW)
            path.moveTo(w * 0.1f, h * 0.5f)
            path.lineTo(w * 0.9f, h * 0.5f)
            path.lineTo(cx, h * 0.05f)
        }
        path.close()
        cv.save()
        cv.clipRect(0f, 0f, w, h)
        cv.translate(0f, off)
        cv.drawPath(path, paint)
        cv.restore()
        if (active && (slide > 0f || blink > 0f)) postInvalidateOnAnimation()
    }
}
