package com.alfy.tunnel

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.Executors

/**
 * HTTP Proxy lokal (non-root hotspot sharing). Mendengarkan di 0.0.0.0:PORT, mendukung
 * metode CONNECT (HTTPS) dan request HTTP biasa (GET/POST/dll. dengan URL absolut).
 * Semua koneksi diteruskan lewat TunnelLink.open() => channel direct-tcpip SSH.
 */
class HttpProxyServer(private val link: TunnelLink, private val port: Int = PORT) {
    companion object {
        const val PORT = 8080

        /** IPv4 lokal HP yang dilihat perangkat penerima (antarmuka hotspot diprioritaskan). */
        fun localIp(): String {
            var best: String? = null
            var bestScore = -1
            try {
                for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                    if (!ni.isUp || ni.isLoopback) continue
                    val n = ni.name.lowercase()
                    if (n.startsWith("tun") || n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("dummy")) continue
                    for (a in ni.inetAddresses.toList()) {
                        if (a !is Inet4Address || a.isLoopbackAddress) continue
                        val ip = a.hostAddress ?: continue
                        var sc = if (a.isSiteLocalAddress) 1 else 0
                        if (n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("rndis") || n.startsWith("wlan1")) sc += 10
                        if (ip.startsWith("192.168.43.") || ip.startsWith("192.168.42.") || ip.startsWith("192.168.49.")) sc += 5
                        if (sc > bestScore) { bestScore = sc; best = ip }
                    }
                }
            } catch (e: Exception) { }
            return best ?: "-"
        }
    }

    @Volatile private var running = false
    @Volatile private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "alfy-proxy").also { it.isDaemon = true } }
    private val clients = Collections.synchronizedSet(HashSet<Socket>())

    @Synchronized
    fun start() {
        if (running) return
        try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(InetAddress.getByName("0.0.0.0"), port), 128)
            server = ss
            running = true
            Thread {
                Bus.log("HTTP Proxy aktif di 0.0.0.0:$port")
                while (running) {
                    val c = try { ss.accept() } catch (e: Exception) { break }
                    clients.add(c)
                    pool.execute { handle(c) }
                }
            }.also { it.isDaemon = true; it.name = "alfy-proxy-accept" }.start()
        } catch (e: Exception) {
            running = false
            Bus.log("HTTP Proxy gagal start: ${e.message}")
        }
    }

    @Synchronized
    fun stop() {
        if (!running && server == null) return
        running = false
        try { server?.close() } catch (e: Exception) { }
        server = null
        synchronized(clients) { clients.toList() }.forEach { try { it.close() } catch (e: Exception) { } }
        clients.clear()
        try { pool.shutdownNow() } catch (e: Exception) { }
        Bus.log("HTTP Proxy dimatikan")
    }

    private fun readHead(i: InputStream): ByteArray? {
        val bo = ByteArrayOutputStream()
        var s = 0
        while (true) {
            val c = i.read()
            if (c < 0) return null
            bo.write(c)
            s = when {
                c == 13 && (s == 0 || s == 2) -> s + 1
                c == 10 && (s == 1 || s == 3) -> s + 1
                else -> 0
            }
            if (s == 4) return bo.toByteArray()
            if (bo.size() > 65536) return null
        }
    }

    private fun reply(o: OutputStream, line: String) {
        try {
            o.write("HTTP/1.1 $line\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
            o.flush()
        } catch (e: Exception) { }
    }

    private fun handle(c: Socket) {
        var ch: SshChan? = null
        try {
            c.tcpNoDelay = true
            c.soTimeout = 30000
            val ci = c.getInputStream()
            val co = c.getOutputStream()
            val head = readHead(ci) ?: return
            val txt = String(head, Charsets.ISO_8859_1)
            val lines = txt.split("\r\n")
            val rl = lines[0].split(" ")
            if (rl.size < 3) { reply(co, "400 Bad Request"); return }
            val method = rl[0].uppercase()
            val target = rl[1]
            val ver = rl[2]
            val host: String
            val prt: Int
            var fwd: ByteArray? = null
            if (method == "CONNECT") {
                val (h, p) = splitHp(target, 443)
                host = h; prt = p
            } else {
                val u = target.removePrefix("http://").let { if (it == target && target.startsWith("https://")) target.removePrefix("https://") else it }
                if (!target.startsWith("http://") && !target.startsWith("https://")) { reply(co, "400 Bad Request"); return }
                val slash = u.indexOf('/')
                val hp = if (slash >= 0) u.substring(0, slash) else u
                val path = if (slash >= 0) u.substring(slash) else "/"
                val (h, p) = splitHp(hp, if (target.startsWith("https://")) 443 else 80)
                host = h; prt = p
                val sb = StringBuilder("$method $path $ver\r\n")
                var hasHost = false
                for (k in 1 until lines.size) {
                    val l = lines[k]
                    if (l.isEmpty()) continue
                    val lk = l.lowercase()
                    if (lk.startsWith("proxy-connection:") || lk.startsWith("proxy-authorization:") || lk.startsWith("connection:") || lk.startsWith("keep-alive:")) continue
                    if (lk.startsWith("host:")) hasHost = true
                    sb.append(l).append("\r\n")
                }
                if (!hasHost) sb.append("Host: $hp\r\n")
                sb.append("Connection: close\r\n\r\n")
                fwd = sb.toString().toByteArray(Charsets.ISO_8859_1)
            }
            val k = try {
                link.open(host, prt).also { it.connect(10000) }
            } catch (e: Throwable) {
                reply(co, "502 Bad Gateway")
                return
            }
            ch = k
            c.soTimeout = 0
            if (method == "CONNECT") {
                co.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
                co.flush()
            } else {
                k.outputStream.write(fwd!!)
                k.outputStream.flush()
            }
            val chan = k
            val t = Thread { pipe(chan.inputStream, co, c, chan) }.also { it.isDaemon = true }
            t.start()
            pipe(ci, chan.outputStream, c, chan)
            t.join(2000)
        } catch (e: Throwable) {
        } finally {
            try { ch?.disconnect() } catch (e: Exception) { }
            try { c.close() } catch (e: Exception) { }
            clients.remove(c)
        }
    }

    private fun pipe(i: InputStream, o: OutputStream, c: Socket, ch: SshChan) {
        val buf = ByteArray(16384)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (e: IOException) {
        } catch (e: Exception) {
        } finally {
            try { ch.disconnect() } catch (e: Exception) { }
            try { c.close() } catch (e: Exception) { }
        }
    }

    private fun splitHp(s: String, def: Int): Pair<String, Int> {
        if (s.startsWith("[")) {
            val e = s.indexOf(']')
            if (e > 0) return s.substring(1, e) to (s.substring(e + 1).removePrefix(":").toIntOrNull() ?: def)
        }
        val i = s.lastIndexOf(':')
        return if (i > 0) s.substring(0, i) to (s.substring(i + 1).toIntOrNull() ?: def) else s to def
    }
}
