package com.alfy.tunnel

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

fun rainbowText(s: String, speed: Float, nowMs: Long, hide: IntArray = IntArray(0), base: Int = 0): CharSequence {
    val sp = SpannableString(s)
    val off = Rb.offset(nowMs / 1000f, speed)
    val hsv = FloatArray(3)
    hsv[1] = 0.7f
    hsv[2] = 1f
    for (i in s.indices) {
        if (s[i] == ' ') continue
        hsv[0] = ((off + (i + base) * 16f) % 360f + 360f) % 360f
        val col = if (hide.contains(i)) Color.TRANSPARENT else Color.HSVToColor(hsv)
        sp.setSpan(ForegroundColorSpan(col), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    return sp
}

/**
 * Satu "jam" di sisi service: sampling byte TUN tiap 250 ms + EMA, speedometer mengambang, update notifikasi.
 * Tanpa thread tambahan; semua di Handler main dan hanya berjalan saat tunnel aktif.
 */
class Hud(private val svc: VpnSvc) {
    companion object {
        const val IV = 250L
        const val ALPHA = 0.5f
    }

    private val h = Handler(Looper.getMainLooper())
    private var on = false
    private var lastT = 0L
    private var lastR = 0L
    private var lastX = 0L
    private var n = 0
    private var dbgN = 0
    private var accR = 0L
    private var accX = 0L
    private var accT = 0L
    private var srcRoot = false
    private var phyOn = false
    private var lastPR = 0L
    private var lastPX = 0L
    private var view: LinearLayout? = null
    private var tvDl: TextView? = null
    private var tvUl: TextView? = null
    private var tvDbm: TextView? = null
    private var avD: ArrowView? = null
    private var avU: ArrowView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var viaAcc = false

    private val run = object : Runnable {
        override fun run() {
            if (!on) return
            try { tick() } catch (e: Throwable) { }
            h.postDelayed(this, IV)
        }
    }

    fun start() {
        if (on) return
        on = true
        Mon.resetSpeed()
        lastT = SystemClock.elapsedRealtime()
        lastR = 0
        lastX = 0
        n = 0
        dbgN = 0
        Usage.prune()
        srcRoot = false
        phyOn = false
        NetSrc.start()
        Mon.dbmUse(svc, true)
        h.postDelayed(run, IV)
    }

    fun stop() {
        if (!on) return
        on = false
        h.removeCallbacks(run)
        Usage.flush()
        h.post { removeOverlay() }
        Mon.dbmUse(svc, false)
        NetSrc.stop()
        Mon.resetSpeed()
    }

    private fun tick() {
        val now0 = SystemClock.elapsedRealtime()
        // Sumber paling akurat: kernel /proc/net/dev (root) dengan cap waktu sampel sendiri; cadangan: hitungan TUN internal
        val sn = if (Prefs.noRoot.value) null else NetSrc.snap()?.takeIf { now0 - it.t < 1500 }
        val useRoot = false
        if (useRoot != srcRoot) {
            srcRoot = useRoot
            lastR = Mon.rx.get()
            lastX = Mon.tx.get()
            lastT = now0
        }
        val now = now0
        val dt = now - lastT
        if (dt >= 100) {
            val r = Mon.rx.get()
            val x = Mon.tx.get()
            val dr = r - lastR
            val dx = x - lastX
            val iD = dr * 1000f / dt
            val iU = dx * 1000f / dt
            var d = Mon.dl.value + ALPHA * (iD - Mon.dl.value)
            var u = Mon.ul.value + ALPHA * (iU - Mon.ul.value)
            if (d < 20f && iD == 0f) d = 0f
            if (u < 20f && iU == 0f) u = 0f
            Mon.dl.value = d
            Mon.ul.value = u
            Mon.push(d, u)
            lastT = now
            lastR = r
            lastX = x
            // pemakaian harian: byte fisik (rmnet/wlan) bila root tersedia, jika tidak byte tun
            val usePhy = sn != null && sn.phy
            if (usePhy != phyOn) {
                phyOn = usePhy
                lastPR = sn?.pRx ?: 0L
                lastPX = sn?.pTx ?: 0L
            }
            if (usePhy && sn != null) {
                Usage.add((sn.pRx - lastPR) + (sn.pTx - lastPX))
                lastPR = sn.pRx
                lastPX = sn.pTx
            } else {
                Usage.add(dr + dx)
            }
            accR += dr
            accX += dx
            accT += dt
            if (Prefs.dbg.value && ++dbgN % 20 == 0) {
                Bus.log("dbg speed iv=${accT / 20}ms rx=${accR}B tx=${accX}B dl=${Mon.fmt(d)} ul=${Mon.fmt(u)}")
                accR = 0; accX = 0; accT = 0
            }
        }
        val wall = System.currentTimeMillis()
        // overlay: panah dianimasikan sendiri oleh ArrowView (kedip + meluncur) saat ada data
        if (Prefs.floatOn.value && canOverlay()) {
            if (view != null && viaAcc != (AccSvc.inst != null)) removeOverlay()
            ensureOverlay()
            val sp = Prefs.speedFor(Prefs.P_FLOAT)
            val dTxt = Mon.fmt(Mon.dl.value)
            val ut = Mon.fmt(Mon.ul.value)
            val ub = 2 + dTxt.length + 4
            tvDl?.text = rainbowText(dTxt, sp, wall, IntArray(0), 2)
            tvUl?.text = rainbowText(ut, sp, wall, IntArray(0), ub + 2)
            tvDbm?.text = rainbowText("  " + Mon.dbmText(Mon.dbm.value), sp, wall, IntArray(0), ub + 2 + ut.length)
            avD?.color = hueColor(sp, wall, 0)
            avU?.color = hueColor(sp, wall, ub)
            avD?.active = Mon.dl.value > 0f
            avU?.active = Mon.ul.value > 0f
        } else if (view != null) {
            removeOverlay()
        }
        // notifikasi dibuat diam: hanya diperbarui tiap 30 detik dan hanya jika isinya berubah
        if (n % 120 == 0) {
            Usage.flush()
            svc.refreshNotif()
        }
        n++
    }

    private fun canOverlay() = AccSvc.inst != null || Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(svc)

    private fun hueColor(sp: Float, nowMs: Long, idx: Int): Int {
        val hsv = floatArrayOf(((Rb.offset(nowMs / 1000f, sp) + idx * 16f) % 360f + 360f) % 360f, 0.7f, 1f)
        return Color.HSVToColor(hsv)
    }

    private fun ensureOverlay() {
        if (view != null) return
        val dn = svc.resources.displayMetrics.density
        val tv = LinearLayout(svc)
        tv.orientation = LinearLayout.HORIZONTAL
        tv.gravity = Gravity.CENTER_VERTICAL
        tv.setPadding(24, 12, 24, 12)
        tv.background = GradientDrawable().apply {
            setColor(0xAA000000.toInt())
            cornerRadius = 40f
        }
        fun mk(padL: Int) = TextView(svc).also {
            it.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            it.setTypeface(it.typeface, android.graphics.Typeface.BOLD)
            it.setPadding((padL * dn).toInt(), 0, 0, 0)
        }
        val ad = ArrowView(svc, true)
        val au = ArrowView(svc, false)
        val td = mk(3)
        val tu = mk(3)
        val tb = mk(0)
        tv.addView(ad)
        tv.addView(td)
        tv.addView(LinearLayout(svc), LinearLayout.LayoutParams((10 * dn).toInt(), 1))
        tv.addView(au)
        tv.addView(tu)
        tv.addView(tb)
        tvDl = td; tvUl = tu; tvDbm = tb; avD = ad; avU = au
        val acc = AccSvc.inst
        viaAcc = acc != null
        wm = (acc ?: svc).getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = if (acc != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = Prefs.getInt("ox", 40)
        p.y = Prefs.getInt("oy", 200)
        var sx = 0f
        var sy = 0f
        var px = 0
        var py = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; px = p.x; py = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val dm = svc.resources.displayMetrics
                    p.x = (px + (e.rawX - sx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - tv.width))
                    p.y = (py + (e.rawY - sy).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - tv.height))
                    try { wm.updateViewLayout(tv, p) } catch (x: Exception) { }
                }
                MotionEvent.ACTION_UP -> {
                    Prefs.putInt("ox", p.x)
                    Prefs.putInt("oy", p.y)
                }
            }
            true
        }
        try {
            wm.addView(tv, p)
            view = tv
            lp = p
        } catch (e: Exception) {
            Bus.log("Overlay gagal: ${e.message}")
            Prefs.setFloat(false)
        }
    }

    private fun removeOverlay() {
        view?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        view = null
        tvDl = null; tvUl = null; tvDbm = null; avD = null; avU = null
        lp = null
    }
}
