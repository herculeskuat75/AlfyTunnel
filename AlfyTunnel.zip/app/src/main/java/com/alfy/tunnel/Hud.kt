package com.alfy.tunnel

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

fun rainbowText(s: String, speed: Float, nowMs: Long): CharSequence {
    val sp = SpannableString(s)
    val off = Rb.offset(nowMs / 1000f, speed)
    val hsv = FloatArray(3)
    hsv[1] = 0.7f
    hsv[2] = 1f
    for (i in s.indices) {
        if (s[i] == ' ') continue
        hsv[0] = ((off + i * 16f) % 360f + 360f) % 360f
        sp.setSpan(ForegroundColorSpan(Color.HSVToColor(hsv)), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    return sp
}

/**
 * Satu "jam" di sisi service: sampling byte TUN tiap 250 ms + EMA, speedometer mengambang, update notifikasi.
 * Tanpa thread tambahan; semua di Handler main dan hanya berjalan saat tunnel aktif.
 */
class Hud(private val svc: VpnSvc) {
    companion object {
        const val IV = 250L
        const val ALPHA = 0.5f
    }

    private val h = Handler(Looper.getMainLooper())
    private var on = false
    private var lastT = 0L
    private var lastR = 0L
    private var lastX = 0L
    private var n = 0
    private var dbgN = 0
    private var accR = 0L
    private var accX = 0L
    private var accT = 0L
    private var view: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val run = object : Runnable {
        override fun run() {
            if (!on) return
            try { tick() } catch (e: Throwable) { }
            h.postDelayed(this, IV)
        }
    }

    fun start() {
        if (on) return
        on = true
        Mon.resetSpeed()
        lastT = SystemClock.elapsedRealtime()
        lastR = 0
        lastX = 0
        n = 0
        dbgN = 0
        Usage.prune()
        Mon.dbmUse(svc, true)
        h.postDelayed(run, IV)
    }

    fun stop() {
        if (!on) return
        on = false
        h.removeCallbacks(run)
        Usage.flush()
        h.post { removeOverlay() }
        Mon.dbmUse(svc, false)
        Mon.resetSpeed()
    }

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val dt = now - lastT
        if (dt >= 100) {
            val r = Mon.rx.get()
            val x = Mon.tx.get()
            val dr = r - lastR
            val dx = x - lastX
            val iD = dr * 1000f / dt
            val iU = dx * 1000f / dt
            var d = Mon.dl.value + ALPHA * (iD - Mon.dl.value)
            var u = Mon.ul.value + ALPHA * (iU - Mon.ul.value)
            if (d < 20f && iD == 0f) d = 0f
            if (u < 20f && iU == 0f) u = 0f
            Mon.dl.value = d
            Mon.ul.value = u
            Mon.push(d, u)
            lastT = now
            lastR = r
            lastX = x
            Usage.add(dr + dx)
            accR += dr
            accX += dx
            accT += dt
            if (Prefs.dbg.value && ++dbgN % 20 == 0) {
                Bus.log("dbg speed iv=${accT / 20}ms rx=${accR}B tx=${accX}B dl=${Mon.fmt(d)} ul=${Mon.fmt(u)}")
                accR = 0; accX = 0; accT = 0
            }
        }
        val txt = "↓ ${Mon.fmt(Mon.dl.value)}  ↑ ${Mon.fmt(Mon.ul.value)}"
        val wall = System.currentTimeMillis()
        // overlay
        if (Prefs.floatOn.value && canOverlay()) {
            ensureOverlay()
            view?.text = rainbowText(txt + "  " + Mon.dbmText(Mon.dbm.value), Prefs.speedFor(Prefs.P_FLOAT), wall)
        } else if (view != null) {
            removeOverlay()
        }
        // notifikasi: 2x/detik jika pelangi bergerak, selain itu 1x/detik
        val every = if (Prefs.speedFor(Prefs.P_NOTIF) > 0f) 2 else 4
        if (n % every == 0 || n == 0) {
            if (n % 20 == 0) Usage.flush()
            val sp = Prefs.speedFor(Prefs.P_NOTIF)
            val us = Usage.text()
            svc.pushSpeed(
                rainbowText(txt, sp, wall), Mon.dbmText(Mon.dbm.value), us,
                Prefs.allOn.value, sp, wall
            )
        }
        n++
    }

    private fun canOverlay() = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(svc)

    private fun ensureOverlay() {
        if (view != null) return
        val tv = TextView(svc)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
        tv.setPadding(24, 12, 24, 12)
        tv.background = GradientDrawable().apply {
            setColor(0xAA000000.toInt())
            cornerRadius = 40f
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = Prefs.getInt("ox", 40)
        p.y = Prefs.getInt("oy", 200)
        var sx = 0f
        var sy = 0f
        var px = 0
        var py = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; px = p.x; py = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = px + (e.rawX - sx).toInt()
                    p.y = py + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(tv, p) } catch (x: Exception) { }
                }
                MotionEvent.ACTION_UP -> {
                    Prefs.putInt("ox", p.x)
                    Prefs.putInt("oy", p.y)
                }
            }
            true
        }
        try {
            wm.addView(tv, p)
            view = tv
            lp = p
        } catch (e: Exception) {
            Bus.log("Overlay gagal: ${e.message}")
            Prefs.setFloat(false)
        }
    }

    private fun removeOverlay() {
        view?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        view = null
        lp = null
    }
}
