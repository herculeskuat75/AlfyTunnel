package com.alfy.tunnel

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

fun rainbowText(s: String, speed: Float, nowMs: Long, hide: IntArray = IntArray(0), base: Int = 0): CharSequence {
    val sp = SpannableString(s)
    val off = Rb.offset((nowMs % 3600000L) / 1000f, speed)
    val hsv = FloatArray(3)
    hsv[1] = 0.7f
    hsv[2] = 1f
    for (i in s.indices) {
        if (s[i] == ' ') continue
        hsv[0] = ((off + (i + base) * 16f) % 360f + 360f) % 360f
        val col = if (hide.contains(i)) Color.TRANSPARENT else Color.HSVToColor(hsv)
        sp.setSpan(ForegroundColorSpan(col), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    return sp
}

/**
 * Satu "jam" di sisi service: sampling byte TUN tiap 250 ms + EMA, speedometer mengambang, update notifikasi.
 * Tanpa thread tambahan; semua di Handler main dan hanya berjalan saat tunnel aktif.
 */
class Hud(private val ctx: Context, private val svc: VpnSvc? = null) {
    companion object {
        var staleView: android.view.View? = null
        var staleWm: WindowManager? = null
        @Volatile var actHud: Hud? = null
        @Volatile var resumed = false
        @Volatile var svcOn = false
        const val IV = 250L
        const val ALPHA = 0.5f
    }

    private val h = Handler(Looper.getMainLooper())
    private var on = false
    private var lastT = 0L
    private var lastR = 0L
    private var lastX = 0L
    private var n = 0
    private var dbgN = 0
    private var accR = 0L
    private var accX = 0L
    private var accT = 0L
    private var srcRoot = false
    private var phyOn = false
    private var lastPR = 0L
    private var lastPX = 0L
    private var view: LinearLayout? = null
    private var tvDl: TextView? = null
    private var tvUl: TextView? = null
    private var tvData: TextView? = null
    private var avD: ArrowView? = null
    private var avU: ArrowView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var viaAcc = false
    // Nilai kecepatan khusus tampilan HUD (diperhalus); Mon.dl/Mon.ul tetap apa adanya untuk grafik & bagian lain
    private var dispD = 0f
    private var dispU = 0f
    private var dispT = 0L

    private val run = object : Runnable {
        override fun run() {
            if (!on) return
            try { tick() } catch (e: Throwable) { }
            h.postDelayed(this, IV)
        }
    }

    fun start() {
        if (on) return
        on = true
        if (svc != null) { svcOn = true; actHud?.stop() } else AppNotif.reset()
        Mon.resetSpeed()
        dispD = 0f
        dispU = 0f
        dispT = 0L
        lastT = SystemClock.elapsedRealtime()
        lastR = 0
        lastX = 0
        n = 0
        dbgN = 0
        Usage.prune()
        srcRoot = false
        phyOn = false
        NetSrc.start()
        Mon.dbmUse(ctx, true)
        h.postDelayed(run, IV)
    }

    fun stop() {
        if (!on) return
        on = false
        h.removeCallbacks(run)
        Usage.flush()
        h.post { removeOverlay() }
        Mon.dbmUse(ctx, false)
        NetSrc.stop()
        Mon.resetSpeed()
        if (svc != null) { svcOn = false; if (resumed) h.postDelayed({ if (resumed && !svcOn) actHud?.start() }, 400) }
    }

    private fun tick() {
        val now0 = SystemClock.elapsedRealtime()
        // Sumber paling akurat: kernel /proc/net/dev (root) dengan cap waktu sampel sendiri; cadangan: hitungan TUN internal
        val sn = if (Prefs.noRoot.value) null else NetSrc.snap()?.takeIf { now0 - it.t < 1500 }
        val useRoot = false
        if (useRoot != srcRoot) {
            srcRoot = useRoot
            lastR = Mon.rx.get()
            lastX = Mon.tx.get()
            lastT = now0
        }
        val now = now0
        val dt = now - lastT
        if (dt >= 100) {
            val r = Mon.rx.get()
            val x = Mon.tx.get()
            val dr = r - lastR
            val dx = x - lastX
            val iD = dr * 1000f / dt
            val iU = dx * 1000f / dt
            var d = Mon.dl.value + ALPHA * (iD - Mon.dl.value)
            var u = Mon.ul.value + ALPHA * (iU - Mon.ul.value)
            if (d < 20f && iD == 0f) d = 0f
            if (u < 20f && iU == 0f) u = 0f
            Mon.dl.value = d
            Mon.ul.value = u
            Mon.push(d, u)
            lastT = now
            lastR = r
            lastX = x
            // pemakaian harian: byte fisik (rmnet/wlan) bila root tersedia, jika tidak byte tun
            val usePhy = sn != null && sn.phy
            if (usePhy != phyOn) {
                phyOn = usePhy
                lastPR = sn?.pRx ?: 0L
                lastPX = sn?.pTx ?: 0L
            }
            if (usePhy && sn != null) {
                Usage.add((sn.pRx - lastPR) + (sn.pTx - lastPX))
                lastPR = sn.pRx
                lastPX = sn.pTx
            } else {
                Usage.add(dr + dx)
            }
            accR += dr
            accX += dx
            accT += dt
        }
        val wall = System.currentTimeMillis()
        // overlay: panah dianimasikan sendiri oleh ArrowView (kedip + meluncur) saat ada data
        if (Prefs.floatOn.value && canOverlay()) {
            if (view != null && viaAcc != (AccSvc.inst != null)) removeOverlay()
            ensureOverlay()
            val sp = Prefs.speedFor(Prefs.P_FLOAT)
            smoothDisp(now0)
            val dTxt = fmtHud(dispD)
            val ut = fmtHud(dispU)
            val db = ut.length + 4
            tvUl?.text = rainbowText(ut, sp, wall, IntArray(0), 0)
            tvDl?.text = rainbowText(dTxt, sp, wall, IntArray(0), db)
            tvData?.text = rainbowText(Mon.dataText(Usage.totals().first), sp, wall, IntArray(0), db + dTxt.length + 4)
            avU?.color = hueColor(sp, wall, 0)
            avD?.color = hueColor(sp, wall, db)
            avD?.active = dispD > 0f
            avU?.active = dispU > 0f
        } else if (view != null) {
            removeOverlay()
        }
        // notifikasi dibuat diam: hanya diperbarui tiap 30 detik dan hanya jika isinya berubah
        if (n % 120 == 0) Usage.flush()
        if (n % (if (Prefs.notifAnim()) 2 else 20) == 0) svc?.refreshNotif()
        if (svc == null && n % 8 == 0) AppNotif.refresh(ctx)
        n++
    }

    /** Haluskan kecepatan untuk HUD: naik cukup cepat, turun lebih pelan, sehingga angka tidak loncat-loncat. */
    private fun smoothDisp(nowMs: Long) {
        val dtMs = if (dispT == 0L) IV else (nowMs - dispT).coerceIn(1L, 2000L)
        dispT = nowMs
        dispD = ease(dispD, Mon.dl.value, dtMs)
        dispU = ease(dispU, Mon.ul.value, dtMs)
    }

    private fun ease(cur: Float, target: Float, dtMs: Long): Float {
        val tau = (if (target > cur) Prefs.hudRise.value else Prefs.hudFall.value).toFloat()
        if (tau <= 0f) return target
        val a = 1f - Math.exp(-dtMs / tau.toDouble()).toFloat()
        val v = cur + a * (target - cur)
        return if (target == 0f && v < 1024f) 0f else v
    }

    /** Format HUD: di bawah 1 MB/s dalam KB/s bulat, mulai 1 MB/s memakai 1 desimal (mis. 1.2 MB/s). */
    private fun fmtHud(bps: Float): String =
        if (bps < 1048576f) "${(bps / 1024f).toLong()} KB/s"
        else String.format(java.util.Locale.US, "%.1f MB/s", bps / 1048576f)

    private fun canOverlay() = AccSvc.inst != null || Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    private fun hueColor(sp: Float, nowMs: Long, idx: Int): Int {
        val hsv = floatArrayOf(((Rb.offset((nowMs % 3600000L) / 1000f, sp) + idx * 16f) % 360f + 360f) % 360f, 0.7f, 1f)
        return Color.HSVToColor(hsv)
    }

    private fun ensureOverlay() {
        if (view != null) return
        val dn = ctx.resources.displayMetrics.density
        val tv = LinearLayout(ctx)
        tv.orientation = LinearLayout.HORIZONTAL
        tv.gravity = Gravity.CENTER_VERTICAL
        tv.setPadding(24, 12, 24, 12)
        tv.background = GradientDrawable().apply {
            setColor(0xAA000000.toInt())
            cornerRadius = 40f
        }
        fun mk(padL: Int, col: Int, sz: Float) = TextView(ctx).also {
            it.setTextSize(TypedValue.COMPLEX_UNIT_SP, sz)
            it.setTypeface(it.typeface, android.graphics.Typeface.BOLD)
            it.setTextColor(col)
            it.setSingleLine(true)
            it.setPadding((padL * dn).toInt(), 0, 0, 0)
        }
        val r2 = LinearLayout(ctx)
        r2.orientation = LinearLayout.HORIZONTAL
        r2.gravity = Gravity.CENTER_VERTICAL
        val ad = ArrowView(ctx, true)
        val au = ArrowView(ctx, false)
        val td = mk(0, Color.WHITE, 13f)
        val tu = mk(0, Color.WHITE, 13f)
        val tdata = mk(0, Color.WHITE, 12f)
        val gap = (4 * dn).toInt()
        val sep = (10 * dn).toInt()
        // [panah upload][teks upload] [panah download][teks download] [Data: XX MB]; panah di KIRI teksnya
        r2.addView(au)
        r2.addView(tu.also { it.setPadding(gap, 0, 0, 0) })
        r2.addView(LinearLayout(ctx), LinearLayout.LayoutParams(sep, 1))
        r2.addView(ad)
        r2.addView(td.also { it.setPadding(gap, 0, 0, 0) })
        r2.addView(LinearLayout(ctx), LinearLayout.LayoutParams(sep, 1))
        r2.addView(tdata)
        tv.addView(r2)
        tvDl = td; tvUl = tu; tvData = tdata; avD = ad; avU = au
        val acc = AccSvc.inst
        viaAcc = acc != null
        wm = (acc ?: ctx).getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = if (acc != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = Prefs.getInt("ox", 40)
        p.y = Prefs.getInt("oy", 200)
        var sx = 0f
        var sy = 0f
        var px = 0
        var py = 0
        var pend = false
        val dm0 = ctx.resources.displayMetrics
        val frame = android.view.Choreographer.FrameCallback {
            pend = false
            try { wm.updateViewLayout(tv, p) } catch (x: Exception) { }
        }
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; px = p.x; py = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (px + (e.rawX - sx).toInt()).coerceIn(0, maxOf(0, dm0.widthPixels - tv.width))
                    p.y = (py + (e.rawY - sy).toInt()).coerceIn(0, maxOf(0, dm0.heightPixels - tv.height))
                    if (!pend) {
                        pend = true
                        android.view.Choreographer.getInstance().postFrameCallback(frame)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (pend) {
                        android.view.Choreographer.getInstance().removeFrameCallback(frame)
                        pend = false
                    }
                    try { wm.updateViewLayout(tv, p) } catch (x: Exception) { }
                    Prefs.putInt("ox", p.x)
                    Prefs.putInt("oy", p.y)
                }
            }
            true
        }
        try { staleView?.let { staleWm?.removeView(it) } } catch (e: Exception) { }
        staleView = null
        try {
            wm.addView(tv, p)
            staleView = tv
            staleWm = wm
            view = tv
            lp = p
        } catch (e: Exception) {
            Bus.log("Overlay gagal: ${e.message}")
            Prefs.setFloat(false)
        }
    }

    private fun removeOverlay() {
        view?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        if (staleView === view) { staleView = null; staleWm = null }
        view = null
        tvDl = null; tvUl = null; tvData = null; avD = null; avU = null
        lp = null
    }
}
