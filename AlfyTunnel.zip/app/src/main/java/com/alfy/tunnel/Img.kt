package com.alfy.tunnel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import kotlin.math.max
import kotlin.math.min

object Img {
    fun bgFile(c: Context) = File(c.filesDir, "bg.jpg")

    fun decode(c: Context, uri: Uri, maxDim: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        if (o.outWidth <= 0) return null
        var s = 1
        while (max(o.outWidth, o.outHeight) / (s * 2) >= maxDim) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.RGB_565 }
        val b = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        val k = maxDim.toFloat() / max(b.width, b.height)
        if (k >= 1f) return b
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
    }

    fun saveBg(c: Context, uri: Uri): Boolean {
        val b = decode(c, uri, 960) ?: return false
        bgFile(c).outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        Prefs.bgVer.value = Prefs.bgVer.value + 1
        return true
    }

    fun clearBg(c: Context) {
        bgFile(c).delete()
        Prefs.bgVer.value = Prefs.bgVer.value + 1
    }

    fun square(c: Context, uri: Uri, size: Int): Bitmap? {
        val b = decode(c, uri, size * 2) ?: return null
        val m = min(b.width, b.height)
        val sq = Bitmap.createBitmap(b, (b.width - m) / 2, (b.height - m) / 2, m, m)
        return Bitmap.createScaledBitmap(sq, size, size, true)
    }
}
