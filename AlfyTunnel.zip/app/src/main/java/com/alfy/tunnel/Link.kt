package com.alfy.tunnel

/**
 * Kontrak transport yang dipakai TunStack & VpnSvc.
 * SshLink (jalur SSH standar) dan SlowDnsLink (jalur DNS tunnel) sama-sama mengimplementasikan ini
 * sehingga logika TCP/IP stack di TunStack.kt tidak perlu tahu/berubah soal transport apa yang dipakai.
 */
interface TunnelLink {
    val alive: Boolean
    fun connect()
    fun close()
    fun open(host: String, port: Int): SshChan
}
