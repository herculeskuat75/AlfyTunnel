package com.alfy.tunnel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class MainVM(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    val configs = MutableStateFlow<List<Config>>(emptyList())
    val cur = MutableStateFlow(Config(name = "Config 1"))
    private val ipRe = Regex("""^(\d{1,3}\.){3}\d{1,3}$""")

    init {
        viewModelScope.launch {
            val saved = store.configs.first()
            val id = store.current.first()
            val list = saved.ifEmpty { listOf(Config(name = "Config 1")) }
            configs.value = list
            cur.value = list.firstOrNull { it.id == id } ?: list[0]
            if (saved.isEmpty()) persist()
        }
    }

    private fun persist() {
        viewModelScope.launch {
            store.saveAll(configs.value)
            store.setCurrent(cur.value.id)
        }
    }

    fun edit(f: (Config) -> Config) {
        val n = f(cur.value)
        cur.value = n
        configs.value = configs.value.map { if (it.id == n.id) n else it }
        persist()
    }

    fun select(id: String) {
        configs.value.firstOrNull { it.id == id }?.let {
            cur.value = it
            persist()
        }
    }

    fun add() {
        val n = Config(name = "Config ${configs.value.size + 1}")
        configs.value = configs.value + n
        cur.value = n
        persist()
    }

    fun rename(id: String, name: String, tag: String = "") {
        configs.value = configs.value.map { if (it.id == id) it.copy(name = name, customTag = tag) else it }
        if (cur.value.id == id) cur.value = cur.value.copy(name = name, customTag = tag)
        persist()
    }

    fun togglePin(id: String) {
        configs.value = configs.value.map { if (it.id == id) it.copy(isPinned = !it.isPinned) else it }
        configs.value.firstOrNull { it.id == cur.value.id }?.let { cur.value = it }
        persist()
    }

    fun duplicate(id: String, newName: String) {
        val l = configs.value
        val i = l.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = l[i].copy(id = UUID.randomUUID().toString(), name = newName, isPinned = false)
        configs.value = l.subList(0, i + 1) + c + l.subList(i + 1, l.size)
        persist()
    }

    fun reorder(ids: List<String>) {
        val m = configs.value.associateBy { it.id }
        val n = ids.mapNotNull { m[it] }
        if (n.size != configs.value.size) return
        configs.value = n
        persist()
    }

    fun delete(id: String) {
        var l = configs.value.filter { it.id != id }
        if (l.isEmpty()) l = listOf(Config(name = "Config 1"))
        configs.value = l
        if (cur.value.id == id) cur.value = l[0]
        persist()
    }

    fun validate(c: Config): String? {
        if (Srv.parse(c.server) == null) return "Format server: host:port@user:password"
        if (c.proxy.isNotBlank() && parseHp(c.proxy) == null) return "Format proxy: host:port"
        if (c.useSlowDns) {
            if (c.dnsNs.isBlank()) return "SlowDNS: NS Name wajib diisi"
            if (c.dnsPubKey.isBlank()) return "SlowDNS: Public Key wajib diisi"
        }
        if (c.dnsOn) {
            if (!ipRe.matches(c.dns1.trim())) return "DNS primary harus alamat IPv4"
            if (c.dns2.isNotBlank() && !ipRe.matches(c.dns2.trim())) return "DNS secondary harus alamat IPv4"
        }
        return null
    }

    fun backupText(): String = JSONObject()
        .put("app", "AlfyTunnel").put("version", 1)
        .put("configs", JSONArray(configs.value.map { it.toJson() }))
        .toString(2)

    fun parseBackup(t: String): Result<List<Config>> = runCatching {
        val o = JSONObject(t.trim())
        require(o.optString("app") == "AlfyTunnel") { "Bukan berkas backup AlfyTunnel" }
        val a = o.getJSONArray("configs")
        require(a.length() > 0) { "Backup kosong" }
        (0 until a.length()).map { Config.fromJson(a.getJSONObject(it)) }
    }

    fun conflicts(l: List<Config>): Int = l.count { n -> configs.value.any { it.id == n.id } }

    fun importConfigs(l: List<Config>, overwrite: Boolean) {
        val res = configs.value.toMutableList()
        for (n in l) {
            val i = res.indexOfFirst { it.id == n.id }
            when {
                i < 0 -> res.add(n)
                overwrite -> res[i] = n
                else -> res.add(n.copy(id = UUID.randomUUID().toString()))
            }
        }
        configs.value = res
        cur.value = res.first { it.id == cur.value.id }
        persist()
    }
}
