package com.alfy.tunnel

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/** Pengaturan UI sederhana (SharedPreferences), dipakai Activity dan Service. */
object Prefs {
    const val P_NOTIF = 0
    const val P_FLOAT = 1
    const val P_GRAPH = 2
    const val P_HOST = 3

    private var sp: SharedPreferences? = null
    val rb = List(4) { MutableStateFlow(3f) }
    val floatOn = MutableStateFlow(false)
    val dbg = MutableStateFlow(false)
    val bgVer = MutableStateFlow(0)
    val resume = MutableStateFlow(0)
    val allOn = MutableStateFlow(false)
    val allSpeed = MutableStateFlow(3f)
    val divOn = MutableStateFlow(true)
    val divSpeed = MutableStateFlow(3f)
    val hostLabel = MutableStateFlow("")
    val noRoot = MutableStateFlow(false)
    var use4GLabel = MutableStateFlow(false)
    val slideSp = MutableStateFlow(3f)
    val notifOn = MutableStateFlow(true)
    val notifSpeed = MutableStateFlow(3f)
    val blinkSp = MutableStateFlow(3f)
    val udpgwPort = MutableStateFlow(0) // 0 = Unduh/Download (koneksi SSH utama)
    val hotspot = MutableStateFlow(false)
    val transparent = MutableStateFlow(true)
    val useCompression = MutableStateFlow(false)
    val alwaysReconnect = MutableStateFlow(true)
    val cfgNameNotif = MutableStateFlow(true)
    val mtu = MutableStateFlow(1280)
    val wakeLock = MutableStateFlow(true)
    val pingOn = MutableStateFlow(true)
    val pingUrl = MutableStateFlow("http://cp.cloudflare.com")
    val pingInterval = MutableStateFlow(6000)
    val pingTimeout = MutableStateFlow(5000)
    val pingFails = MutableStateFlow(2)
    const val HUD_MIN = 0
    const val HUD_MAX = 5000
    val hudRise = MutableStateFlow(600)  // ms, respon angka HUD saat kecepatan naik (0 = langsung)
    val hudFall = MutableStateFlow(1100) // ms, respon angka HUD saat kecepatan turun (0 = langsung)
    val hotspotMode = MutableStateFlow(0) // 0 = Root (rute TUN), 1 = Non-Root (HTTP Proxy)

    fun init(c: Context) {
        if (sp != null) return
        val s = c.applicationContext.getSharedPreferences("alfy_ui", Context.MODE_PRIVATE)
        sp = s
        for (i in 0..3) rb[i].value = s.getFloat("rb$i", 3f)
        floatOn.value = s.getBoolean("float", false)
        dbg.value = s.getBoolean("debugmode", false)
        allOn.value = s.getBoolean("allrb", false)
        allSpeed.value = s.getFloat("allrbsp", 3f)
        divOn.value = s.getBoolean("divrb", true)
        divSpeed.value = s.getFloat("divrbsp", 3f)
        hostLabel.value = s.getString("hostlabel", "") ?: ""
        noRoot.value = s.getBoolean("noroot", false)
        use4GLabel.value = s.getBoolean("use4g", false)
        slideSp.value = s.getFloat("arrslide", 3f)
        notifOn.value = s.getBoolean("notifrb", true)
        notifSpeed.value = s.getFloat("notifrbsp", 3f)
        blinkSp.value = s.getFloat("arrblink", 3f)
        udpgwPort.value = s.getInt("udpgw", 0)
        hotspot.value = s.getBoolean("hotspot", false)
        transparent.value = s.getBoolean("transparent", true)
        hotspotMode.value = s.getInt("hotspotmode", 0)
        useCompression.value = s.getBoolean("compress", false)
        alwaysReconnect.value = s.getBoolean("alwaysrecon", true)
        cfgNameNotif.value = s.getBoolean("cfgnamenotif", true)
        mtu.value = s.getInt("mtu", 1280)
        wakeLock.value = s.getBoolean("wakelock", true)
        pingOn.value = s.getBoolean("pingon", true)
        pingUrl.value = s.getString("pingurl", "http://cp.cloudflare.com") ?: "http://cp.cloudflare.com"
        pingInterval.value = s.getInt("pinginterval", 6000)
        pingTimeout.value = s.getInt("pingtimeout", 5000)
        pingFails.value = s.getInt("pingfails", 2)
        hudRise.value = s.getInt("hudrise", 600).coerceIn(HUD_MIN, HUD_MAX)
        hudFall.value = s.getInt("hudfall", 1100).coerceIn(HUD_MIN, HUD_MAX)
    }

    fun setHudRise(v: Int) { hudRise.value = v.coerceIn(HUD_MIN, HUD_MAX); sp?.edit()?.putInt("hudrise", hudRise.value)?.apply() }
    fun setHudFall(v: Int) { hudFall.value = v.coerceIn(HUD_MIN, HUD_MAX); sp?.edit()?.putInt("hudfall", hudFall.value)?.apply() }

    fun setAlwaysReconnect(v: Boolean) { alwaysReconnect.value = v; sp?.edit()?.putBoolean("alwaysrecon", v)?.apply() }
    fun setCfgNameNotif(v: Boolean) { cfgNameNotif.value = v; sp?.edit()?.putBoolean("cfgnamenotif", v)?.apply() }
    fun setCompress(v: Boolean) { useCompression.value = v; sp?.edit()?.putBoolean("compress", v)?.apply() }
    fun setMtu(v: Int) { mtu.value = v; sp?.edit()?.putInt("mtu", v)?.apply() }
    fun setWakeLock(v: Boolean) { wakeLock.value = v; sp?.edit()?.putBoolean("wakelock", v)?.apply() }
    fun setPingOn(v: Boolean) { pingOn.value = v; sp?.edit()?.putBoolean("pingon", v)?.apply() }
    fun setPingUrl(v: String) { pingUrl.value = v; sp?.edit()?.putString("pingurl", v)?.apply() }
    fun setPingInterval(v: Int) { pingInterval.value = v; sp?.edit()?.putInt("pinginterval", v)?.apply() }
    fun setPingTimeout(v: Int) { pingTimeout.value = v; sp?.edit()?.putInt("pingtimeout", v)?.apply() }
    fun setPingFails(v: Int) { pingFails.value = v; sp?.edit()?.putInt("pingfails", v)?.apply() }

    fun setAllOn(v: Boolean) {
        allOn.value = v
        sp?.edit()?.putBoolean("allrb", v)?.apply()
    }

    fun setDivOn(v: Boolean) {
        divOn.value = v
        sp?.edit()?.putBoolean("divrb", v)?.apply()
    }

    fun setDivSpeed(v: Float) {
        divSpeed.value = v
        sp?.edit()?.putFloat("divrbsp", v)?.apply()
    }

    fun setAllSpeed(v: Float) {
        allSpeed.value = v
        sp?.edit()?.putFloat("allrbsp", v)?.apply()
    }

    fun setUse4GLabel(v: Boolean) {
        use4GLabel.value = v
        sp?.edit()?.putBoolean("use4g", v)?.apply()
        VpnSvc.refreshNotif()
    }

    fun setTransparent(v: Boolean) {
        transparent.value = v
        sp?.edit()?.putBoolean("transparent", v)?.apply()
    }

    fun setHotspot(v: Boolean) {
        hotspot.value = v
        sp?.edit()?.putBoolean("hotspot", v)?.apply()
    }

    fun setHotspotMode(v: Int) {
        hotspotMode.value = v
        sp?.edit()?.putInt("hotspotmode", v)?.apply()
    }

    fun setNoRoot(v: Boolean) {
        noRoot.value = v
        sp?.edit()?.putBoolean("noroot", v)?.apply()
    }

    fun setNotifOn(v: Boolean) {
        notifOn.value = v
        sp?.edit()?.putBoolean("notifrb", v)?.apply()
    }

    fun setNotifSpeed(v: Float) {
        notifSpeed.value = v
        sp?.edit()?.putFloat("notifrbsp", v)?.apply()
    }

    /** Notifikasi hanya diperbarui sering bila pelangi menyala dan bergerak (hemat baterai bila mati/diam). */
    fun notifAnim(): Boolean = notifOn.value && notifSpeed.value > 0f

    fun setSlideSp(v: Float) {
        slideSp.value = v
        sp?.edit()?.putFloat("arrslide", v)?.apply()
    }

    fun setBlinkSp(v: Float) {
        blinkSp.value = v
        sp?.edit()?.putFloat("arrblink", v)?.apply()
    }

    fun setHostLabel(v: String) {
        hostLabel.value = v
        sp?.edit()?.putString("hostlabel", v)?.apply()
        VpnSvc.refreshNotif()
    }

    /** Kecepatan efektif: jika "semua teks" aktif, dipakai untuk semua bagian. */
    fun speedFor(part: Int): Float = if (allOn.value) allSpeed.value else rb[part].value

    fun getLong(k: String, d: Long) = sp?.getLong(k, d) ?: d
    fun putLong(k: String, v: Long) {
        sp?.edit()?.putLong(k, v)?.apply()
    }
    fun removeKeys(pred: (String) -> Boolean) {
        val s = sp ?: return
        val ks = s.all.keys.filter(pred)
        if (ks.isNotEmpty()) s.edit().apply { ks.forEach { remove(it) } }.apply()
    }

    fun setRb(i: Int, v: Float) {
        rb[i].value = v
        sp?.edit()?.putFloat("rb$i", v)?.apply()
    }

    fun setUdpgw(v: Int) {
        udpgwPort.value = v
        sp?.edit()?.putInt("udpgw", v)?.apply()
    }

    fun setFloat(v: Boolean) {
        floatOn.value = v
        sp?.edit()?.putBoolean("float", v)?.apply()
    }

    fun setDbg(v: Boolean) {
        dbg.value = v
        sp?.edit()?.putBoolean("debugmode", v)?.apply()
    }

    fun getInt(k: String, d: Int) = sp?.getInt(k, d) ?: d
    fun putInt(k: String, v: Int) {
        sp?.edit()?.putInt(k, v)?.apply()
    }
}

/** True saat UI utama terlihat (ON_START..ON_STOP). Hanya untuk animasi UI aplikasi; HUD & notifikasi tidak memakainya. */
object AppFg {
    val fg = MutableStateFlow(true)
}

/** Satu jam bersama untuk semua animasi pelangi di UI. Hanya berdetak selama ada yang mengamati. */
object Rb {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val t: StateFlow<Float> = flow {
        while (true) {
            AppFg.fg.first { it }
            emit(SystemClock.uptimeMillis() / 1000f)
            delay(100)
        }
    }.stateIn(scope, SharingStarted.WhileSubscribed(1000), 0f)

    const val DEG_PER_SEC = 20f

    fun offset(sec: Float, speed: Float): Float = if (speed <= 0f) 0f else (sec * speed * DEG_PER_SEC) % 360f

    fun colors(off: Float, n: Int = 7, step: Float = 50f): List<Color> =
        List(n) { Color.hsv(((off + it * step) % 360f + 360f) % 360f, 0.8f, 1f) }
}

/** Isi teks/gambar dengan gradasi pelangi. Animasi dibaca di fase gambar (tanpa recompose). Speed 0 = statis. */
@Composable
fun Modifier.rainbow(part: Int): Modifier {
    val all by Prefs.allOn.collectAsState()
    val asp by Prefs.allSpeed.collectAsState()
    val psp by Prefs.rb[part].collectAsState()
    return rainbowSp(if (all) asp else psp)
}

/** Dipakai pembungkus Text: aktif hanya jika opsi "semua teks warna-warni" menyala. */
@Composable
fun Modifier.rainbowAll(): Modifier {
    val all by Prefs.allOn.collectAsState()
    if (!all) return this
    val asp by Prefs.allSpeed.collectAsState()
    return rainbowSp(asp)
}

@Composable
fun Modifier.rainbowSp(sp: Float): Modifier {
    val clk: State<Float>? = if (sp > 0f) Rb.t.collectAsState() else null
    return this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val off = Rb.offset(clk?.value ?: 0f, sp)
            drawRect(
                Brush.horizontalGradient(Rb.colors(off, 7, 50f).let { it + it.first() }, 0f, size.width.coerceAtLeast(1f)),
                blendMode = BlendMode.SrcIn
            )
        }
}

/** Statistik pemakaian data harian (disimpan di SharedPreferences, 62 hari terakhir). */
object Usage {
    private val kf = java.text.SimpleDateFormat("yyyyMMdd", Locale.US)
    private var curKey = ""
    private var curVal = 0L
    private var dirty = false

    private fun key(cal: java.util.Calendar) = "u_" + kf.format(cal.time)

    @Synchronized
    fun add(b: Long) {
        if (b <= 0) return
        val k = key(java.util.Calendar.getInstance())
        if (k != curKey) {
            flush()
            curKey = k
            curVal = Prefs.getLong(k, 0L)
        }
        curVal += b
        dirty = true
    }

    @Synchronized
    fun flush() {
        if (dirty && curKey.isNotEmpty()) Prefs.putLong(curKey, curVal)
        dirty = false
    }

    @Synchronized
    private fun get(k: String): Long = if (k == curKey) curVal else Prefs.getLong(k, 0L)

    @Synchronized
    fun prune() {
        val c = java.util.Calendar.getInstance()
        c.add(java.util.Calendar.DAY_OF_YEAR, -62)
        val limit = key(c)
        Prefs.removeKeys { it.startsWith("u_") && it < limit }
    }

    /** Hasil: hari ini, minggu ini (Senin-), bulan ini. */
    @Synchronized
    fun totals(): Triple<Long, Long, Long> {
        val now = java.util.Calendar.getInstance()
        val today = get(key(now))
        var week = 0L
        val w = now.clone() as java.util.Calendar
        var guard = 0
        while (guard++ < 7) {
            week += get(key(w))
            if (w.get(java.util.Calendar.DAY_OF_WEEK) == java.util.Calendar.MONDAY) break
            w.add(java.util.Calendar.DAY_OF_YEAR, -1)
        }
        var month = 0L
        val m = now.clone() as java.util.Calendar
        for (i in 0 until now.get(java.util.Calendar.DAY_OF_MONTH)) {
            month += get(key(m))
            m.add(java.util.Calendar.DAY_OF_YEAR, -1)
        }
        return Triple(today, week, month)
    }

    fun fmtBytes(b: Long): String = when {
        b < 1024L -> "$b B"
        b < 1048576L -> "${(b / 1024L)} KB"
        b < 1073741824L -> "${(b / 1048576L)} MB"
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    fun text(): String {
        val (d, w, m) = totals()
        return "Hari ini ${fmtBytes(d)} · Minggu ${fmtBytes(w)} · Bulan ${fmtBytes(m)}"
    }
}

object Mon {
    val rx = AtomicLong() // byte menuju perangkat (download), dihitung di TUN
    val tx = AtomicLong() // byte dari perangkat (upload), dihitung di TUN
    val dl = MutableStateFlow(0f)
    val ul = MutableStateFlow(0f)
    val dbm = MutableStateFlow<Int?>(null)
    val netType = MutableStateFlow("")
    val band = MutableStateFlow<String?>(null)
    val ip = MutableStateFlow("-")
    val hTick = MutableStateFlow(0)

    const val N = 240
    private val hd = FloatArray(N)
    private val hu = FloatArray(N)
    private var pos = 0
    private var cnt = 0

    @Synchronized
    fun push(d: Float, u: Float) {
        hd[pos] = d
        hu[pos] = u
        pos = (pos + 1) % N
        if (cnt < N) cnt++
        hTick.value = hTick.value + 1
    }

    @Synchronized
    fun history(outD: FloatArray, outU: FloatArray): Int {
        val start = (pos - cnt + N) % N
        for (i in 0 until cnt) {
            outD[i] = hd[(start + i) % N]
            outU[i] = hu[(start + i) % N]
        }
        return cnt
    }

    @Synchronized
    fun resetSpeed() {
        rx.set(0)
        tx.set(0)
        dl.value = 0f
        ul.value = 0f
        pos = 0
        cnt = 0
        hTick.value = hTick.value + 1
    }

    fun fmt(bps: Float): String = when {
        bps < 1048576f -> "${(bps / 1024f).toLong()} KB/s"
        else -> "${(bps / 1048576f).toLong()} MB/s"
    }

    // ---- dBm: scan otomatis tiap 3 detik, nilai tidak valid -> null ("-") ----
    private var users = 0
    private var appCtx: Context? = null
    private var ht: HandlerThread? = null
    private var bg: Handler? = null
    private val scanRun = object : Runnable {
        override fun run() {
            val c = appCtx
            if (c != null) scanNet(c) else dbm.value = null
            if (users > 0) bg?.postDelayed(this, 3000)
        }
    }

    @Synchronized
    fun dbmUse(ctx: Context, on: Boolean) {
        appCtx = ctx.applicationContext
        if (on) {
            users++
            if (users == 1) {
                val t = HandlerThread("alfy-dbm").also { it.start() }
                ht = t
                bg = Handler(t.looper).also { it.post(scanRun) }
            }
        } else {
            users = maxOf(0, users - 1)
            if (users == 0) {
                bg?.removeCallbacksAndMessages(null)
                ht?.quitSafely()
                ht = null
                bg = null
                try { SignalReader.stop() } catch (e: Throwable) { }
                dbm.value = null
                band.value = null
                netType.value = ""
            }
        }
    }

    private fun localIp(): String {
        try {
            for (ni in java.net.NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback || ni.name.startsWith("tun")) continue
                for (a in ni.inetAddresses.toList()) if (a is java.net.Inet4Address && !a.isLoopbackAddress) return a.hostAddress ?: "-"
            }
        } catch (e: Exception) { }
        return "-"
    }

    private fun scanNet(c: Context) {
        ip.value = localIp()
        val oldSig = "${dbm.value}|${band.value}|${netType.value}"
        val r = try { SignalReader.read(c) } catch (e: Throwable) { null }
        dbm.value = r?.dbm
        netType.value = r?.type ?: ""
        // Band dari scan sel BARU SIM data aktif (SignalReader, logika SpeedMeter); tanpa dumpsys / data basi.
        // Label manual (4G/LTE) dicentang -> UI pakai netLabel, Band tidak dipakai.
        band.value = if (Prefs.use4GLabel.value) null else r?.band
        // Band / dBm berubah -> notifikasi langsung diperbarui (tidak menunggu siklus 5 detik)
        if (oldSig != "${dbm.value}|${band.value}|${netType.value}") {
            VpnSvc.refreshNotif()
            AppNotif.refresh(c)
        }
    }

    /** Tipe jaringan sesuai opsi label ("LTE" -> "4G" bila diaktifkan). */
    fun netLabel(): String {
        val t = netType.value
        return if (t == "LTE" && Prefs.use4GLabel.value) "4G" else t
    }

    /** Root + Band berhasil -> Band saja (tanpa tipe jaringan); selain itu tipe jaringan. */
    fun netInfo(): String = if (Prefs.use4GLabel.value) netLabel().ifEmpty { "-" } else (band.value ?: netLabel().ifEmpty { "-" })

    fun infoLine(): String = "${ip.value} \u2022 ${dbmText(dbm.value)} \u2022 ${netInfo()}"

    fun dataText(b: Long): String = if (b < 1073741824L) String.format(Locale.US, "Data: %.1f MB", b / 1048576.0) else String.format(Locale.US, "Data: %.2f GB", b / 1073741824.0)

    fun dbmText(v: Int?): String = if (v == null) "-" else "$v dBm"
}


/** Garis pemisah 4dp: pelangi berjalan (kecepatan & on/off dari Pengaturan), jika OFF kembali abu-abu polos. */
@Composable
fun RbDivider() {
    val on by Prefs.divOn.collectAsState()
    val spd by Prefs.divSpeed.collectAsState()
    if (!on) {
        androidx.compose.material3.HorizontalDivider(modifier = Modifier.fillMaxWidth(), thickness = 4.dp, color = Color.Gray)
        return
    }
    val clk: State<Float>? = if (spd > 0f) Rb.t.collectAsState() else null
    Box(
        Modifier.fillMaxWidth().height(4.dp).drawBehind {
            val off = Rb.offset(clk?.value ?: 0f, spd)
            drawRect(Brush.horizontalGradient(Rb.colors(off, 7, 50f).let { it + it.first() }, 0f, size.width.coerceAtLeast(1f)))
        }
    )
}
