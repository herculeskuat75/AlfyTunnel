package com.alfy.tunnel

import android.os.SystemClock
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

/**
 * Sumber hitungan paling akurat: counter kernel /proc/net/dev (butuh root).
 * - tun*: byte yang dipakai aplikasi (rx = unduh, tx = unggah), dipakai untuk kecepatan.
 * - rmnet/ccmni/wlan/eth: byte fisik (termasuk overhead tunnel), dipakai untuk pemakaian harian.
 * Setiap sampel membawa cap waktunya sendiri supaya kecepatan dihitung dengan selang waktu sebenarnya.
 * Tanpa root: snap() = null dan Hud memakai hitungan TUN internal.
 */
object NetSrc {
    class Snap(val t: Long, val rx: Long, val tx: Long, val pRx: Long, val pTx: Long, val phy: Boolean)

    @Volatile private var cur: Snap? = null
    @Volatile private var run = false
    private var th: Thread? = null
    private var proc: Process? = null

    val ok: Boolean get() = cur != null
    fun snap(): Snap? = cur

    @Synchronized
    fun start() {
        if (run) return
        run = true
        cur = null
        th = Thread { loop() }.also { it.isDaemon = true; it.start() }
    }

    @Synchronized
    fun stop() {
        run = false
        cur = null
        th?.interrupt()
        th = null
        try { proc?.destroy() } catch (e: Throwable) { }
        proc = null
    }

    private class Parsed(val tun: LongArray?, val phy: Map<String, LongArray>)

    private fun parse(t: String): Parsed {
        var tun: LongArray? = null
        val phy = HashMap<String, LongArray>()
        for (ln in t.lineSequence()) {
            val i = ln.indexOf(':')
            if (i < 0) continue
            val name = ln.substring(0, i).trim()
            val f = ln.substring(i + 1).trim().split(Regex("\\s+"))
            if (f.size < 9) continue
            val a = f[0].toLongOrNull() ?: continue
            val b = f[8].toLongOrNull() ?: continue
            if (name.startsWith("tun")) {
                if (tun == null) tun = longArrayOf(a, b)
            } else if (name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("wlan") || name.startsWith("eth")) {
                phy[name] = longArrayOf(a, b)
            }
        }
        return Parsed(tun, phy)
    }

    private fun loop() {
        var rootBad = false
        var wr: java.io.OutputStream? = null
        var rd: BufferedReader? = null
        var lastA = -1L
        var lastB = -1L
        var cumR = 0L
        var cumX = 0L
        var cumPR = 0L
        var cumPX = 0L
        val lastPhy = HashMap<String, LongArray>()
        try {
            while (run) {
                var pr: Parsed? = try { parse(File("/proc/net/dev").readText()) } catch (e: Throwable) { null }
                if (pr?.tun == null && !rootBad) {
                    try {
                        if (proc == null) {
                            val p = ProcessBuilder("su").redirectErrorStream(true).start()
                            proc = p
                            wr = p.outputStream
                            rd = BufferedReader(InputStreamReader(p.inputStream))
                        }
                        wr!!.write("cat /proc/net/dev; echo __E__\n".toByteArray())
                        wr.flush()
                        val sb = StringBuilder()
                        while (true) {
                            val ln = rd!!.readLine() ?: throw java.io.IOException("su tertutup")
                            if (ln.trim() == "__E__") break
                            sb.append(ln).append('\n')
                        }
                        pr = parse(sb.toString())
                    } catch (e: Throwable) {
                        if (!run) return
                        rootBad = true
                        try { proc?.destroy() } catch (x2: Throwable) { }
                        proc = null
                    }
                }
                val v = pr?.tun
                if (pr != null && v != null) {
                    if (lastA < 0) {
                        lastA = v[0]; lastB = v[1]
                    } else {
                        cumR += if (v[0] >= lastA) v[0] - lastA else v[0]
                        cumX += if (v[1] >= lastB) v[1] - lastB else v[1]
                        lastA = v[0]; lastB = v[1]
                    }
                    for ((k, c) in pr.phy) {
                        val l = lastPhy[k]
                        if (l != null) {
                            cumPR += if (c[0] >= l[0]) c[0] - l[0] else c[0]
                            cumPX += if (c[1] >= l[1]) c[1] - l[1] else c[1]
                        }
                        lastPhy[k] = c
                    }
                    cur = Snap(SystemClock.elapsedRealtime(), cumR, cumX, cumPR, cumPX, pr.phy.isNotEmpty())
                } else if (rootBad) {
                    cur = null
                }
                Thread.sleep(200)
            }
        } catch (e: InterruptedException) {
        } catch (e: Throwable) {
            cur = null
        }
    }
}
