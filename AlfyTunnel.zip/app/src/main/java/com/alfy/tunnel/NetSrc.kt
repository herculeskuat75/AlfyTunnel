package com.alfy.tunnel

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicLong

/**
 * Sumber hitungan paling akurat (sesuai hasil diagnostik): counter kernel /proc/net/dev pada antarmuka tun (root).
 * Nilai rx = unduh, tx = unggah, dihitung kumulatif sejak start. Jika tidak tersedia, Hud memakai hitungan TUN sendiri.
 */
object NetSrc {
    @Volatile var ok = false
        private set
    private val r = AtomicLong()
    private val x = AtomicLong()
    @Volatile private var run = false
    private var th: Thread? = null
    private var proc: Process? = null

    fun rx() = r.get()
    fun tx() = x.get()

    @Synchronized
    fun start() {
        if (run) return
        run = true
        ok = false
        r.set(0); x.set(0)
        th = Thread { loop() }.also { it.isDaemon = true; it.start() }
    }

    @Synchronized
    fun stop() {
        run = false
        ok = false
        th?.interrupt()
        th = null
        try { proc?.destroy() } catch (e: Throwable) { }
        proc = null
    }

    private fun parse(t: String): LongArray? {
        for (ln in t.lineSequence()) {
            val i = ln.indexOf(':')
            if (i < 0) continue
            if (!ln.substring(0, i).trim().startsWith("tun")) continue
            val f = ln.substring(i + 1).trim().split(Regex("\\s+"))
            if (f.size < 9) continue
            val a = f[0].toLongOrNull() ?: continue
            val b = f[8].toLongOrNull() ?: continue
            return longArrayOf(a, b)
        }
        return null
    }

    private fun loop() {
        var rootBad = false
        var wr: java.io.OutputStream? = null
        var rd: BufferedReader? = null
        var lastA = -1L
        var lastB = -1L
        try {
            while (run) {
                var v: LongArray? = try { parse(File("/proc/net/dev").readText()) } catch (e: Throwable) { null }
                if (v == null && !rootBad) {
                    try {
                        if (proc == null) {
                            val p = ProcessBuilder("su").redirectErrorStream(true).start()
                            proc = p
                            wr = p.outputStream
                            rd = BufferedReader(InputStreamReader(p.inputStream))
                        }
                        wr!!.write("cat /proc/net/dev; echo __E__\n".toByteArray())
                        wr.flush()
                        val sb = StringBuilder()
                        while (true) {
                            val ln = rd!!.readLine() ?: throw java.io.IOException("su tertutup")
                            if (ln.trim() == "__E__") break
                            sb.append(ln).append('\n')
                        }
                        v = parse(sb.toString())
                    } catch (e: Throwable) {
                        if (!run) return
                        rootBad = true
                        try { proc?.destroy() } catch (x2: Throwable) { }
                        proc = null
                        ok = false
                    }
                }
                if (v != null) {
                    if (lastA < 0) {
                        lastA = v[0]; lastB = v[1]
                    } else {
                        r.addAndGet(if (v[0] >= lastA) v[0] - lastA else v[0])
                        x.addAndGet(if (v[1] >= lastB) v[1] - lastB else v[1])
                        lastA = v[0]; lastB = v[1]
                    }
                    ok = true
                } else if (rootBad) {
                    ok = false
                }
                Thread.sleep(200)
            }
        } catch (e: InterruptedException) {
        } catch (e: Throwable) {
            ok = false
        }
    }
}
