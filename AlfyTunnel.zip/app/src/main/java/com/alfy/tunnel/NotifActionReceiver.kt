package com.alfy.tunnel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class NotifActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_RECONNECT = "ACTION_RECONNECT"
    }

    override fun onReceive(c: Context, i: Intent?) {
        val act = when (i?.action) {
            ACTION_STOP -> VpnSvc.ACT_STOP
            ACTION_RECONNECT -> VpnSvc.ACT_RECONNECT
            else -> return
        }
        if (Bus.status.value == St.IDLE) return
        try {
            ContextCompat.startForegroundService(c, Intent(c, VpnSvc::class.java).setAction(act))
        } catch (e: Exception) { }
    }
}
