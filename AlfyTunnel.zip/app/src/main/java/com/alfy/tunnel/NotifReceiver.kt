package com.alfy.tunnel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Tombol "Sambung Ulang" di notifikasi: diteruskan ke VpnSvc tanpa membuka aplikasi. */
class NotifReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        if (i?.action != VpnSvc.ACT_RECONNECT) return
        if (Bus.status.value == St.IDLE) return
        try {
            c.startService(Intent(c, VpnSvc::class.java).setAction(VpnSvc.ACT_RECONNECT))
        } catch (e: Throwable) { }
    }
}
