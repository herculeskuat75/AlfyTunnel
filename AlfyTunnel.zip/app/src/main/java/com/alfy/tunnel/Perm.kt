package com.alfy.tunnel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

/** Minta semua izin sistem di awal: metode root (otomatis lewat su) lalu metode non-root (dialog/pengaturan sistem). */
object Perm {
    private var started = false
    private var ready = false
    private var rAsked = false
    private var oAsked = false
    private var aAsked = false

    private fun rootGrant(a: Activity): Boolean {
        val pkg = a.packageName
        val c = "$pkg/$pkg.AccSvc"
        val sh = StringBuilder()
        sh.append("pm grant $pkg android.permission.ACCESS_FINE_LOCATION\n")
        if (Build.VERSION.SDK_INT >= 33) sh.append("pm grant $pkg android.permission.POST_NOTIFICATIONS\n")
        sh.append("appops set $pkg SYSTEM_ALERT_WINDOW allow\n")
        sh.append("dumpsys deviceidle whitelist +$pkg\n")
        sh.append("cur=\$(settings get secure enabled_accessibility_services)\n")
        sh.append("case \"\$cur\" in *$c*) ;; null|\"\") settings put secure enabled_accessibility_services $c;; *) settings put secure enabled_accessibility_services \"\$cur:$c\";; esac\n")
        sh.append("settings put secure accessibility_enabled 1\nexit\n")
        return try {
            val p = ProcessBuilder("su").redirectErrorStream(true).start()
            p.outputStream.write(sh.toString().toByteArray())
            p.outputStream.flush()
            p.outputStream.close()
            p.inputStream.readBytes()
            p.waitFor()
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun start(a: Activity) {
        if (started) return
        started = true
        Thread {
            if (!Prefs.noRoot.value) rootGrant(a)
            a.runOnUiThread {
                ready = true
                next(a)
            }
        }.start()
    }

    fun next(a: Activity) {
        if (!ready) return
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (a.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (need.isNotEmpty() && !rAsked) {
            rAsked = true
            a.requestPermissions(need.toTypedArray(), 7)
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(a) && !oAsked) {
            oAsked = true
            try { a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))) } catch (e: Throwable) { }
            return
        }
        if (AccSvc.inst == null && !aAsked) {
            aAsked = true
            try { a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Throwable) { }
        }
    }
}
