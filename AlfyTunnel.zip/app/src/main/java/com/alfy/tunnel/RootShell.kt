package com.alfy.tunnel

import java.util.concurrent.TimeUnit

/** Eksekusi perintah via `su -c` (root). Hasil cek root di-cache; dicoba ulang sesekali bila sebelumnya gagal. */
object RootShell {
    @Volatile private var state = 0 // 0 belum dicek, 1 root ada, -1 tidak ada / ditolak
    private var retry = 0

    /**
     * Jalankan `su -c <cmd>`. Hasil dipakai walau exit code bukan 0 (dumpsys sering begitu).
     * Null hanya bila su gagal dijalankan, timeout, atau keluaran kosong.
     */
    fun exec(cmd: String, timeoutSec: Long = 8): String? {
        var p: Process? = null
        return try {
            p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            try { p.outputStream.close() } catch (e: Throwable) { }
            val pp = p
            var out = ""
            val t = Thread { try { out = pp.inputStream.bufferedReader().readText() } catch (e: Throwable) { } }
            t.isDaemon = true
            t.start()
            t.join(timeoutSec * 1000)
            if (t.isAlive) null else {
                try { pp.waitFor(1, TimeUnit.SECONDS) } catch (e: Throwable) { }
                if (out.isNotBlank()) out else null
            }
        } catch (e: Throwable) { null } finally {
            try { p?.destroy() } catch (e: Throwable) { }
        }
    }

    /** True bila root tersedia dan diizinkan (dan pengguna tidak memilih mode Non-Root). */
    fun available(): Boolean {
        if (Prefs.noRoot.value) return false
        if (state == 0 || (state < 0 && ++retry % 5 == 0)) {
            state = if (exec("id")?.contains("uid=0") == true) 1 else -1
        }
        return state == 1
    }
}
