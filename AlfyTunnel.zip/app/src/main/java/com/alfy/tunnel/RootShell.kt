package com.alfy.tunnel

import java.io.File
import java.util.concurrent.TimeUnit

/** Eksekusi perintah via `su -c` (root). Hasil cek root di-cache; dicoba ulang sesekali bila sebelumnya gagal. */
object RootShell {
    @Volatile private var state = 0 // 0 belum dicek, 1 root ada, -1 tidak ada / ditolak
    private var retry = 0

    private val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
        "/data/adb/magisk/su", "/system/sbin/su", "/data/adb/ksu/bin/su"
    )

    /** Jalankan `su -c <cmd>`. Mengembalikan stdout, atau null bila gagal / timeout. */
    fun exec(cmd: String, timeoutSec: Long = 6): String? = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        p.outputStream.close()
        var out = ""
        val t = Thread { try { out = p.inputStream.bufferedReader().readText() } catch (e: Throwable) { } }
        t.isDaemon = true
        t.start()
        if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
            p.destroy()
            null
        } else {
            t.join(1000)
            if (p.exitValue() == 0) out else null
        }
    } catch (e: Throwable) { null }

    /** True bila root tersedia dan diizinkan (dan pengguna tidak memilih mode Non-Root). */
    fun available(): Boolean {
        if (Prefs.noRoot.value) return false
        if (state == 0 || (state < 0 && ++retry % 20 == 0)) {
            val hasSu = suPaths.any { File(it).exists() }
            state = if (hasSu && exec("id")?.contains("uid=0") == true) 1 else -1
        }
        return state == 1
    }
}
