package com.alfy.tunnel

/** Eksekusi perintah via `su -c` (root). Hasil cek root di-cache; dicoba ulang sesekali bila sebelumnya gagal. */
object RootShell {
    @Volatile private var state = 0 // 0 belum dicek, 1 root ada, -1 tidak ada / ditolak
    private var retry = 0

    /**
     * Jalankan `su -c <cmd>`. Hasil dipakai walau exit code bukan 0 (dumpsys sering begitu).
     * Null hanya bila su gagal dijalankan, timeout, atau keluaran kosong.
     */
    fun exec(cmd: String, timeoutSec: Long = 8): String? {
        val sb = StringBuilder()
        var proc: Process? = null
        try {
            val pp = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            proc = pp
            try { pp.outputStream.close() } catch (e: Throwable) { }
            val t = Thread {
                try {
                    pp.inputStream.bufferedReader().use { r ->
                        val buf = CharArray(4096)
                        while (true) {
                            val n = r.read(buf)
                            if (n < 0) break
                            synchronized(sb) { sb.append(buf, 0, n) }
                        }
                    }
                } catch (e: Throwable) { }
            }
            t.isDaemon = true
            t.start()
            t.join(timeoutSec * 1000)
            if (t.isAlive) return null
        } catch (e: Throwable) {
            return null
        } finally {
            try { proc?.destroy() } catch (e: Throwable) { }
        }
        val out = synchronized(sb) { sb.toString() }
        return if (out.isNotBlank()) out else null
    }

    /** True bila root tersedia dan diizinkan (dan pengguna tidak memilih mode Non-Root). */
    fun available(): Boolean {
        if (Prefs.noRoot.value) return false
        if (state == 0 || (state < 0 && ++retry % 5 == 0)) {
            state = if (exec("id")?.contains("uid=0") == true) 1 else -1
        }
        return state == 1
    }

    private fun cmdFor(pkg: String, k: Int): String = when (k) {
        0 -> "pm grant $pkg android.permission.POST_NOTIFICATIONS; appops set $pkg POST_NOTIFICATION allow"
        1 -> "pm grant $pkg android.permission.ACCESS_FINE_LOCATION; pm grant $pkg android.permission.ACCESS_COARSE_LOCATION"
        2 -> "appops set $pkg SYSTEM_ALERT_WINDOW allow"
        else -> "dumpsys deviceidle whitelist +$pkg; appops set $pkg RUN_ANY_IN_BACKGROUND allow"
    }

    /** Beri izin k (0 notif, 1 lokasi, 2 overlay, 3 baterai) via root. False bila root tidak tersedia. */
    fun grant(pkg: String, k: Int): Boolean {
        if (!available()) return false
        exec(cmdFor(pkg, k))
        return true
    }

    fun grantAll(pkg: String): Boolean {
        if (!available()) return false
        exec((0..3).joinToString("; ") { cmdFor(pkg, it) }, 20)
        return true
    }

    /** Cek status asli via dumpsys/appops (root). Null bila tidak bisa dipastikan. */
    fun check(pkg: String, k: Int): Boolean? {
        if (!available()) return null
        return when (k) {
            2 -> exec("appops get $pkg SYSTEM_ALERT_WINDOW")?.contains("allow") 
            3 -> exec("dumpsys deviceidle whitelist")?.contains(pkg)
            else -> null
        }
    }
}
