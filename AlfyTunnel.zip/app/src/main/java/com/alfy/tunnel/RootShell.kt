package com.alfy.tunnel

/** Eksekusi perintah via `su -c` (root). Hasil cek root di-cache; dicoba ulang sesekali bila sebelumnya gagal. */
object RootShell {
    @Volatile private var state = 0 // 0 belum dicek, 1 root ada, -1 tidak ada / ditolak
    private var retry = 0

    /**
     * Jalankan `su -c <cmd>`. Hasil dipakai walau exit code bukan 0 (dumpsys sering begitu).
     * Null hanya bila su gagal dijalankan, timeout, atau keluaran kosong.
     */
    fun exec(cmd: String, timeoutSec: Long = 8): String? {
        val sb = StringBuilder()
        var proc: Process? = null
        try {
            val pp = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            proc = pp
            try { pp.outputStream.close() } catch (e: Throwable) { }
            val t = Thread {
                try {
                    pp.inputStream.bufferedReader().use { r ->
                        val buf = CharArray(4096)
                        while (true) {
                            val n = r.read(buf)
                            if (n < 0) break
                            synchronized(sb) { sb.append(buf, 0, n) }
                        }
                    }
                } catch (e: Throwable) { }
            }
            t.isDaemon = true
            t.start()
            t.join(timeoutSec * 1000)
            if (t.isAlive) return null
        } catch (e: Throwable) {
            return null
        } finally {
            try { proc?.destroy() } catch (e: Throwable) { }
        }
        val out = synchronized(sb) { sb.toString() }
        return if (out.isNotBlank()) out else null
    }

    /** True bila root tersedia dan diizinkan (dan pengguna tidak memilih mode Non-Root). */
    fun available(): Boolean {
        if (Prefs.noRoot.value) return false
        if (state == 0 || (state < 0 && ++retry % 5 == 0)) {
            state = if (exec("id")?.contains("uid=0") == true) 1 else -1
        }
        return state == 1
    }
}
