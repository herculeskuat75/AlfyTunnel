package com.alfy.tunnel

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private val GREEN = Color(0xFF3DDC84)

@Composable
fun LogLine(l: String) {
    val i = l.indexOf("] ")
    val ts = if (i > 0) l.substring(0, i + 1) else ""
    val msg = if (i > 0) l.substring(i + 2) else l
    val green = msg == "Connected"
    val bold = green || msg.startsWith("Response:")
    Text(
        buildAnnotatedString {
            if (ts.isNotEmpty()) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(ts) }
                append(" ")
            }
            withStyle(SpanStyle(color = if (green) GREEN else Color.Unspecified, fontWeight = if (bold) FontWeight.Bold else null)) {
                append(msg)
            }
        },
        fontFamily = FontFamily.Monospace, fontSize = 12.sp
    )
}

@Composable
private fun SpeedRow() {
    val dl by Mon.dl.collectAsState()
    val ul by Mon.ul.collectAsState()
    val dbm by Mon.dbm.collectAsState()
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("↓ " + Mon.fmt(dl), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("↑ " + Mon.fmt(ul), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(Mon.dbmText(dbm), fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun SpeedCard(host: String, onFloat: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        Mon.dbmUse(ctx, true)
        onDispose { Mon.dbmUse(ctx, false) }
    }
    val fl by Prefs.floatOn.collectAsState()
    val label by Prefs.hostLabel.collectAsState()
    var edit by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                label.ifBlank { host }, Modifier.clickable { edit = true }.rainbow(Prefs.P_HOST), color = Color.White,
                fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1
            )
            Text("Ketuk nama untuk mengganti", fontSize = 11.sp)
            SpeedRow()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Mengambang", Modifier.weight(1f), fontSize = 13.sp)
                Switch(checked = fl, onCheckedChange = onFloat)
            }
        }
    }
    if (edit) {
        var t by remember { mutableStateOf(label) }
        AlertDialog(
            onDismissRequest = { edit = false },
            title = { Text("Ganti nama tampilan") },
            text = {
                OutlinedTextField(
                    value = t, onValueChange = { t = it }, singleLine = true,
                    label = { Text("Nama bebas. Kosong = otomatis ($host)") }
                )
            },
            confirmButton = { TextButton(onClick = { Prefs.setHostLabel(t.trim()); edit = false }) { Text("Simpan") } },
            dismissButton = { TextButton(onClick = { edit = false }) { Text("Batal") } }
        )
    }
}

private fun permOn(c: Context, k: Int): Boolean = when (k) {
    0 -> (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()
    1 -> c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    2 -> Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)
    else -> Build.VERSION.SDK_INT < 23 ||
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
}

@Composable
private fun Perm(title: String, on: Boolean, steps: List<String>, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text(if (on) "AKTIF" else "MATI", color = if (on) GREEN else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
            for (s in steps) Text(s.uppercase(), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            if (!on) Button(onClick = onClick, Modifier.fillMaxWidth()) { Text("AKTIFKAN") }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, toast: (String) -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rs by Prefs.resume.collectAsState()
    val dbg by Prefs.dbg.collectAsState()
    val pkg = ctx.packageName
    fun bump() {
        Prefs.resume.value = Prefs.resume.value + 1
    }

    val notifReq = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump() }
    val locReq = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump() }
    val bgPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { Img.saveBg(ctx, uri) }.getOrDefault(false) }
            toast(if (ok) "Latar diganti" else "Gambar tidak bisa dibaca")
        }
    }
    val iconPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { Img.square(ctx, uri, 192) }.getOrNull() }
            if (bmp == null) {
                toast("Gambar tidak bisa dibaca")
            } else if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
                toast("Launcher tidak mendukung shortcut")
            } else {
                val info = ShortcutInfoCompat.Builder(ctx, "alfy_custom")
                    .setShortLabel("AlfyTunnel")
                    .setIcon(IconCompat.createWithBitmap(bmp))
                    .setIntent(Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
                    .build()
                ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
                toast("Konfirmasi penambahan shortcut di layar utama")
            }
        }
    }

    fun go(i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) { toast("Tidak bisa membuka pengaturan") }
    }

    val appDetail = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
    val names = listOf("Notifikasi", "Speedometer mengambang", "", "Nama tampilan")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Kembali") }
            Text("Pengaturan & izin", style = MaterialTheme.typography.titleLarge)
        }
        Text("Izin (tanpa root)", style = MaterialTheme.typography.titleMedium)
        Perm(
            "Notifikasi", remember(rs) { permOn(ctx, 0) },
            listOf("1. tekan aktifkan.", "2. pilih izinkan.", "3. jika tidak muncul: pengaturan > notifikasi > aktifkan alfytunnel.")
        ) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notifReq.launch(Manifest.permission.POST_NOTIFICATIONS)
            else go(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg))
        }
        Perm(
            "Lokasi (untuk dBm)", remember(rs) { permOn(ctx, 1) },
            listOf("1. tekan aktifkan.", "2. pilih saat aplikasi digunakan, lalu presisi.", "3. hanya dipakai membaca sinyal seluler (dBm).")
        ) { locReq.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
        Perm(
            "Overlay (speedometer mengambang)", remember(rs) { permOn(ctx, 2) },
            listOf("1. tekan aktifkan.", "2. cari alfytunnel.", "3. nyalakan izinkan tampil di atas aplikasi lain.", "4. tekan kembali.")
        ) { go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg"))) }
        Perm(
            "Baterai (tanpa dibatasi)", remember(rs) { permOn(ctx, 3) },
            listOf("1. tekan aktifkan.", "2. cari alfytunnel.", "3. pilih tidak dibatasi / jangan dioptimalkan.")
        ) { go(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        FilledTonalButton(onClick = { go(appDetail) }, Modifier.fillMaxWidth()) { Text("Buka pengaturan aplikasi") }
        HorizontalDivider()

        Text("Teks warna-warni berjalan", style = MaterialTheme.typography.titleMedium)
        val allOn by Prefs.allOn.collectAsState()
        val allSp by Prefs.allSpeed.collectAsState()
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Semua teks aplikasi warna-warni", Modifier.weight(1f))
            Switch(checked = allOn, onCheckedChange = { Prefs.setAllOn(it) })
        }
        Text("Kecepatan semua teks: " + if (allSp <= 0f) "DIAM" else allSp.roundToInt().toString())
        Slider(
            value = allSp, onValueChange = { Prefs.setAllSpeed(it.roundToInt().toFloat()) },
            valueRange = 0f..10f, steps = 9
        )
        Text("Kecepatan gerak pelangi per bagian (0 = diam; dipakai bila opsi di atas mati)", style = MaterialTheme.typography.titleMedium)
        for (i in listOf(0, 1, 3)) {
            val v by Prefs.rb[i].collectAsState()
            Text(names[i] + ": " + if (v <= 0f) "DIAM" else v.roundToInt().toString())
            Slider(
                value = v, onValueChange = { Prefs.setRb(i, it.roundToInt().toFloat()) },
                valueRange = 0f..10f, steps = 9
            )
        }
        Text("Animasi panah mengambang (0 = mati)", style = MaterialTheme.typography.titleMedium)
        val slSp by Prefs.slideSp.collectAsState()
        Text("Kecepatan panah meluncur: " + if (slSp <= 0f) "MATI" else slSp.roundToInt().toString())
        Slider(
            value = slSp, onValueChange = { Prefs.setSlideSp(it.roundToInt().toFloat()) },
            valueRange = 0f..10f, steps = 9
        )
        val blSp by Prefs.blinkSp.collectAsState()
        Text("Kecepatan kedip panah: " + if (blSp <= 0f) "MATI" else blSp.roundToInt().toString())
        Slider(
            value = blSp, onValueChange = { Prefs.setBlinkSp(it.roundToInt().toFloat()) },
            valueRange = 0f..10f, steps = 9
        )
        val hl by Prefs.hostLabel.collectAsState()
        Field(hl, "Nama tampilan (bebas, kosong = otomatis dari server)") { Prefs.setHostLabel(it) }
        HorizontalDivider()

        Text("Personalisasi", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = { bgPick.launch("image/*") }) { Text("Latar dari galeri") }
            TextButton(onClick = { Img.clearBg(ctx) }) { Text("Hapus latar") }
        }
        FilledTonalButton(onClick = { iconPick.launch("image/*") }, Modifier.fillMaxWidth()) { Text("Ikon dari galeri (shortcut)") }
        Text(
            "Batasan: Android tidak mengizinkan aplikasi mengganti ikon aslinya dengan gambar bebas. " +
                "Yang dibuat adalah shortcut baru di layar utama dengan gambar pilihan; ikon lama dihapus manual bila perlu.",
            fontSize = 12.sp
        )
        HorizontalDivider()

        Text("Log", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Hentikan log setelah Connected", Modifier.weight(1f))
            val lo by Prefs.logOff.collectAsState()
            Switch(checked = lo, onCheckedChange = { Prefs.setLogOff(it) })
        }
        HorizontalDivider()

        Text("Uji akurasi", style = MaterialTheme.typography.titleMedium)
        val noRoot by Prefs.noRoot.collectAsState()
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Paksa mode tanpa root (hitungan TUN internal)", Modifier.weight(1f))
            Switch(checked = noRoot, onCheckedChange = { Prefs.setNoRoot(it) })
        }
        Text(
            "Mati = otomatis (kernel root jika ada, jika tidak TUN internal). Nyalakan untuk melihat seperti apa " +
                "akurasi di HP tanpa root, lalu bandingkan lewat uji di bawah.",
            fontSize = 12.sp
        )
        var accRun by remember { mutableStateOf(AccTest.running()) }
        var accLog by remember { mutableStateOf("") }
        Text(
            "1. Sambungkan VPN, tekan Mulai ukur. 2. Di aplikasi lain (browser, dll) unduh atau unggah file yang " +
                "ukurannya kamu tahu, misalnya 10 MB. 3. Kembali ke sini, tekan Selesai. Log hasil bisa disalin untuk dilaporkan.",
            fontSize = 12.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(
                onClick = {
                    if (AccTest.begin()) {
                        accRun = true
                        accLog = ""
                        toast("Pengukuran dimulai")
                    } else toast("VPN belum tersambung")
                },
                enabled = !accRun
            ) { Text("Mulai ukur") }
            FilledTonalButton(
                onClick = {
                    accLog = AccTest.end()
                    accRun = false
                },
                enabled = accRun
            ) { Text("Selesai") }
        }
        if (accLog.isNotEmpty()) {
            Text(accLog, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            FilledTonalButton(
                onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("log uji akurasi", accLog))
                    toast("Log disalin")
                },
                Modifier.fillMaxWidth()
            ) { Text("Salin log") }
        }
        HorizontalDivider()

        Text("Speedometer", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Log debug speedometer", Modifier.weight(1f))
            Switch(checked = dbg, onCheckedChange = { Prefs.setDbg(it) })
        }
        Text(
            "Kecepatan dihitung dari byte yang lewat antarmuka TUN tiap 250 ms + EMA. TrafficStats tidak dipakai karena " +
                "menghitung ganda saat VPN aktif. Header IP ikut terhitung, overhead SSH tidak, jadi bisa sedikit " +
                "berbeda dari 1DM+. dBm: nilai di luar -140..-30 ditampilkan \"-\"; Wi-Fi tidak dibaca.",
            fontSize = 12.sp
        )
    }
}
