package com.alfy.tunnel

import android.Manifest
import androidx.compose.ui.semantics.Role
import kotlinx.coroutines.delay
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.flow.first
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.RadioButton
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.layout.height
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private val GREEN = Color(0xFF3DDC84)

@Composable
fun LogLine(l: String) {
    val i = l.indexOf("] ")
    val ts = if (i > 0) l.substring(0, i + 1) else ""
    val msg = if (i > 0) l.substring(i + 2) else l
    val authFail = msg.contains("Auth failed")
    val green = msg.contains("Auth complete") || msg.contains("Connected")
    val bold = green || authFail || msg.startsWith("Response:")
    val pingMs = if (msg.contains("ping", ignoreCase = true) && !msg.contains("gagal", ignoreCase = true))
        Regex("""(\d+(?:\.\d+)?)\s*ms""").find(msg)?.groupValues?.get(1)?.toDoubleOrNull() else null
    val col = when {
        authFail -> Color(0xFFFF1744)
        green -> Color(0xFF00E676)
        pingMs != null -> if (pingMs < 100.0) GREEN else Color(0xFFFF1744)
        else -> Color.Unspecified
    }
    Text(
        buildAnnotatedString {
            if (ts.isNotEmpty()) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(ts) }
                append(" ")
            }
            withStyle(SpanStyle(color = col, fontWeight = if (bold || pingMs != null) FontWeight.Bold else null)) {
                append(msg)
            }
        },
        fontFamily = FontFamily.Monospace, fontSize = 12.sp
    )
}

@Composable
fun HostName(host: String) {
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        Mon.dbmUse(ctx, true)
        onDispose { Mon.dbmUse(ctx, false) }
    }
    val label by Prefs.hostLabel.collectAsState()
    var edit by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clickable { edit = true }.padding(vertical = 4.dp)) {
        Text("Nama (ketuk untuk mengganti)", fontSize = 11.sp, color = Color.Gray)
        Text(
            label.ifBlank { host }, Modifier.padding(top = 2.dp).rainbow(Prefs.P_HOST), color = Color.White,
            fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1
        )
    }
    if (edit) {
        var t by remember { mutableStateOf(label) }
        AlertDialog(
            onDismissRequest = { edit = false },
            title = { Text("Ganti nama tampilan") },
            text = {
                OutlinedTextField(
                    value = t, onValueChange = { t = it }, singleLine = true,
                    label = { Text("Nama bebas. Kosong = otomatis ($host)") }
                )
            },
            confirmButton = { TextButton(onClick = { Prefs.setHostLabel(t.trim()); edit = false }) { Text("Simpan") } },
            dismissButton = { TextButton(onClick = { edit = false }) { Text("Batal") } }
        )
    }
}

@Composable
fun FloatRow(onFloat: (Boolean) -> Unit) {
    val fl by Prefs.floatOn.collectAsState()
    Row(Modifier.fillMaxWidth().height(32.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Mengambang", Modifier.weight(1f), fontSize = 13.sp)
        Switch(checked = fl, onCheckedChange = onFloat, modifier = Modifier.scale(0.7f))
    }
}

private fun permOn(c: Context, k: Int): Boolean = when (k) {
    0 -> (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()
    1 -> c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    2 -> Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)
    else -> Build.VERSION.SDK_INT < 23 ||
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
}

@Composable
fun SettingsScreen(onBack: () -> Unit, toast: (String) -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rs by Prefs.resume.collectAsState()
    val dbg by Prefs.dbg.collectAsState()
    val pkg = ctx.packageName
    fun bump() {
        Prefs.resume.value = Prefs.resume.value + 1
    }

    val notifReq = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump() }
    val locReq = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump() }
    val iconPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { Img.square(ctx, uri, 192) }.getOrNull() }
            if (bmp == null) {
                toast("Gambar tidak bisa dibaca")
            } else if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
                toast("Launcher tidak mendukung shortcut")
            } else {
                val info = ShortcutInfoCompat.Builder(ctx, "alfy_custom")
                    .setShortLabel("AlfyTunnel")
                    .setIcon(IconCompat.createWithBitmap(bmp))
                    .setIntent(Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
                    .build()
                ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
                toast("Konfirmasi penambahan shortcut di layar utama")
            }
        }
    }

    fun rootOr(k: Int, fallback: () -> Unit) {
        scope.launch {
            val ok = withContext(Dispatchers.IO) { RootShell.grant(pkg, k) }
            bump()
            if (!ok) fallback()
        }
    }

    fun go(i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) { toast("Tidak bisa membuka pengaturan") }
    }

    val appDetail = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))

    val names = listOf("Notifikasi", "Speedometer mengambang", "", "Nama tampilan")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("\u2039 Kembali", fontSize = 13.sp) }
            Text("Pengaturan", fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }

        // ===== 1. JARINGAN & KONEKSI =====
        SHead("Jaringan & Koneksi")
        val comp by Prefs.useCompression.collectAsState()
        SSwitch("Enable Compression", "Hemat kuota, tapi bikin HP panas saat streaming. Rekomendasi: OFF.", comp) { Prefs.setCompress(it) }
        val mtu by Prefs.mtu.collectAsState()
        SInput("MTU", mtu.toString(), "Ukuran paket data. Rekomendasi: 1280 (Anti putus).", true) { v -> v.toIntOrNull()?.let { Prefs.setMtu(it.coerceIn(576, 1500)) } }
        val wlk by Prefs.wakeLock.collectAsState()
        SSwitch("WakeLock", "Cegah koneksi mati saat layar dikunci. Rekomendasi: ON.", wlk) { Prefs.setWakeLock(it) }
        val alw by Prefs.alwaysReconnect.collectAsState()
        SSwitch("Always Reconnect", "Paksa nyambung walau sinyal hilang (boros baterai). Rekomendasi: ON.", alw) { Prefs.setAlwaysReconnect(it) }
        SSub("HTTP Ping (Keep-Alive)")
        val pOn by Prefs.pingOn.collectAsState()
        SSwitch("Aktifkan Ping", "Cek koneksi lewat tunnel secara berkala setelah tersambung untuk mendeteksi koneksi mati.", pOn) { Prefs.setPingOn(it) }
        val pUrl by Prefs.pingUrl.collectAsState()
        SInput("URL", pUrl, "Target cek koneksi. Rekomendasi: http://cp.cloudflare.com", false) { v -> if (v.isNotBlank()) Prefs.setPingUrl(v.trim()) }
        val pInt by Prefs.pingInterval.collectAsState()
        SInput("Interval", pInt.toString() + "ms", "Jeda antar cek koneksi. Rekomendasi: 6000 ms (6 detik).", true, pInt.toString()) { v -> v.toIntOrNull()?.let { Prefs.setPingInterval(it.coerceAtLeast(1000)) } }
        val pTo by Prefs.pingTimeout.collectAsState()
        SInput("Timeout", pTo.toString() + "ms", "Batas waktu tunggu balasan. Rekomendasi: 5000 ms.", true, pTo.toString()) { v -> v.toIntOrNull()?.let { Prefs.setPingTimeout(it.coerceAtLeast(1000)) } }
        val pFl by Prefs.pingFails.collectAsState()
        SInput("Auto Reconnect After X Fails", pFl.toString() + "x", "Batas gagal sebelum reconnect. Rekomendasi: 2 kali.", true, pFl.toString()) { v -> v.toIntOrNull()?.let { Prefs.setPingFails(it.coerceAtLeast(0)) } }

        // ===== 2. TAMPILAN (UI) =====
        SHead("Tampilan (UI)")
        val allOn by Prefs.allOn.collectAsState()
        val allSp by Prefs.allSpeed.collectAsState()
        SSwitch("Teks warna-warni", "Semua teks aplikasi berubah warna seperti pelangi.", allOn) { Prefs.setAllOn(it) }
        SSlider("Kecepatan semua teks", allSp, "DIAM", "Seberapa cepat warna pelangi bergerak. 0 = diam.") { Prefs.setAllSpeed(it) }
        val dvOn by Prefs.divOn.collectAsState()
        val dvSp by Prefs.divSpeed.collectAsState()
        SSwitch("Garis pemisah warna-warni", "Garis pemisah di menu utama berjalan warna pelangi. Matikan untuk garis abu-abu polos.", dvOn) { Prefs.setDivOn(it) }
        if (dvOn) SSlider("Kecepatan garis pemisah", dvSp, "DIAM", "Seberapa cepat warna garis bergerak. 0 = diam.") { Prefs.setDivSpeed(it) }
        val nOn by Prefs.notifOn.collectAsState()
        val nSp by Prefs.notifSpeed.collectAsState()
        SSwitch("Notifikasi warna-warni", "Teks notifikasi berwarna pelangi. Matikan agar lebih hemat baterai.", nOn) { Prefs.setNotifOn(it) }
        if (nOn) SSlider("Kecepatan pelangi notifikasi", nSp, "DIAM", "Kecepatan gerak warna di notifikasi. 0 = diam.") { Prefs.setNotifSpeed(it) }
        val cnn by Prefs.cfgNameNotif.collectAsState()
        SSwitch("Config Name In Notification", "Tampilkan nama profil di notifikasi. Rekomendasi: ON.", cnn) { Prefs.setCfgNameNotif(it) }
        SSub("Kecepatan animasi HUD")
        for (i in listOf(1, 3)) {
            val v by Prefs.rb[i].collectAsState()
            SSlider(names[i], v, "DIAM", "Kecepatan warna pelangi pada bagian ini. 0 = diam.") { Prefs.setRb(i, it) }
        }
        SSub("Kecepatan angka HUD")
        val hRise by Prefs.hudRise.collectAsState()
        SInput("Respon saat naik", hRise.toString() + "ms", "Seberapa cepat angka HUD mengikuti saat kecepatan naik. Min ${Prefs.HUD_MIN}, maks ${Prefs.HUD_MAX} (ms). Makin kecil makin cepat, 0 = langsung. Default: 600.", true, hRise.toString()) { v -> v.toIntOrNull()?.let { Prefs.setHudRise(it) } }
        val hFall by Prefs.hudFall.collectAsState()
        SInput("Respon saat turun", hFall.toString() + "ms", "Seberapa cepat angka HUD mengikuti saat kecepatan turun. Min ${Prefs.HUD_MIN}, maks ${Prefs.HUD_MAX} (ms). Makin besar makin pelan/halus, 0 = langsung. Default: 1100.", true, hFall.toString()) { v -> v.toIntOrNull()?.let { Prefs.setHudFall(it) } }
        val slSp by Prefs.slideSp.collectAsState()
        SSlider("Kecepatan panah meluncur", slSp, "MATI", "Kecepatan animasi panah naik/turun pada speedometer. 0 = mati.") { Prefs.setSlideSp(it) }
        val blSp by Prefs.blinkSp.collectAsState()
        SSlider("Kecepatan kedip panah", blSp, "MATI", "Kecepatan panah berkedip saat ada data. 0 = mati.") { Prefs.setBlinkSp(it) }
        val hl by Prefs.hostLabel.collectAsState()
        SInput("Nama tampilan", hl.ifBlank { "-" }, "Nama bebas yang ditampilkan di layar utama. Kosong = otomatis dari server.", false, hl) { Prefs.setHostLabel(it.trim()) }
        val trOn by Prefs.transparent.collectAsState()
        SSwitch("Tampilan transparan", "Kartu dan menu dibuat transparan agar latar terlihat.", trOn) { Prefs.setTransparent(it) }
        SItem("Ikon dari galeri (shortcut)", "Membuat shortcut baru di layar utama dengan gambar pilihanmu.") { iconPick.launch("image/*") }

        // ===== 3. SISTEM & LAINNYA =====
        SHead("Sistem & Lainnya")
        SSub("Izin")
        SPerm("Notifikasi", "Agar status VPN dan tombol Putus/Sambung Ulang tampil.", remember(rs) { permOn(ctx, 0) }) {
            rootOr(0) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) notifReq.launch(Manifest.permission.POST_NOTIFICATIONS)
                else go(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg))
            }
        }
        SPerm("Lokasi (untuk dBm)", "Hanya dipakai membaca kekuatan sinyal seluler (dBm).", remember(rs) { permOn(ctx, 1) }) { rootOr(1) { locReq.launch(Manifest.permission.ACCESS_FINE_LOCATION) } }
        SPerm("Overlay (speedometer mengambang)", "Agar speedometer bisa melayang di atas aplikasi lain.", remember(rs) { permOn(ctx, 2) }) {
            rootOr(2) { go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg"))) }
        }
        SPerm("Baterai (tanpa dibatasi)", "Agar sistem tidak mematikan VPN saat di latar belakang.", remember(rs) { permOn(ctx, 3) }) {
            rootOr(3) { go(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        SItem("Paksa Semua Izin (Root)", "Beri semua izin di atas sekaligus lewat root (su).") {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { RootShell.grantAll(pkg) }
                bump()
                toast(if (ok) "Semua izin dipaksa via root" else "Root tidak tersedia / ditolak")
            }
        }
        SItem("Aktifkan Always-On VPN", "Buka setelan VPN Android, pilih AlfyTunnel lalu aktifkan 'VPN selalu aktif'.") {
            go(Intent(Settings.ACTION_VPN_SETTINGS))
        }
        SItem("Buka pengaturan aplikasi", "Buka halaman detail aplikasi di pengaturan sistem.") { go(appDetail) }

        SSub("Log")
        SSwitch("Mode Debug", "Tampilkan log internal (dbg speed & Watchdog). Default: OFF.", dbg) { Prefs.setDbg(it) }

        SSub("Uji akurasi")
        val use4g by Prefs.use4GLabel.collectAsState()
        SSwitch("Label 4G", "Tampilkan LTE sebagai 4G.", use4g) { Prefs.setUse4GLabel(it) }
        val noRoot by Prefs.noRoot.collectAsState()
        SSwitch("Mode tanpa root", "Paksa hitungan kecepatan internal (tanpa kernel root).", noRoot) { Prefs.setNoRoot(it) }
        var accRun by remember { mutableStateOf(AccTest.running()) }
        var accLog by remember { mutableStateOf("") }
        SItem("Mulai ukur", "Sambungkan VPN, unduh file yang ukurannya kamu tahu, lalu tekan Selesai.") {
            if (!accRun) {
                if (AccTest.begin()) { accRun = true; accLog = ""; toast("Pengukuran dimulai") } else toast("VPN belum tersambung")
            }
        }
        SItem("Selesai", if (accRun) "Pengukuran sedang berjalan." else "Belum mulai. Tekan Mulai ukur dulu.") {
            if (accRun) { accLog = AccTest.end(); accRun = false }
        }
        if (accLog.isNotEmpty()) {
            Text(accLog, Modifier.padding(horizontal = 16.dp, vertical = 4.dp), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            SItem("Salin log", "Salin hasil uji ke clipboard untuk dilaporkan.") {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("log uji akurasi", accLog))
                toast("Log disalin")
            }
        }
    }
}

@Composable
private fun SHead(t: String) {
    Text(t, Modifier.padding(start = 16.dp, top = 14.dp, bottom = 2.dp), fontSize = 12.sp,
        fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun SSub(t: String) {
    Text(t.uppercase(), Modifier.padding(start = 16.dp, top = 8.dp, bottom = 0.dp), fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
}

@Composable
private fun SItem(title: String, sub: String, trailing: @Composable (() -> Unit)? = null, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp)
            if (sub.isNotEmpty()) Text(sub, fontSize = 10.sp, color = Color.Gray)
        }
        if (trailing != null) trailing()
    }
}

@Composable
private fun SSwitch(title: String, sub: String, v: Boolean, onChange: (Boolean) -> Unit) {
    SItem(title, sub, {
        Switch(checked = v, onCheckedChange = onChange, modifier = Modifier.scale(0.7f))
    }, { onChange(!v) })
}

@Composable
private fun SSlider(title: String, v: Float, zero: String, desc: String, onChange: (Float) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 2.dp)) {
        Text(title + ": " + if (v <= 0f) zero else v.roundToInt().toString(), fontSize = 14.sp)
        Slider(
            value = v, onValueChange = { onChange(it.roundToInt().toFloat()) },
            valueRange = 0f..10f, steps = 9, modifier = Modifier.height(24.dp)
        )
        Text(desc, fontSize = 10.sp, color = Color.Gray)
    }
}

@Composable
private fun SInput(title: String, value: String, desc: String, numeric: Boolean, init: String = value, onSave: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    var t by remember { mutableStateOf("") }
    SItem(title, desc, {
        Text(value, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
    }, { t = init; open = true })
    if (open) AlertDialog(
        onDismissRequest = { open = false },
        title = { Text(title, fontSize = 15.sp) },
        text = {
            OutlinedTextField(
                value = t,
                onValueChange = { t = if (numeric) it.filter { c -> c.isDigit() }.take(6) else it },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = if (numeric) androidx.compose.ui.text.input.KeyboardType.Number
                    else androidx.compose.ui.text.input.KeyboardType.Uri
                )
            )
        },
        confirmButton = { TextButton(onClick = { onSave(t); open = false }) { Text("Simpan", fontSize = 13.sp) } },
        dismissButton = { TextButton(onClick = { open = false }) { Text("Batal", fontSize = 13.sp) } }
    )
}

@Composable
private fun SPerm(title: String, desc: String, on: Boolean, onClick: () -> Unit) {
    SItem(title, desc, {
        Text(if (on) "ON" else "OFF", fontSize = 11.sp, fontWeight = FontWeight.Bold,
            color = if (on) GREEN else MaterialTheme.colorScheme.error)
    }, { if (!on) onClick() })
}

/** Pengaturan "Bagikan Koneksi (Hotspot VPN)" - dibuka dari menu Titik Tiga. */
@Composable
fun HotspotDialog(onDismiss: () -> Unit, toast: (String) -> Unit) {
    val ctx = LocalContext.current
    val pkg = ctx.packageName
    fun go(i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) { toast("Tidak bisa membuka pengaturan") }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
        val hs by Prefs.hotspot.collectAsState()
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Bagikan Koneksi VPN (Hotspot)", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Switch(checked = hs, onCheckedChange = { v ->
                        Prefs.setHotspot(v)
                        if (v) {
                            if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(ctx)) {
                                toast("Izinkan ubah pengaturan sistem untuk tethering")
                                go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$pkg")))
                            }
                            toast("Sambungkan ulang VPN agar berlaku")
                        }
                    })
                }
                val hm by Prefs.hotspotMode.collectAsState()
                var lip by remember { mutableStateOf("-") }
                LaunchedEffect(Unit) {
                    while (true) {
                        AppFg.fg.first { it }
                        lip = withContext(Dispatchers.IO) { HttpProxyServer.localIp() }
                        delay(2000)
                    }
                }
                val opts = listOf(
                    Triple(0, "Mode Root (Otomatis)", "Semua perangkat di Hotspot langsung dapat internet VPN."),
                    Triple(1, "Mode Non-Root (Proxy HTTP)", "Tanpa root. Perangkat yang connect ke Hotspot harus mengatur Proxy Wi-Fi manual.")
                )
                for ((id, ttl, desc) in opts) {
                    Row(
                        Modifier.fillMaxWidth().selectable(
                            selected = hm == id,
                            onClick = { Prefs.setHotspotMode(id); toast("Sambungkan ulang VPN agar berlaku") },
                            role = Role.RadioButton
                        ),
                        verticalAlignment = Alignment.Top
                    ) {
                        RadioButton(selected = hm == id, onClick = null, modifier = Modifier.padding(top = 2.dp, end = 8.dp))
                        Column {
                            Text(ttl, fontWeight = FontWeight.Bold)
                            Text(desc, fontSize = 12.sp)
                        }
                    }
                }
                if (hm == 1) {
                    Text(
                        "Cara Pakai: Nyalakan Hotspot. Di HP penerima, buka Setelan Wi-Fi -> Ubah Jaringan -> Proxy Manual -> " +
                            "Isi IP: $lip dan Port: ${HttpProxyServer.PORT}.",
                        fontSize = 13.sp,
                        color = Color(0xFFFFD600)
                    )
                }
                FilledTonalButton(
                    onClick = {
                        val i = Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")
                        try { ctx.startActivity(i) } catch (e: Exception) {
                            go(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                        }
                    },
                    Modifier.fillMaxWidth()
                ) { Text("Buka pengaturan Hotspot") }
            }
        }
            }
        }
    )
}
