package com.alfy.tunnel

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.CellIdentityNr
import android.telephony.TelephonyCallback
import android.telephony.PhoneStateListener
import android.telephony.SignalStrength
import android.telephony.TelephonyManager

/**
 * Pembaca sinyal TANPA dumpsys (logika dari SpeedMeter.SignalReader.readNoRoot).
 * Band & dBm dibaca dari CellInfo hasil scan BARU modem (requestCellInfoUpdate) milik SIM data aktif
 * (default data subscription), hanya sel primary-serving yang terdaftar. Tidak ada cache / data basi.
 */
object SignalReader {
    class Info(val dbm: Int?, val band: String?, val type: String)

    @Volatile private var cbDbm: Int? = null
    @Volatile private var cbCells: List<CellInfo>? = null
    private var cbTm: TelephonyManager? = null
    private var cbObj: Any? = null
    @Volatile private var cbFull = false
    private val cbExec = java.util.concurrent.Executor { it.run() }

    /** Daftarkan TelephonyCallback (API 31+) / PhoneStateListener (lama) pada TelephonyManager SIM data aktif. */
    @android.annotation.SuppressLint("MissingPermission", "NewApi")
    @Synchronized
    fun start(c: Context) {
        if (cbObj != null) return
        val tm = dataTm(c) ?: return
        cbFull = false
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.SignalStrengthsListener, TelephonyCallback.CellInfoListener {
                    override fun onSignalStrengthsChanged(ss: SignalStrength) {
                        cbDbm = ss.cellSignalStrengths.map { it.dbm }.firstOrNull { ok(it) }
                    }
                    override fun onCellInfoChanged(cellInfo: MutableList<CellInfo>) { cbCells = cellInfo }
                }
                try { tm.registerTelephonyCallback(cbExec, cb); cbFull = true } catch (e: SecurityException) {
                    // Tanpa izin READ_PHONE_STATE / lokasi: pakai listener sinyal saja
                    val cb2 = object : TelephonyCallback(), TelephonyCallback.SignalStrengthsListener {
                        override fun onSignalStrengthsChanged(ss: SignalStrength) {
                            cbDbm = ss.cellSignalStrengths.map { it.dbm }.firstOrNull { ok(it) }
                        }
                    }
                    tm.registerTelephonyCallback(cbExec, cb2)
                    cbTm = tm; cbObj = cb2; return
                }
                cbTm = tm; cbObj = cb
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onSignalStrengthsChanged(ss: SignalStrength?) {
                        if (ss != null) cbDbm = try { if (Build.VERSION.SDK_INT >= 29) ss.cellSignalStrengths.map { it.dbm }.firstOrNull { ok(it) } else null } catch (e: Throwable) { null }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onCellInfoChanged(cellInfo: MutableList<CellInfo>?) { if (cellInfo != null) cbCells = cellInfo }
                }
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS or PhoneStateListener.LISTEN_CELL_INFO)
                cbTm = tm; cbObj = l
            }
        } catch (e: Throwable) { cbObj = null; cbTm = null }
    }

    @android.annotation.SuppressLint("NewApi")
    @Synchronized
    fun stop() {
        val tm = cbTm; val o = cbObj
        cbObj = null; cbTm = null; cbDbm = null; cbCells = null
        if (tm == null || o == null) return
        try {
            if (Build.VERSION.SDK_INT >= 31 && o is TelephonyCallback) tm.unregisterTelephonyCallback(o)
            else if (o is PhoneStateListener) { @Suppress("DEPRECATION") tm.listen(o, PhoneStateListener.LISTEN_NONE) }
        } catch (e: Throwable) { }
    }

    fun read(c: Context): Info {
        if (cbObj != null && !cbFull && hasPhone(c)) stop()
        start(c)
        val tm = dataTm(c) ?: return Info(null, "LTE", "")
        var d: Int? = null
        var b: String? = null
        try {
            val ci = servingCell(c, tm)
            if (ci != null) { d = cellDbm(ci)?.takeIf { ok(it) }; b = bandOf(ci) }
        } catch (e: Throwable) { }
        if (b == null) {
            try {
                val r = readRootDumpsys()
                if (r != null) { b = r.second; if (d == null) d = r.first }
            } catch (e: Throwable) { }
        }
        if (d == null) d = cbDbm
        if (d == null) d = try { signalDbm(tm) } catch (e: Throwable) { null }
        val type = typeOf(c, tm)
        return Info(d, b ?: type.ifEmpty { "LTE" }, type)
    }

    // ---------------- Jalur ROOT (port dari SpeedMeter.SignalReader.read/parse) ----------------
    @Volatile private var rootFailUntil = 0L

    private fun runSu(cmd: String): String? {
        var out: String? = null
        val t = Thread {
            var p: Process? = null
            try {
                p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                out = p.inputStream.bufferedReader().readText()
                p.waitFor()
            } catch (e: Throwable) { } finally { try { p?.destroy() } catch (e: Throwable) { } }
        }
        t.isDaemon = true
        t.start()
        t.join(5000)
        if (t.isAlive) { t.interrupt(); return null }
        return out
    }

    private fun first(t: String, re: Regex): String? = re.find(t)?.groupValues?.getOrNull(1)

    private fun registeredSegments(t: String): List<String> {
        val out = ArrayList<String>()
        var from = 0
        while (true) {
            val i = t.indexOf("mRegistered=", from)
            if (i < 0) break
            val next = t.indexOf("mRegistered=", i + 12)
            val end = if (next < 0) minOf(t.length, i + 3000) else minOf(next, i + 3000)
            if (t.startsWith("mRegistered=YES", i)) out.add(t.substring(i, end))
            from = i + 12
        }
        return out.sortedBy { if (it.contains("CellIdentityLte")) 0 else 1 }
    }

    /** Band dari output dumpsys (mBands / mBand / earfcn / mEarfcn), segmen mRegistered=YES dahulu. */
    private fun parseBand(t: String): String? {
        for (seg in registeredSegments(t)) {
            val nr = seg.contains("CellIdentityNr") || seg.contains("CellInfoNr")
            val b = first(seg, Regex("""mBands\s*=\s*\[\s*(\d+)"""))?.toIntOrNull()
                ?: first(seg, Regex("""mBand=(\d+)"""))?.toIntOrNull()
            if (b != null && b in 1..127) return label(b, nr)
            if (!nr) {
                val ch = first(seg, Regex("""[mM]?[eE]arfcn=(\d+)"""))?.toIntOrNull()
                val eb = if (ch != null) earfcnToBand(ch) else null
                if (eb != null) return eb
            }
        }
        val raw = first(t, Regex("""mBand=(\d+)"""))?.toIntOrNull()
        if (raw != null && raw in 1..99) return label(raw, false)
        val ch = first(t, Regex("""earfcn=(\d+)""")) ?.toIntOrNull()
            ?: first(t, Regex("""mEarfcn=(\d+)"""))?.toIntOrNull()
        return if (ch != null && ch > 0) earfcnToBand(ch) else null
    }

    private fun parseDbm(t: String): Int? {
        fun v(s: String?): Int? { val i = s?.toIntOrNull() ?: return null; return if (i == Int.MAX_VALUE || i > 0 || i < -200) null else i }
        var from = 0
        while (true) {
            val i = t.indexOf("SignalStrength:", from)
            if (i < 0) break
            val seg = t.substring(i, minOf(t.length, i + 1500))
            val r = v(first(seg, Regex("""\brsrp=(-?\d+)"""))) ?: v(first(seg, Regex("""ssRsrp=(-?\d+)""")))
            if (r != null) return r
            from = i + 15
        }
        for (seg in registeredSegments(t)) {
            val r = v(first(seg, Regex("""\brsrp=(-?\d+)"""))) ?: v(first(seg, Regex("""ssRsrp=(-?\d+)""")))
            if (r != null) return r
        }
        return v(first(t, Regex("""mDbm=(-?\d+)"""))) ?: v(first(t, Regex("""\brsrp=(-?\d+)""")))
    }

    /** Fallback root: su -c "dumpsys telephony.registry; dumpsys phone". Pair(dbm, band) atau null. */
    fun readRootDumpsys(): Pair<Int?, String?>? {
        if (System.currentTimeMillis() < rootFailUntil) return null
        val txt = runSu("dumpsys telephony.registry 2>/dev/null; dumpsys phone 2>/dev/null")
        if (txt.isNullOrBlank()) { rootFailUntil = System.currentTimeMillis() + 60000L; return null }
        return Pair(parseDbm(txt), parseBand(txt))
    }

    private fun ok(v: Int) = v in -140..-30

    private fun hasPhone(c: Context) = Build.VERSION.SDK_INT < 23 ||
        c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    /** TelephonyManager polos (sama seperti SpeedMeter). */
    private fun dataTm(c: Context): TelephonyManager? =
        c.applicationContext.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager

    private val bandMhz = mapOf(
        1 to 2100, 2 to 1900, 3 to 1800, 4 to 1700, 5 to 850, 7 to 2600, 8 to 900, 12 to 700, 13 to 700, 17 to 700,
        20 to 800, 25 to 1900, 26 to 850, 28 to 700, 38 to 2600, 39 to 1900, 40 to 2300, 41 to 2500, 66 to 2100
    )

    // EARFCN (downlink) -> [band, awal, akhir]
    private val earfcnTbl = arrayOf(
        intArrayOf(1, 0, 599), intArrayOf(2, 600, 1199), intArrayOf(3, 1200, 1949), intArrayOf(4, 1950, 2399),
        intArrayOf(5, 2400, 2649), intArrayOf(7, 2750, 3449), intArrayOf(8, 3450, 3799), intArrayOf(12, 5010, 5179),
        intArrayOf(13, 5180, 5279), intArrayOf(17, 5730, 5849), intArrayOf(20, 6150, 6449), intArrayOf(25, 8040, 8689),
        intArrayOf(26, 8690, 9039), intArrayOf(28, 9210, 9659), intArrayOf(38, 37750, 38249), intArrayOf(39, 38250, 38649),
        intArrayOf(40, 38650, 39649), intArrayOf(41, 39650, 41589), intArrayOf(66, 66436, 67335)
    )

    /** EARFCN -> nama band, contoh 100 -> "Band 1 (2100)". */
    fun earfcnToBand(e: Int): String? {
        val r = earfcnTbl.firstOrNull { e in it[1]..it[2] } ?: return null
        val mhz = bandMhz[r[0]]
        return "Band ${r[0]}" + (if (mhz != null) " ($mhz)" else "")
    }

    /** NR-ARFCN -> band n (rentang umum). */
    fun nrArfcnToBand(a: Int): String? = when (a) {
        in 151600..160600 -> "Band n28 (700)"
        in 173800..178800 -> "Band n5 (850)"
        in 361000..376000 -> "Band n3 (1800)"
        in 422000..434000 -> "Band n1 (2100)"
        in 524000..538000 -> "Band n7 (2600)"
        in 460000..480000 -> "Band n40 (2300)"
        in 499200..537999 -> "Band n41 (2500)"
        in 620000..653333 -> "Band n78 (3500)"
        else -> null
    }

    private fun label(b: Int, nr: Boolean): String {
        val f = bandMhz[b]
        val name = if (nr) "Band n$b" else "Band $b"
        return if (f != null && !nr) "$name ($f)" else name
    }

    private fun hasLoc(c: Context) = Build.VERSION.SDK_INT < 23 ||
        c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Minta modem memindai sel baru (Android 10+). allCellInfo biasa hanya cache lama. Maks 2,5 detik. */
    @android.annotation.SuppressLint("MissingPermission", "NewApi")
    private fun freshCells(tm: TelephonyManager): List<CellInfo>? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val latch = java.util.concurrent.CountDownLatch(1)
            val res = java.util.concurrent.atomic.AtomicReference<List<CellInfo>?>(null)
            tm.requestCellInfoUpdate(java.util.concurrent.Executor { it.run() }, object : TelephonyManager.CellInfoCallback() {
                override fun onCellInfo(cellInfo: MutableList<CellInfo>) { res.set(cellInfo); latch.countDown() }
                override fun onError(errorCode: Int, detail: Throwable?) { latch.countDown() }
            })
            latch.await(2500, java.util.concurrent.TimeUnit.MILLISECONDS)
            res.get()
        } catch (e: Throwable) { null }
    }

    /** Sel terdaftar (primary serving) milik SIM data aktif dari scan baru; LTE didahulukan. Null bila tidak bisa. */
    @android.annotation.SuppressLint("MissingPermission", "NewApi")
    private fun servingCell(c: Context, tm: TelephonyManager): CellInfo? {
        if (!hasLoc(c)) return null
        val cells = (freshCells(tm)?.takeIf { it.isNotEmpty() } ?: cbCells?.takeIf { it.isNotEmpty() } ?: try { tm.allCellInfo } catch (e: Throwable) { null }) ?: return null
        val reg = cells.filter { it.isRegistered }
        if (reg.isEmpty()) return null
        val sorted = reg.sortedBy { if (it is CellInfoLte) 0 else 1 }
        // Utamakan sel yang band-nya terbaca (jangan berhenti di sel tanpa band -> Band jadi "-")
        return sorted.firstOrNull { bandOf(it) != null } ?: sorted.firstOrNull()
    }

    @android.annotation.SuppressLint("NewApi")
    private fun bandOf(ci: CellInfo): String? {
        if (ci is CellInfoLte) {
            val id = ci.cellIdentity
            if (Build.VERSION.SDK_INT >= 30) {
                val b = id.bands
                if (b.isNotEmpty() && b[0] in 1..127) return label(b[0], false)
            }
            val ch = id.earfcn
            if (ch > 0 && ch != Int.MAX_VALUE) return earfcnToBand(ch)
        } else if (Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr) {
            val id = ci.cellIdentity as? CellIdentityNr ?: return null
            if (Build.VERSION.SDK_INT >= 30) {
                val b = id.bands
                if (b.isNotEmpty() && b[0] in 1..512) return "Band n${b[0]}"
            }
            val ch = id.nrarfcn
            if (ch > 0 && ch != Int.MAX_VALUE) return nrArfcnToBand(ch)
        }
        return null
    }

    private fun cellDbm(ci: CellInfo): Int? = when {
        ci is CellInfoLte -> ci.cellSignalStrength.dbm
        ci is CellInfoWcdma -> ci.cellSignalStrength.dbm
        ci is CellInfoGsm -> ci.cellSignalStrength.dbm
        ci is CellInfoCdma -> ci.cellSignalStrength.dbm
        Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr -> ci.cellSignalStrength.dbm
        else -> null
    }

    private fun signalDbm(tm: TelephonyManager): Int? {
        if (Build.VERSION.SDK_INT < 29) return null
        return tm.signalStrength?.cellSignalStrengths?.map { it.dbm }?.firstOrNull { ok(it) }
    }

    private fun nt(t: Int): String = when (t) {
        TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
        TelephonyManager.NETWORK_TYPE_NR -> "5G"
        TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_EVDO_0, TelephonyManager.NETWORK_TYPE_EVDO_A,
        TelephonyManager.NETWORK_TYPE_EVDO_B, TelephonyManager.NETWORK_TYPE_TD_SCDMA -> "3G"
        TelephonyManager.NETWORK_TYPE_HSPAP -> "H+"
        TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS, TelephonyManager.NETWORK_TYPE_GSM -> "2G"
        else -> ""
    }

    /** Fallback bertingkat: dataNetworkType -> getNetworkType -> ServiceState (hanya bila IN_SERVICE) -> CellInfo. */
    @android.annotation.SuppressLint("MissingPermission", "NewApi")
    private fun typeOf(c: Context, tm: TelephonyManager): String {
        try { val r = nt(tm.dataNetworkType); if (r.isNotEmpty()) return r } catch (e: Throwable) { }
        try {
            @Suppress("DEPRECATION")
            val r = nt(tm.networkType); if (r.isNotEmpty()) return r
        } catch (e: Throwable) { }
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val ss = tm.serviceState
                if (ss != null && ss.state == android.telephony.ServiceState.STATE_IN_SERVICE) {
                    @Suppress("DEPRECATION")
                    val r = nt(tm.networkType); if (r.isNotEmpty()) return r
                }
            }
        } catch (e: Throwable) { }
        if (hasLoc(c)) {
            try {
                val ci = tm.allCellInfo?.firstOrNull { it.isRegistered }
                return when {
                    ci is CellInfoLte -> "LTE"
                    Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr -> "5G"
                    ci is CellInfoWcdma -> "3G"
                    ci is CellInfoGsm -> "2G"
                    else -> ""
                }
            } catch (e: Throwable) { }
        }
        return ""
    }
}
