package com.alfy.tunnel

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager

/**
 * Pembaca sinyal.
 * - Root: `su -c "dumpsys telephony.registry"` -> dBm dari `SignalStrength:` (rsrp/rssi) dan Band dari EARFCN.
 * - Non-Root: TelephonyManager standar -> dBm + tipe jaringan (LTE/4G, dst.).
 */
object SignalReader {
    class Info(val dbm: Int?, val band: String?, val type: String)

    fun read(c: Context): Info {
        var d: Int? = try { telephonyDbm(c) } catch (e: Throwable) { null }
        var b: String? = null
        if (RootShell.available()) {
            val r = rootRead()
            b = r.first
            if (r.second != null) d = r.second
        }
        val tm = c.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        return Info(d, b, if (tm == null) "" else typeOf(c, tm))
    }

    private fun ok(v: Int) = v in -140..-30

    // ---------------- Root ----------------
    private val bandMhz = mapOf(
        1 to 2100, 2 to 1900, 3 to 1800, 4 to 1700, 5 to 850, 7 to 2600, 8 to 900, 12 to 700, 13 to 700, 17 to 700,
        20 to 800, 25 to 1900, 26 to 850, 28 to 700, 38 to 2600, 39 to 1900, 40 to 2300, 41 to 2500, 66 to 2100
    )

    // EARFCN (downlink) -> [band, awal, akhir]
    private val earfcnTbl = arrayOf(
        intArrayOf(1, 0, 599), intArrayOf(2, 600, 1199), intArrayOf(3, 1200, 1949), intArrayOf(4, 1950, 2399),
        intArrayOf(5, 2400, 2649), intArrayOf(7, 2750, 3449), intArrayOf(8, 3450, 3799), intArrayOf(12, 5010, 5179),
        intArrayOf(13, 5180, 5279), intArrayOf(17, 5730, 5849), intArrayOf(20, 6150, 6449), intArrayOf(25, 8040, 8689),
        intArrayOf(26, 8690, 9039), intArrayOf(28, 9210, 9659), intArrayOf(38, 37750, 38249), intArrayOf(39, 38250, 38649),
        intArrayOf(40, 38650, 39649), intArrayOf(41, 39650, 41589), intArrayOf(66, 66436, 67335)
    )

    /** EARFCN -> nama band, contoh 100 -> "Band 1 (2100)". */
    fun earfcnToBand(e: Int): String? {
        val r = earfcnTbl.firstOrNull { e in it[1]..it[2] } ?: return null
        val mhz = bandMhz[r[0]]
        return "Band ${r[0]}" + (if (mhz != null) " ($mhz)" else "")
    }

    /** NR-ARFCN -> band n (rentang umum). */
    fun nrArfcnToBand(a: Int): String? = when (a) {
        in 151600..160600 -> "Band n28 (700)"
        in 173800..178800 -> "Band n5 (850)"
        in 361000..376000 -> "Band n3 (1800)"
        in 422000..434000 -> "Band n1 (2100)"
        in 524000..538000 -> "Band n7 (2600)"
        in 460000..480000 -> "Band n40 (2300)"
        in 499200..537999 -> "Band n41 (2500)"
        in 620000..653333 -> "Band n78 (3500)"
        else -> null
    }

    private fun first(t: String, re: Regex): String? = re.find(t)?.groupValues?.getOrNull(1)

    private fun valid(v: String?): Int? {
        val i = v?.toIntOrNull() ?: return null
        return if (i == Int.MAX_VALUE || i > 0 || i < -200) null else i
    }

    private fun label(b: Int, nr: Boolean): String {
        val f = bandMhz[b]
        val name = if (nr) "Band n$b" else "Band $b"
        return if (f != null && !nr) "$name ($f)" else name
    }

    /** Potongan teks tiap sel `mRegistered=YES` (LTE didahulukan). */
    private fun registeredSegments(t: String): List<String> {
        val out = ArrayList<String>()
        var from = 0
        while (true) {
            val i = t.indexOf("mRegistered=", from)
            if (i < 0) break
            val next = t.indexOf("mRegistered=", i + 12)
            val end = if (next < 0) minOf(t.length, i + 3000) else minOf(next, i + 3000)
            if (t.startsWith("mRegistered=YES", i)) out.add(t.substring(i, end))
            from = i + 12
        }
        return out.sortedBy { if (it.contains("CellIdentityLte")) 0 else 1 }
    }

    /** Pair(band, dBm) dari `dumpsys telephony.registry; dumpsys phone` (cara kerja SpeedMeter). */
    private fun rootRead(): Pair<String?, Int?> {
        val t = RootShell.exec("dumpsys telephony.registry 2>/dev/null; dumpsys phone 2>/dev/null") ?: return Pair(null, null)
        val regs = registeredSegments(t)

        // ---- dBm: objek `SignalStrength:` dulu (selalu diperbarui sistem)
        var dbm: Int? = null
        var from = 0
        while (dbm == null) {
            val i = t.indexOf("SignalStrength:", from)
            if (i < 0) break
            val seg = t.substring(i, minOf(t.length, i + 1500))
            dbm = valid(first(seg, Regex("""\brsrp=(-?\d+)""")))
                ?: valid(first(seg, Regex("""ssRsrp=(-?\d+)""")))
                ?: valid(first(seg, Regex("""\brssi=(-?\d+)""")))
            from = i + 15
        }
        if (dbm == null) for (seg in regs) {
            dbm = valid(first(seg, Regex("""\brsrp=(-?\d+)""")))
                ?: valid(first(seg, Regex("""ssRsrp=(-?\d+)""")))
            if (dbm != null) break
        }
        if (dbm == null) {
            val mDbm = Regex("""mDbm=(-?\d+)""")
            dbm = valid(first(t, mDbm)) ?: valid(first(t, Regex("""\brsrp=(-?\d+)""")))
                ?: valid(mDbm.findAll(t).lastOrNull()?.groupValues?.get(1))
        }

        // ---- Band: dari sel terdaftar (mBands / mBand / EARFCN), lalu dari seluruh teks
        var band: String? = null
        for (seg in regs) {
            val nr = seg.contains("CellIdentityNr") || seg.contains("CellInfoNr")
            val b = first(seg, Regex("""mBands\s*=\s*\[\s*(\d+)"""))?.toIntOrNull()
                ?: first(seg, Regex("""mBand=(\d+)"""))?.toIntOrNull()
            if (b != null && b in 1..127) { band = label(b, nr); break }
            if (!nr) {
                val ch = first(seg, Regex("""[mM]?[eE]arfcn=(\d+)"""))?.toIntOrNull()
                val s2 = if (ch != null) earfcnToBand(ch) else null
                if (s2 != null) { band = s2; break }
            } else {
                val ch = first(seg, Regex("""mNrArfcn=(\d+)"""))?.toIntOrNull()
                val s2 = if (ch != null) nrArfcnToBand(ch) else null
                if (s2 != null) { band = s2; break }
            }
        }
        if (band == null) {
            val raw = first(t, Regex("""mBand=(\d+)"""))?.toIntOrNull()
            if (raw != null && raw in 1..99) band = label(raw, false)
            else {
                val b = first(t, Regex("""mBands\s*=\s*\[\s*(\d+)"""))?.toIntOrNull()
                if (b != null && b in 1..127) band = label(b, false)
                else {
                    val ch = (first(t, Regex("""[mM]?[eE]arfcn=(\d+)"""))?.toIntOrNull())?.takeIf { it > 0 && it != Int.MAX_VALUE }
                    if (ch != null) band = earfcnToBand(ch)
                }
            }
        }
        return Pair(band, dbm)
    }

    // ---------------- Non-Root (TelephonyManager) ----------------
    private fun cellDbm(ci: CellInfo): Int? = when {
        ci is CellInfoLte -> ci.cellSignalStrength.dbm
        ci is CellInfoWcdma -> ci.cellSignalStrength.dbm
        ci is CellInfoGsm -> ci.cellSignalStrength.dbm
        ci is CellInfoCdma -> ci.cellSignalStrength.dbm
        Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr -> ci.cellSignalStrength.dbm
        else -> null
    }

    private fun telephonyDbm(c: Context): Int? {
        val tm = c.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return null
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val v = tm.signalStrength?.cellSignalStrengths?.map { it.dbm }?.firstOrNull { ok(it) }
                if (v != null) return v
            } catch (e: Throwable) { }
        }
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                @Suppress("MissingPermission")
                val l = tm.allCellInfo
                val v = l?.filter { it.isRegistered }?.mapNotNull { cellDbm(it) }?.firstOrNull { ok(it) }
                if (v != null) return v
            } catch (e: Throwable) { }
        }
        return null
    }

    private fun typeOf(c: Context, tm: TelephonyManager): String {
        try {
            @Suppress("MissingPermission")
            val t = tm.dataNetworkType
            val r = when (t) {
                TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
                TelephonyManager.NETWORK_TYPE_NR -> "5G"
                TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA,
                TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_EVDO_0, TelephonyManager.NETWORK_TYPE_EVDO_A,
                TelephonyManager.NETWORK_TYPE_EVDO_B, TelephonyManager.NETWORK_TYPE_TD_SCDMA -> "3G"
                TelephonyManager.NETWORK_TYPE_HSPAP -> "H+"
                TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS, TelephonyManager.NETWORK_TYPE_GSM -> "2G"
                else -> ""
            }
            if (r.isNotEmpty()) return r
        } catch (e: Throwable) { }
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                @Suppress("MissingPermission")
                val ci = tm.allCellInfo?.firstOrNull { it.isRegistered }
                return when {
                    ci is CellInfoLte -> "LTE"
                    Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr -> "5G"
                    ci is CellInfoWcdma -> "3G"
                    ci is CellInfoGsm -> "2G"
                    else -> ""
                }
            } catch (e: Throwable) { }
        }
        return ""
    }
}
