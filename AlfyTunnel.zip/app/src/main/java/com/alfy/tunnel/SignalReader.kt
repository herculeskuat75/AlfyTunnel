package com.alfy.tunnel

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.CellIdentityNr
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

/**
 * Pembaca sinyal TANPA dumpsys (logika dari SpeedMeter.SignalReader.readNoRoot).
 * Band & dBm dibaca dari CellInfo hasil scan BARU modem (requestCellInfoUpdate) milik SIM data aktif
 * (default data subscription), hanya sel primary-serving yang terdaftar. Tidak ada cache / data basi.
 */
object SignalReader {
    class Info(val dbm: Int?, val band: String?, val type: String)

    fun read(c: Context): Info {
        val tm = dataTm(c) ?: return Info(null, null, "")
        var d: Int? = null
        var b: String? = null
        try {
            val ci = servingCell(c, tm)
            if (ci != null) { d = cellDbm(ci)?.takeIf { ok(it) }; b = bandOf(ci) }
        } catch (e: Throwable) { }
        if (d == null) d = try { signalDbm(tm) } catch (e: Throwable) { null }
        return Info(d, b, typeOf(c, tm))
    }

    private fun ok(v: Int) = v in -140..-30

    /** TelephonyManager milik SIM yang dipakai untuk data seluler (bukan slot lain). */
    private fun dataTm(c: Context): TelephonyManager? {
        var tm = c.applicationContext.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return null
        try {
            val sub = SubscriptionManager.getDefaultDataSubscriptionId()
            if (Build.VERSION.SDK_INT >= 24 && sub != SubscriptionManager.INVALID_SUBSCRIPTION_ID) tm = tm.createForSubscriptionId(sub)
        } catch (e: Throwable) { }
        return tm
    }

    private val bandMhz = mapOf(
        1 to 2100, 2 to 1900, 3 to 1800, 4 to 1700, 5 to 850, 7 to 2600, 8 to 900, 12 to 700, 13 to 700, 17 to 700,
        20 to 800, 25 to 1900, 26 to 850, 28 to 700, 38 to 2600, 39 to 1900, 40 to 2300, 41 to 2500, 66 to 2100
    )

    // EARFCN (downlink) -> [band, awal, akhir]
    private val earfcnTbl = arrayOf(
        intArrayOf(1, 0, 599), intArrayOf(2, 600, 1199), intArrayOf(3, 1200, 1949), intArrayOf(4, 1950, 2399),
        intArrayOf(5, 2400, 2649), intArrayOf(7, 2750, 3449), intArrayOf(8, 3450, 3799), intArrayOf(12, 5010, 5179),
        intArrayOf(13, 5180, 5279), intArrayOf(17, 5730, 5849), intArrayOf(20, 6150, 6449), intArrayOf(25, 8040, 8689),
        intArrayOf(26, 8690, 9039), intArrayOf(28, 9210, 9659), intArrayOf(38, 37750, 38249), intArrayOf(39, 38250, 38649),
        intArrayOf(40, 38650, 39649), intArrayOf(41, 39650, 41589), intArrayOf(66, 66436, 67335)
    )

    /** EARFCN -> nama band, contoh 100 -> "Band 1 (2100)". */
    fun earfcnToBand(e: Int): String? {
        val r = earfcnTbl.firstOrNull { e in it[1]..it[2] } ?: return null
        val mhz = bandMhz[r[0]]
        return "Band ${r[0]}" + (if (mhz != null) " ($mhz)" else "")
    }

    /** NR-ARFCN -> band n (rentang umum). */
    fun nrArfcnToBand(a: Int): String? = when (a) {
        in 151600..160600 -> "Band n28 (700)"
        in 173800..178800 -> "Band n5 (850)"
        in 361000..376000 -> "Band n3 (1800)"
        in 422000..434000 -> "Band n1 (2100)"
        in 524000..538000 -> "Band n7 (2600)"
        in 460000..480000 -> "Band n40 (2300)"
        in 499200..537999 -> "Band n41 (2500)"
        in 620000..653333 -> "Band n78 (3500)"
        else -> null
    }

    private fun label(b: Int, nr: Boolean): String {
        val f = bandMhz[b]
        val name = if (nr) "Band n$b" else "Band $b"
        return if (f != null && !nr) "$name ($f)" else name
    }

    private fun hasLoc(c: Context) = Build.VERSION.SDK_INT < 23 ||
        c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Minta modem memindai sel baru (Android 10+). allCellInfo biasa hanya cache lama. Maks 2,5 detik. */
    @android.annotation.SuppressLint("MissingPermission", "NewApi")
    private fun freshCells(tm: TelephonyManager): List<CellInfo>? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val latch = java.util.concurrent.CountDownLatch(1)
            val res = java.util.concurrent.atomic.AtomicReference<List<CellInfo>?>(null)
            tm.requestCellInfoUpdate(java.util.concurrent.Executor { it.run() }, object : TelephonyManager.CellInfoCallback() {
                override fun onCellInfo(cellInfo: MutableList<CellInfo>) { res.set(cellInfo); latch.countDown() }
                override fun onError(errorCode: Int, detail: Throwable?) { latch.countDown() }
            })
            latch.await(2500, java.util.concurrent.TimeUnit.MILLISECONDS)
            res.get()
        } catch (e: Throwable) { null }
    }

    @android.annotation.SuppressLint("NewApi")
    private fun plmnOf(ci: CellInfo): String? = try {
        when {
            ci is CellInfoLte && Build.VERSION.SDK_INT >= 28 -> ci.cellIdentity.let { (it.mccString ?: "") + (it.mncString ?: "") }
            Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr -> (ci.cellIdentity as? CellIdentityNr)?.let { (it.mccString ?: "") + (it.mncString ?: "") }
            else -> null
        }?.takeIf { it.length >= 5 }
    } catch (e: Throwable) { null }

    /** Sel terdaftar (primary serving) milik SIM data aktif dari scan baru; LTE didahulukan. Null bila tidak bisa. */
    @android.annotation.SuppressLint("MissingPermission", "NewApi")
    private fun servingCell(c: Context, tm: TelephonyManager): CellInfo? {
        if (!hasLoc(c)) return null
        val cells = (freshCells(tm)?.takeIf { it.isNotEmpty() } ?: try { tm.allCellInfo } catch (e: Throwable) { null }) ?: return null
        var reg = cells.filter { it.isRegistered }
        // Hanya sel milik operator SIM data (bila identitas sel menyebutkannya)
        val op = try { tm.networkOperator } catch (e: Throwable) { null }
        if (!op.isNullOrEmpty() && op.length >= 5) {
            val m = reg.filter { val p = plmnOf(it); p == null || p == op }
            if (m.isNotEmpty()) reg = m
        }
        if (Build.VERSION.SDK_INT >= 28) {
            val p = reg.filter { it.cellConnectionStatus == CellInfo.CONNECTION_PRIMARY_SERVING }
            reg = if (p.isNotEmpty()) p else reg.filter { it.cellConnectionStatus != CellInfo.CONNECTION_SECONDARY_SERVING }
        }
        return reg.sortedBy { if (it is CellInfoLte) 0 else 1 }.firstOrNull()
    }

    @android.annotation.SuppressLint("NewApi")
    private fun bandOf(ci: CellInfo): String? {
        if (ci is CellInfoLte) {
            val id = ci.cellIdentity
            if (Build.VERSION.SDK_INT >= 30) {
                val b = id.bands
                if (b.isNotEmpty() && b[0] in 1..127) return label(b[0], false)
            }
            val ch = id.earfcn
            if (ch > 0 && ch != Int.MAX_VALUE) return earfcnToBand(ch)
        } else if (Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr) {
            val id = ci.cellIdentity as? CellIdentityNr ?: return null
            if (Build.VERSION.SDK_INT >= 30) {
                val b = id.bands
                if (b.isNotEmpty() && b[0] in 1..512) return "Band n${b[0]}"
            }
            val ch = id.nrarfcn
            if (ch > 0 && ch != Int.MAX_VALUE) return nrArfcnToBand(ch)
        }
        return null
    }

    private fun cellDbm(ci: CellInfo): Int? = when {
        ci is CellInfoLte -> ci.cellSignalStrength.dbm
        ci is CellInfoWcdma -> ci.cellSignalStrength.dbm
        ci is CellInfoGsm -> ci.cellSignalStrength.dbm
        ci is CellInfoCdma -> ci.cellSignalStrength.dbm
        Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr -> ci.cellSignalStrength.dbm
        else -> null
    }

    private fun signalDbm(tm: TelephonyManager): Int? {
        if (Build.VERSION.SDK_INT < 29) return null
        return tm.signalStrength?.cellSignalStrengths?.map { it.dbm }?.firstOrNull { ok(it) }
    }

    private fun typeOf(c: Context, tm: TelephonyManager): String {
        try {
            @Suppress("MissingPermission")
            val t = tm.dataNetworkType
            val r = when (t) {
                TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
                TelephonyManager.NETWORK_TYPE_NR -> "5G"
                TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA,
                TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_EVDO_0, TelephonyManager.NETWORK_TYPE_EVDO_A,
                TelephonyManager.NETWORK_TYPE_EVDO_B, TelephonyManager.NETWORK_TYPE_TD_SCDMA -> "3G"
                TelephonyManager.NETWORK_TYPE_HSPAP -> "H+"
                TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS, TelephonyManager.NETWORK_TYPE_GSM -> "2G"
                else -> ""
            }
            if (r.isNotEmpty()) return r
        } catch (e: Throwable) { }
        if (hasLoc(c)) {
            try {
                @Suppress("MissingPermission")
                val ci = tm.allCellInfo?.firstOrNull { it.isRegistered }
                return when {
                    ci is CellInfoLte -> "LTE"
                    Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr -> "5G"
                    ci is CellInfoWcdma -> "3G"
                    ci is CellInfoGsm -> "2G"
                    else -> ""
                }
            } catch (e: Throwable) { }
        }
        return ""
    }
}
