package com.alfy.tunnel

import android.net.VpnService
import android.util.Base64
import net.schmizz.sshj.DefaultConfig
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.Socket
import java.net.SocketAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import javax.net.SocketFactory

private const val TYPE_TXT = 16
private const val CLASS_IN = 1
private const val UP_CHUNK = 90           // byte mentah per query upstream (aman utk panjang label DNS)
private const val HANDSHAKE_TIMEOUT_MS = 15000L
private const val B32 = "abcdefghijklmnopqrstuvwxyz234567"

/**
 * Jalur TERPISAH dari SshLink: tidak membuka koneksi TCP/TLS biasa ke host:port,
 * melainkan membungkus seluruh trafik SSH ke dalam query DNS (DNS tunneling / "SlowDNS")
 * yang dikirim ke Nameserver (NS) yang diinput user, lalu sesi SSH (sshj) dijalankan
 * di atas socket virtual hasil tunnel tsb. Hanya aktif kalau cfg.useSlowDns == true.
 */
class SlowDnsLink(private val svc: VpnService, private val cfg: Config) : TunnelLink {

    @Volatile private var ses: SSHClient? = null
    @Volatile private var udp: DatagramSocket? = null
    @Volatile private var closed = true
    private var pollThread: Thread? = null

    private var nsAddr: InetAddress? = null
    private var domain: String = ""
    private var keyHash: String = ""
    private var sessionId: String = ""
    private var seqUp = 0
    private var seqDown = 0
    private val inQueue = LinkedBlockingQueue<ByteArray>()
    private val ioLock = Any()

    override val alive: Boolean get() = !closed && ses?.let { it.isConnected && it.isAuthenticated } == true

    override fun connect() {
        close()
        val sv = Srv.parse(cfg.server) ?: throw IOException("Format server salah")
        domain = cfg.dnsNs.trim().trim('.')
        if (domain.isBlank()) throw IOException("SlowDNS: NS Name kosong")
        if (cfg.dnsPubKey.isBlank()) throw IOException("SlowDNS: Public Key kosong")
        keyHash = sha256Hex(cfg.dnsPubKey.trim()).take(16)
        sessionId = randomHex(8)
        seqUp = 0; seqDown = 0

        Bus.log("SlowDNS: resolving NS target ${sv.host}")
        nsAddr = InetAddress.getByName(sv.host)

        val sock = DatagramSocket()
        svc.protect(sock)
        udp = sock
        closed = false

        try {
            handshake()
        } catch (e: Exception) {
            closed = true
            try { sock.close() } catch (x: Exception) { }
            udp = null
            throw if (e is IOException) e else IOException("SlowDNS handshake gagal: ${e.message}")
        }
        Bus.log("SlowDNS: handshake OK, sesi=$sessionId")

        pollThread = Thread { pollLoop() }.also { it.isDaemon = true; it.start() }

        val s = SSHClient(DefaultConfig().apply {
            keepAliveProvider = net.schmizz.keepalive.KeepAliveProvider.KEEP_ALIVE
        })
        s.addHostKeyVerifier(PromiscuousVerifier())
        s.connectTimeout = 20000
        s.timeout = 20000
        val virtual = wrapTunnel()
        s.setSocketFactory(object : SocketFactory() {
            override fun createSocket(): Socket = virtual
            override fun createSocket(host: String?, port: Int): Socket = virtual
            override fun createSocket(host: String?, port: Int, la: InetAddress?, lp: Int): Socket = virtual
            override fun createSocket(host: InetAddress?, port: Int): Socket = virtual
            override fun createSocket(host: InetAddress?, port: Int, la: InetAddress?, lp: Int): Socket = virtual
        })
        try {
            s.connect(nsAddr, 53)
            s.authPassword(sv.user, sv.pass)
        } catch (e: Exception) {
            Bus.log("SlowDNS SSH Error: ${e.javaClass.name} - ${e.message}")
            try { s.disconnect() } catch (x: Exception) { }
            close()
            throw IOException("SlowDNS SSH gagal: ${e.message}")
        }
        ses = s
        Bus.log("SlowDNS: auth complete lewat DNS tunnel")
    }

    override fun open(host: String, port: Int): SshChan {
        val s = ses?.takeIf { it.isConnected && it.isAuthenticated } ?: throw IOException("SlowDNS tidak terhubung")
        return SshChan(s, host, port)
    }

    override fun close() {
        if (closed && udp == null && ses == null) return
        closed = true
        try { pollThread?.interrupt() } catch (e: Exception) { }
        pollThread = null
        try {
            udp?.let { u ->
                val bye = buildQuery("bye.$sessionId.$domain", TYPE_TXT)
                u.send(DatagramPacket(bye, bye.size, nsAddr, 53))
            }
        } catch (e: Exception) { }
        try { udp?.close() } catch (e: Exception) { }
        udp = null
        try { ses?.disconnect() } catch (e: Exception) { }
        ses = null
        inQueue.clear()
    }

    // ---------- handshake ----------

    private fun handshake() {
        val deadline = System.currentTimeMillis() + HANDSHAKE_TIMEOUT_MS
        var attempt = 0
        while (true) {
            if (System.currentTimeMillis() > deadline) throw IOException("Timeout handshake SlowDNS")
            attempt++
            try {
                val qname = "$sessionId.$keyHash.hs.$domain"
                val resp = query(qname)
                Bus.log("SlowDNS handshake#$attempt -> $resp")
                when {
                    resp.contains("KEYOK") -> return
                    resp.contains("KEYBAD") -> throw IOException("SlowDNS: Public Key ditolak server")
                    else -> { /* retry */ }
                }
            } catch (e: SocketTimeoutException) {
                Bus.log("SlowDNS: handshake timeout, retry...")
            }
        }
    }

    private fun pollLoop() {
        while (!closed) {
            try {
                val qname = "$seqDown.$sessionId.dn.$domain"
                val resp = query(qname, timeoutMs = 5000)
                if (resp.isNotEmpty() && resp != "EMPTY") {
                    val raw = try { Base64.decode(resp, Base64.NO_WRAP or Base64.NO_PADDING) } catch (e: Exception) { null }
                    if (raw != null && raw.isNotEmpty()) {
                        inQueue.put(raw)
                        seqDown = (seqDown + 1) and 0xFFFF
                        continue
                    }
                }
            } catch (e: SocketTimeoutException) {
                // tidak ada data baru, lanjut polling
            } catch (e: InterruptedException) {
                return
            } catch (e: Exception) {
                if (closed) return
            }
            try { Thread.sleep(250) } catch (e: InterruptedException) { return }
        }
    }

    private fun sendUp(data: ByteArray) {
        var off = 0
        while (off < data.size) {
            val n = minOf(UP_CHUNK, data.size - off)
            val chunk = data.copyOfRange(off, off + n)
            off += n
            var ok = false
            for (attempt in 1..4) {
                if (closed) return
                try {
                    val qname = "$seqUp.${b32encode(chunk)}.$sessionId.up.$domain"
                    val resp = query(qname, timeoutMs = 3000)
                    if (resp.startsWith("ACK:$seqUp")) { ok = true; break }
                } catch (e: SocketTimeoutException) {
                    // retry
                }
            }
            if (!ok) throw IOException("SlowDNS: gagal kirim data (seq=$seqUp)")
            seqUp = (seqUp + 1) and 0xFFFF
        }
    }

    /** Kirim satu query TXT ke NS dan kembalikan isi TXT record pertama (gabungan). */
    private fun query(qname: String, timeoutMs: Int = 4000): String {
        val u = udp ?: throw IOException("SlowDNS socket tertutup")
        val pkt = buildQuery(qname, TYPE_TXT)
        u.soTimeout = timeoutMs
        u.send(DatagramPacket(pkt, pkt.size, nsAddr, 53))
        val buf = ByteArray(2048)
        val rp = DatagramPacket(buf, buf.size)
        u.receive(rp)
        return parseTxtAnswers(buf, rp.length).joinToString("")
    }

    // ---------- socket virtual utk SSHClient ----------

    private fun wrapTunnel(): Socket = object : Socket() {
        override fun connect(ep: SocketAddress?) {}
        override fun connect(ep: SocketAddress?, timeout: Int) {}
        override fun isConnected(): Boolean = !closed
        override fun isClosed(): Boolean = closed
        override fun close() { this@SlowDnsLink.close() }
        override fun setSoTimeout(t: Int) {}
        override fun getSoTimeout(): Int = 0
        override fun setTcpNoDelay(on: Boolean) {}
        override fun getTcpNoDelay(): Boolean = true
        override fun setKeepAlive(on: Boolean) {}
        override fun getInetAddress(): InetAddress? = nsAddr
        override fun getPort(): Int = 53
        override fun shutdownInput() {}
        override fun shutdownOutput() {}

        override fun getOutputStream(): OutputStream = object : OutputStream() {
            override fun write(b: Int) { write(byteArrayOf(b.toByte()), 0, 1) }
            override fun write(b: ByteArray, off: Int, len: Int) {
                synchronized(ioLock) { sendUp(b.copyOfRange(off, off + len)) }
            }
        }

        override fun getInputStream(): InputStream = object : InputStream() {
            private var cur: ByteArray? = null
            private var pos = 0
            override fun read(): Int {
                val b = ByteArray(1)
                val n = read(b, 0, 1)
                return if (n <= 0) -1 else (b[0].toInt() and 255)
            }
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                while (cur == null || pos >= (cur?.size ?: 0)) {
                    if (closed) return -1
                    val chunk = inQueue.poll(20, TimeUnit.SECONDS) ?: continue
                    cur = chunk; pos = 0
                }
                val c = cur ?: return -1
                val n = minOf(len, c.size - pos)
                System.arraycopy(c, pos, b, off, n)
                pos += n
                return n
            }
        }
    }
}

// ---------- util DNS wire-format (manual, java.net.DatagramSocket, tanpa dependency tambahan) ----------

private fun buildQuery(name: String, type: Int): ByteArray {
    val out = ByteArrayOutputStream()
    val d = DataOutputStream(out)
    val id = (Math.random() * 65535).toInt()
    d.writeShort(id)
    d.writeShort(0x0100) // standard query, recursion desired
    d.writeShort(1); d.writeShort(0); d.writeShort(0); d.writeShort(0)
    for (label in name.split(".")) {
        if (label.isEmpty()) continue
        val lb = label.toByteArray(Charsets.US_ASCII)
        d.writeByte(lb.size)
        d.write(lb)
    }
    d.writeByte(0)
    d.writeShort(type)
    d.writeShort(CLASS_IN)
    return out.toByteArray()
}

private fun skipName(bb: ByteBuffer) {
    while (true) {
        val len = bb.get().toInt() and 255
        if (len == 0) break
        if (len and 0xC0 == 0xC0) { bb.get(); break } // compressed pointer
        bb.position(bb.position() + len)
    }
}

private fun parseTxtAnswers(buf: ByteArray, len: Int): List<String> {
    val out = ArrayList<String>()
    try {
        val bb = ByteBuffer.wrap(buf, 0, len)
        bb.short // id
        bb.short // flags
        val qd = bb.short.toInt() and 0xFFFF
        val an = bb.short.toInt() and 0xFFFF
        bb.short; bb.short // nscount, arcount
        repeat(qd) { skipName(bb); bb.short; bb.short }
        repeat(an) {
            skipName(bb)
            val type = bb.short.toInt() and 0xFFFF
            bb.short // class
            bb.int // ttl
            val rdlen = bb.short.toInt() and 0xFFFF
            val rdStart = bb.position()
            if (type == TYPE_TXT) {
                var p = rdStart
                val end = rdStart + rdlen
                val sb = StringBuilder()
                while (p < end) {
                    val slen = buf[p].toInt() and 255
                    p++
                    sb.append(String(buf, p, slen, Charsets.ISO_8859_1))
                    p += slen
                }
                out.add(sb.toString())
            }
            bb.position(rdStart + rdlen)
        }
    } catch (e: Exception) { }
    return out
}

private fun b32encode(data: ByteArray): String {
    if (data.isEmpty()) return ""
    val sb = StringBuilder()
    var bits = 0
    var value = 0
    for (b in data) {
        value = (value shl 8) or (b.toInt() and 255)
        bits += 8
        while (bits >= 5) {
            sb.append(B32[(value shr (bits - 5)) and 31])
            bits -= 5
        }
    }
    if (bits > 0) sb.append(B32[(value shl (5 - bits)) and 31])
    return sb.toString()
}

private fun sha256Hex(s: String): String {
    val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
    return d.joinToString("") { "%02x".format(it) }
}

private fun randomHex(n: Int): String {
    val chars = "0123456789abcdef"
    val r = java.util.Random()
    return (1..n).map { chars[r.nextInt(16)] }.joinToString("")
}
