package com.alfy.tunnel

import android.net.VpnService
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.SocketFactory
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PushbackInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"

class SshLink(private val svc: VpnService, private val cfg: Config) {
    @Volatile private var ses: Session? = null
    @Volatile private var pending: Socket? = null
    private val dnsCache = HashMap<String, InetAddress>()
    @Volatile private var pin: PushbackInputStream? = null

    companion object {
        private var rot = 0
        private val splitRe = Regex("""\[(split|instant_split|delay_split|split_delay|delay[=_]\d+)\]""", RegexOption.IGNORE_CASE)
        private val rotRe = Regex("""\[rotate[=_]([^\]]*)\]""", RegexOption.IGNORE_CASE)
    }

    val alive: Boolean get() = ses?.isConnected == true

    fun connect() {
        close()
        val sv = Srv.parse(cfg.server) ?: throw IOException("Format server salah")
        val sock = prepare(sv)
        val jsch = JSch()
        // KEX Universal
        jsch.setConfig("kex", "curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group-exchange-sha256,diffie-hellman-group16-sha512,diffie-hellman-group14-sha256,diffie-hellman-group14-sha1,diffie-hellman-group1-sha1")
        // Host Key Universal
        jsch.setConfig("server_host_key", "ssh-ed25519,ecdsa-sha2-nistp256,ecdsa-sha2-nistp384,ecdsa-sha2-nistp521,rsa-sha2-512,rsa-sha2-256,ssh-rsa,ssh-dss")
        // Cipher Universal
        jsch.setConfig("cipher.s2c", "chacha20-poly1305@openssh.com,aes128-ctr,aes192-ctr,aes256-ctr,aes128-cbc,3des-cbc")
        jsch.setConfig("cipher.c2s", "chacha20-poly1305@openssh.com,aes128-ctr,aes192-ctr,aes256-ctr,aes128-cbc,3des-cbc")
        // MAC Universal
        jsch.setConfig("mac.s2c", "hmac-sha2-256,hmac-sha2-512,hmac-sha1")
        jsch.setConfig("mac.c2s", "hmac-sha2-256,hmac-sha2-512,hmac-sha1")
        val s = jsch.getSession(sv.user, sv.host, sv.port)
        s.setPassword(sv.pass)
        s.setConfig("StrictHostKeyChecking", "no")
        s.setConfig("PreferredAuthentications", "password,keyboard-interactive")
        s.setSocketFactory(object : SocketFactory {
            override fun createSocket(host: String, port: Int): Socket = sock
            override fun getInputStream(socket: Socket): InputStream = object : FilterInputStream(pin ?: socket.getInputStream()) {
                private val sb = StringBuilder()
                private var done = false
                private fun feed(b: Int) {
                    if (done) return
                    sb.append(b.toChar())
                    if (b == 10 || sb.length > 255) {
                        done = true
                        Bus.log("H: " + esc(sb.toString()))
                        Bus.log(sb.toString().trim())
                    }
                }
                override fun read(): Int {
                    val c = super.read()
                    if (c >= 0) feed(c)
                    return c
                }
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    val n = super.read(b, off, len)
                    if (!done) for (i in 0 until n) feed(b[off + i].toInt() and 255)
                    return n
                }
            }
            override fun getOutputStream(socket: Socket): OutputStream = socket.getOutputStream()
        })
        s.setServerAliveInterval(20000)
        s.setServerAliveCountMax(3)
        s.setDaemonThread(true)
        try {
            s.connect(20000)
        } catch (e: Exception) {
            Bus.log("SSH Error Detail: ${e.javaClass.name} - ${e.message}")
            Bus.log("Cause: ${e.cause?.message}")
            try { sock.close() } catch (x: Exception) { }
            throw IOException("SSH gagal: ${e.message}")
        }
        ses = s
        pending = null
        Bus.log("Auth complete")
    }

    fun open(host: String, port: Int): ChannelDirectTCPIP {
        val s = ses?.takeIf { it.isConnected } ?: throw IOException("SSH tidak terhubung")
        val ch = s.openChannel("direct-tcpip") as ChannelDirectTCPIP
        ch.setHost(host)
        ch.setPort(port)
        return ch
    }

    fun close() {
        try { pending?.close() } catch (e: Exception) { }
        pending = null
        try { ses?.disconnect() } catch (e: Exception) { }
        ses = null
    }

    private fun resolve(h: String): InetAddress = synchronized(dnsCache) {
        dnsCache.getOrPut(h) {
            try { InetAddress.getByName(h) } catch (e: Exception) { throw IOException("Host tidak ditemukan: $h") }
        }
    }

    private fun rep(s: String, tag: String, v: String) = s.replace("[$tag]", v, ignoreCase = true)

    private fun payloadRaw(sv: Srv): String {
        var r = cfg.payload.ifBlank { Config.DEFAULT_PAYLOAD }
        r = r.replace("\r", "").replace("\n", "")
        r = r.replace("\\r", "\r").replace("\\n", "\n").replace("\\t", "\t")
        val px = if (cfg.proxy.isBlank()) null else parseHp(cfg.proxy)
        val sni = cfg.sni.trim().ifEmpty { sv.host }
        r = rotRe.replace(r) { m ->
            val items = m.groupValues[1].split(';', ',', '|').map { it.trim() }.filter { it.isNotEmpty() }
            if (items.isEmpty()) "" else items[rot % items.size]
        }
        val hp = "${sv.host}:${sv.port}"
        r = rep(r, "host_port", hp)
        r = rep(r, "ssh_host", sv.host)
        r = rep(r, "ssh_port", sv.port.toString())
        r = rep(r, "ssh_host_port", hp)
        r = rep(r, "proxy_host", px?.first ?: sv.host)
        r = rep(r, "proxy_port", (px?.second ?: sv.port).toString())
        r = rep(r, "sni", sni)
        r = rep(r, "host", sv.host)
        r = rep(r, "port", sv.port.toString())
        r = rep(r, "ip", try { resolve(sv.host).hostAddress ?: sv.host } catch (e: Exception) { sv.host })
        r = rep(r, "protocol", "HTTP/1.1")
        r = rep(r, "method", "CONNECT")
        r = rep(r, "netData", "CONNECT $hp HTTP/1.1")
        r = rep(r, "raw", "CONNECT $hp HTTP/1.1[crlf][crlf]")
        r = rep(r, "random", java.util.UUID.randomUUID().toString().take(8))
        return r
    }

    private fun expand(r: String): String =
        r.replace("[ua]", UA, ignoreCase = true)
            .replace("[crlf]", "\r\n", ignoreCase = true).replace("[cr]", "\r", ignoreCase = true)
            .replace("[lf]", "\n", ignoreCase = true)

    private fun sendPayload(s: Socket, sv: Srv) {
        val raw = payloadRaw(sv)
        Bus.log("Sending Payload: $raw")
        var last = 0
        var delay = 0L
        val ms = splitRe.findAll(raw).toList()
        val parts = ArrayList<Pair<Long, String>>()
        for (m in ms) {
            parts.add(delay to raw.substring(last, m.range.first))
            val t = m.groupValues[1].lowercase()
            delay = when {
                t == "instant_split" -> 0L
                t == "delay_split" || t == "split_delay" -> 1500L
                t.startsWith("delay") -> t.filter { it.isDigit() }.toLongOrNull()?.coerceIn(0L, 10000L) ?: 300L
                else -> 300L
            }
            last = m.range.last + 1
        }
        parts.add(delay to raw.substring(last))
        for ((d, p) in parts) {
            if (d > 0) Thread.sleep(d)
            val t = expand(p)
            if (t.isNotEmpty()) send(s, t)
        }
    }

    private fun esc(t: String) = t.replace("\r", "\\r").replace("\n", "\\n")

    private fun prepare(sv: Srv): Socket {
        val px = if (cfg.proxy.isBlank()) null else parseHp(cfg.proxy)
        val tls = cfg.mode == 1
        val tHost = px?.first ?: sv.host
        val tPort = px?.second ?: sv.port
        rot++
        pin = null
        Bus.log("Connecting to proxy $tHost port $tPort")
        val addr = resolve(tHost)
        Bus.log("Ip resolved, ${addr.hostAddress}")
        var s = Socket()
        pending = s
        svc.protect(s)
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(addr, tPort), 15000)
        s.soTimeout = 15000
        if (!tls) {
            pin = PushbackInputStream(s.getInputStream(), 16)
            sendPayload(s, sv)
            readHttp(pin!!)
        } else {
            if (px != null) {
                send(s, "CONNECT ${sv.host}:${sv.port} HTTP/1.1\r\nHost: ${sv.host}:${sv.port}\r\n\r\n")
                readHttp(PushbackInputStream(s.getInputStream(), 16))
            }
            val sni = cfg.sni.trim().ifEmpty { sv.host }
            val tm = object : X509TrustManager {
                override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf(tm), null)
            val ssl = ctx.socketFactory.createSocket(s, sni, tPort, true) as SSLSocket
            pending = ssl
            try {
                val p = ssl.sslParameters
                p.serverNames = listOf(SNIHostName(sni))
                ssl.sslParameters = p
            } catch (e: Exception) {
                Bus.log("SNI tidak valid, dipakai default")
            }
            ssl.startHandshake()
            Bus.log("TLS OK (SNI: $sni)")
            s = ssl
            pin = PushbackInputStream(ssl.getInputStream(), 16)
            if (cfg.payload.isNotBlank()) {
                sendPayload(s, sv)
                readHttp(pin!!)
            }
        }
        s.soTimeout = 0
        return s
    }

    private fun send(s: Socket, t: String) {
        val o = s.getOutputStream()
        o.write(t.toByteArray(Charsets.ISO_8859_1))
        o.flush()
    }

    /** Baca satu atau lebih respons HTTP. Jika server langsung mengirim banner SSH, tidak ada yang dikonsumsi. */
    private fun readHttp(i: PushbackInputStream): String {
        var first = ""
        var n = 0
        while (n < 6) {
            val head = ByteArray(5)
            var got = 0
            while (got < 5) {
                val c = try {
                    i.read(head, got, 5 - got)
                } catch (e: java.net.SocketTimeoutException) {
                    if (n > 0 && got == 0) return first
                    throw e
                }
                if (c < 0) {
                    if (got == 0 && n > 0) return first
                    throw IOException("Koneksi ditutup saat menunggu respons")
                }
                got += c
            }
            val hs = String(head, Charsets.ISO_8859_1)
            if (hs.startsWith("SSH-")) {
                i.unread(head, 0, got)
                return first
            }
            if (n > 0 && !hs.startsWith("HTTP/")) {
                i.unread(head, 0, got)
                return first
            }
            val sb = StringBuilder(hs)
            while (!sb.endsWith("\r\n\r\n")) {
                val c = i.read()
                if (c < 0) throw IOException("Koneksi ditutup saat menunggu respons")
                sb.append(c.toChar())
                if (sb.length > 8192) throw IOException("Respons terlalu panjang")
            }
            Bus.log("H: " + esc(sb.toString()))
            val line = sb.lineSequence().first().trim()
            Bus.log("Response: $line")
            val code = line.split(" ").getOrNull(1)?.toIntOrNull()
            if (cfg.mode != 2 && (code == null || (code != 101 && code != 200 && code !in 100..199))) {
                throw IOException("Respons ditolak: $line")
            }
            if (n == 0) first = line
            n++
            val cl = Regex("content-length:\\s*(\\d+)", RegexOption.IGNORE_CASE).find(sb.toString())
                ?.groupValues?.get(1)?.toIntOrNull() ?: 0
            if (cl > 0 && code != 101 && cl <= 65536) {
                var left = cl
                while (left > 0) {
                    val c = i.read()
                    if (c < 0) break
                    left--
                }
            }
        }
        return first
    }
}
