package com.alfy.tunnel

import android.net.VpnService
import net.schmizz.sshj.DefaultConfig
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.connection.channel.direct.DirectConnection
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PushbackInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketAddress
import java.security.Security
import javax.net.SocketFactory
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"

class SshLink(private val svc: VpnService, private val cfg: Config) : TunnelLink {
    @Volatile private var ses: SSHClient? = null
    @Volatile private var pending: Socket? = null
    private val dnsCache = HashMap<String, InetAddress>()
    @Volatile private var pin: PushbackInputStream? = null

    companion object {
        init {
            try {
                Security.removeProvider("BC")
                Security.insertProviderAt(Class.forName("org.bouncycastle.jce.provider.BouncyCastleProvider").getDeclaredConstructor().newInstance() as java.security.Provider, 1)
            } catch (e: Throwable) { }
        }
        private var rot = 0
        private val splitRe = Regex("""\[(split|instant_split|delay_split|split_delay|delay[=_]\d+)\]""", RegexOption.IGNORE_CASE)
        private val rotRe = Regex("""\[rotate[=_]([^\]]*)\]""", RegexOption.IGNORE_CASE)
    }

    override val alive: Boolean get() = ses?.let { it.isConnected && it.isAuthenticated } == true

    override fun connect() {
        close()
        val sv = Srv.parse(cfg.server) ?: throw IOException("Format server salah")
        val sock = prepare(sv)
        val s = SSHClient(DefaultConfig().apply {
            keepAliveProvider = net.schmizz.keepalive.KeepAliveProvider.KEEP_ALIVE
            applyPilot(this)
            if (Prefs.useCompression.value) {
                try {
                    compressionFactories = listOf<net.schmizz.sshj.common.Factory.Named<net.schmizz.sshj.transport.compression.Compression>>(
                        net.schmizz.sshj.transport.compression.DelayedZlibCompression.Factory(),
                        net.schmizz.sshj.transport.compression.ZlibCompression.Factory(),
                        net.schmizz.sshj.transport.compression.NoneCompression.Factory()
                    )
                } catch (t: Throwable) { }
            }
        })
        s.addHostKeyVerifier(PromiscuousVerifier())
        s.connectTimeout = 20000
        s.timeout = 20000
        // Keep-alive SSH agresif: ketuk server tiap 5 dtk, putus setelah 2x tanpa balasan (diset sebelum connect)
        try {
            val ka0 = s.connection.keepAlive
            ka0.keepAliveInterval = 5
            try { ka0.javaClass.getMethod("setMaxAliveCount", Int::class.javaPrimitiveType).invoke(ka0, 2) } catch (x: Throwable) { }
        } catch (x: Throwable) { }
        s.setSocketFactory(object : SocketFactory() {
            override fun createSocket(): Socket = wrap(sock)
            override fun createSocket(host: String?, port: Int): Socket = wrap(sock)
            override fun createSocket(host: String?, port: Int, la: InetAddress?, lp: Int): Socket = wrap(sock)
            override fun createSocket(host: InetAddress?, port: Int): Socket = wrap(sock)
            override fun createSocket(host: InetAddress?, port: Int, la: InetAddress?, lp: Int): Socket = wrap(sock)
        })
        try {
            s.connect(resolve(sv.host), sv.port)
            try { s.authPassword(sv.user, sv.pass) } catch (ae: Exception) {
                try { s.disconnect() } catch (x: Exception) { }
                try { sock.close() } catch (x: Exception) { }
                Bus.log("Auth failed")
                throw IOException("Auth failed")
            }
            try {
                s.connection.keepAlive.keepAliveInterval = 5
                val ka = s.connection.keepAlive
                ka.javaClass.getMethod("setMaxAliveCount", Int::class.javaPrimitiveType).invoke(ka, 2)
            } catch (x: Throwable) { }
            try { sock.keepAlive = true; sock.tcpNoDelay = true } catch (x: Exception) { }
            sock.soTimeout = 15000
        } catch (e: Exception) {
            if (e is IOException && e.message == "Auth failed") throw e
            try { s.disconnect() } catch (x: Exception) { }
            try { sock.close() } catch (x: Exception) { }
            throw IOException("SSH gagal: ${e.message}")
        }
        ses = s
        pending = null
        Bus.log("Auth complete")
    }

    /** Pilot SSH: batasi daftar KEX/Cipher/HostKey sesuai cfg.pilotType. AUTO = default universal (tidak diubah). */
    private fun applyPilot(c: net.schmizz.sshj.Config) {
        val kex: Set<String>
        val ciph: Set<String>
        val hk: Set<String>?
        when {
            cfg.pilotType.equals("OPENSSH", ignoreCase = true) -> {
                kex = setOf("curve25519-sha256", "ecdh-sha2-nistp256")
                ciph = setOf("chacha20-poly1305@openssh.com", "aes128-ctr", "aes256-ctr")
                hk = null
            }
            cfg.pilotType.equals("DROPBEAR", ignoreCase = true) -> {
                kex = setOf("diffie-hellman-group14-sha1")
                ciph = setOf("aes128-cbc", "3des-cbc")
                hk = setOf("ssh-rsa")
            }
            else -> return
        }
        try {
            val k = c.keyExchangeFactories.filter { it.name in kex }
            if (k.isNotEmpty()) c.keyExchangeFactories = k
            val ci = c.cipherFactories.filter { it.name in ciph }
            if (ci.isNotEmpty()) c.cipherFactories = ci
            if (hk != null) {
                val h = c.keyAlgorithms.filter { it.name in hk }
                if (h.isNotEmpty()) c.keyAlgorithms = h
            }
            Bus.log("Pilot SSH: ${cfg.pilotType.uppercase()} (KEX=${c.keyExchangeFactories.size}, Cipher=${c.cipherFactories.size})")
        } catch (e: Throwable) {
            Bus.log("Pilot SSH gagal diterapkan, pakai default: ${e.message}")
        }
    }

    override fun open(host: String, port: Int): SshChan {
        val s = ses?.takeIf { it.isConnected && it.isAuthenticated } ?: throw IOException("SSH tidak terhubung")
        return SshChan(s, host, port)
    }

    private fun wrap(d: Socket): Socket = object : Socket() {
        override fun connect(ep: SocketAddress?) {}
        override fun connect(ep: SocketAddress?, timeout: Int) {}
        override fun isConnected(): Boolean = d.isConnected
        override fun isClosed(): Boolean = d.isClosed
        override fun close() { d.close() }
        override fun setSoTimeout(t: Int) { d.soTimeout = t }
        override fun getSoTimeout(): Int = d.soTimeout
        override fun setTcpNoDelay(on: Boolean) { d.tcpNoDelay = on }
        override fun getTcpNoDelay(): Boolean = d.tcpNoDelay
        override fun setKeepAlive(on: Boolean) { d.keepAlive = on }
        override fun getInetAddress(): InetAddress? = d.inetAddress
        override fun getPort(): Int = d.port
        override fun getRemoteSocketAddress(): SocketAddress? = d.remoteSocketAddress
        override fun shutdownInput() { d.shutdownInput() }
        override fun shutdownOutput() { d.shutdownOutput() }
        override fun getOutputStream(): OutputStream = d.getOutputStream()
        override fun getInputStream(): InputStream = object : FilterInputStream(pin ?: d.getInputStream()) {
            private val sb = StringBuilder()
            private var done = false
            private var hdr = false
            private var lines = 0
            private fun feed(b: Int) {
                if (done) return
                if (b != 10 && b != 13 && b != 9 && (b < 32 || b > 126)) { done = true; sb.setLength(0); return }
                sb.append(b.toChar())
                if (b == 10 || sb.length > 255) {
                    val t = sb.toString().trim()
                    sb.setLength(0)
                    lines++
                    if (t.isNotEmpty()) {
                        if (!hdr) { hdr = true; Bus.log("Server Message:", true) }
                        Bus.log(t, true)
                    }
                    if (lines >= 10) done = true
                }
            }
            override fun read(): Int {
                val c = super.read()
                if (c >= 0) feed(c)
                return c
            }
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val n = super.read(b, off, len)
                if (!done) for (i in 0 until n) feed(b[off + i].toInt() and 255)
                return n
            }
        }
    }

    override fun close() {
        try { pending?.close() } catch (e: Exception) { }
        pending = null
        try { ses?.disconnect() } catch (e: Exception) { }
        ses = null
    }

    private fun resolve(h: String): InetAddress = synchronized(dnsCache) {
        dnsCache.getOrPut(h) {
            try { InetAddress.getByName(h) } catch (e: Exception) { throw IOException("Host tidak ditemukan: $h") }
        }
    }

    private fun rep(s: String, tag: String, v: String) = s.replace("[$tag]", v, ignoreCase = true)

    private fun payloadRaw(sv: Srv): String {
        var r = cfg.payload.ifBlank { Config.DEFAULT_PAYLOAD }
        r = r.replace("\r", "").replace("\n", "")
        r = r.replace("\\r", "\r").replace("\\n", "\n").replace("\\t", "\t")
        val px = if (cfg.proxy.isBlank()) null else parseHp(cfg.proxy)
        val sni = cfg.sni.trim().ifEmpty { sv.host }
        r = rotRe.replace(r) { m ->
            val items = m.groupValues[1].split(';', ',', '|').map { it.trim() }.filter { it.isNotEmpty() }
            if (items.isEmpty()) "" else items[rot % items.size]
        }
        val hp = "${sv.host}:${sv.port}"
        r = rep(r, "host_port", hp)
        r = rep(r, "ssh_host", sv.host)
        r = rep(r, "ssh_port", sv.port.toString())
        r = rep(r, "ssh_host_port", hp)
        r = rep(r, "proxy_host", px?.first ?: sv.host)
        r = rep(r, "proxy_port", (px?.second ?: sv.port).toString())
        r = rep(r, "sni", sni)
        r = rep(r, "host", sv.host)
        r = rep(r, "port", sv.port.toString())
        r = rep(r, "ip", try { resolve(sv.host).hostAddress ?: sv.host } catch (e: Exception) { sv.host })
        r = rep(r, "protocol", "HTTP/1.1")
        r = rep(r, "method", "CONNECT")
        r = rep(r, "netData", "CONNECT $hp HTTP/1.1")
        r = rep(r, "raw", "CONNECT $hp HTTP/1.1[crlf][crlf]")
        r = rep(r, "random", java.util.UUID.randomUUID().toString().take(8))
        return r
    }

    private fun expand(r: String): String =
        r.replace("[ua]", UA, ignoreCase = true)
            .replace("[crlf]", "\r\n", ignoreCase = true).replace("[cr]", "\r", ignoreCase = true)
            .replace("[lf]", "\n", ignoreCase = true)

    private fun sendPayload(s: Socket, sv: Srv) {
        val raw = payloadRaw(sv)
        Bus.log("Sending Payload: $raw")
        var last = 0
        var delay = 0L
        val ms = splitRe.findAll(raw).toList()
        val parts = ArrayList<Pair<Long, String>>()
        for (m in ms) {
            parts.add(delay to raw.substring(last, m.range.first))
            val t = m.groupValues[1].lowercase()
            delay = when {
                t == "instant_split" -> 0L
                t == "delay_split" || t == "split_delay" -> 1500L
                t.startsWith("delay") -> t.filter { it.isDigit() }.toLongOrNull()?.coerceIn(0L, 10000L) ?: 300L
                else -> 300L
            }
            last = m.range.last + 1
        }
        parts.add(delay to raw.substring(last))
        for ((d, p) in parts) {
            if (d > 0) Thread.sleep(d)
            val t = expand(p)
            if (t.isNotEmpty()) send(s, t)
        }
    }

    private fun esc(t: String) = t.replace("\r", "\\r").replace("\n", "\\n")

    private fun prepare(sv: Srv): Socket {
        val px = if (cfg.proxy.isBlank()) null else parseHp(cfg.proxy)
        val tls = cfg.mode == 1
        val tHost = px?.first ?: sv.host
        val tPort = if (cfg.useSlowDns) 53 else (px?.second ?: sv.port)
        rot++
        pin = null
        if (cfg.useSlowDns) {
            // PLACEHOLDER SlowDNS: transport dipaksa lewat port 53 (TCP). NS Name & Public Key sudah tersimpan,
            // handshake DNS-tunnel penuh (dnstt/slowdns) belum diimplementasikan.
            Bus.log("SlowDNS aktif: paksa port 53, NS=${cfg.dnsNs.trim()}, key=${cfg.dnsPubKey.trim().take(8)}…")
        }
        Bus.log("Connecting to proxy $tHost port $tPort")
        val addr = resolve(tHost)
        Bus.log("Ip resolved, ${addr.hostAddress}")
        var s = Socket()
        pending = s
        svc.protect(s)
        s.keepAlive = true
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(addr, tPort), 15000)
        s.soTimeout = 15000
        if (!tls) {
            pin = PushbackInputStream(s.getInputStream(), 16)
            sendPayload(s, sv)
            readHttp(pin!!)
        } else {
            if (px != null) {
                send(s, "CONNECT ${sv.host}:${sv.port} HTTP/1.1\r\nHost: ${sv.host}:${sv.port}\r\n\r\n")
                readHttp(PushbackInputStream(s.getInputStream(), 16))
            }
            val sni = cfg.sni.trim().ifEmpty { sv.host }
            val tm = object : X509TrustManager {
                override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf(tm), null)
            val ssl = ctx.socketFactory.createSocket(s, sni, tPort, true) as SSLSocket
            pending = ssl
            try {
                val p = ssl.sslParameters
                p.serverNames = listOf(SNIHostName(sni))
                ssl.sslParameters = p
            } catch (e: Exception) {
                Bus.log("SNI tidak valid, dipakai default")
            }
            ssl.startHandshake()
            Bus.log("TLS OK (SNI: $sni)")
            s = ssl
            pin = PushbackInputStream(ssl.getInputStream(), 16)
            if (cfg.payload.isNotBlank()) {
                sendPayload(s, sv)
                readHttp(pin!!)
            }
        }
        s.soTimeout = 15000
        return s
    }

    private fun send(s: Socket, t: String) {
        val o = s.getOutputStream()
        o.write(t.toByteArray(Charsets.ISO_8859_1))
        o.flush()
    }

    /** Baca satu atau lebih respons HTTP. Jika server langsung mengirim banner SSH, tidak ada yang dikonsumsi. */
    private fun readHttp(i: PushbackInputStream): String {
        var first = ""
        var n = 0
        while (n < 6) {
            val head = ByteArray(5)
            var got = 0
            while (got < 5) {
                val c = try {
                    i.read(head, got, 5 - got)
                } catch (e: java.net.SocketTimeoutException) {
                    if (n > 0 && got == 0) return first
                    throw e
                }
                if (c < 0) {
                    if (got == 0 && n > 0) return first
                    throw IOException("Koneksi ditutup saat menunggu respons")
                }
                got += c
            }
            val hs = String(head, Charsets.ISO_8859_1)
            if (hs.startsWith("SSH-")) {
                i.unread(head, 0, got)
                return first
            }
            if (n > 0 && !hs.startsWith("HTTP/")) {
                i.unread(head, 0, got)
                return first
            }
            val sb = StringBuilder(hs)
            while (!sb.endsWith("\r\n\r\n")) {
                val c = i.read()
                if (c < 0) throw IOException("Koneksi ditutup saat menunggu respons")
                sb.append(c.toChar())
                if (sb.length > 8192) throw IOException("Respons terlalu panjang")
            }
            if (Prefs.dbg.value) Bus.log("H: " + esc(sb.toString()))
            val line = sb.lineSequence().first().trim()
            Bus.log("Response: $line")
            val code = line.split(" ").getOrNull(1)?.toIntOrNull()
            if (cfg.mode != 2 && (code == null || (code != 101 && code != 200 && code !in 100..199))) {
                throw IOException("Respons ditolak: $line")
            }
            if (n == 0) first = line
            n++
            val cl = Regex("content-length:\\s*(\\d+)", RegexOption.IGNORE_CASE).find(sb.toString())
                ?.groupValues?.get(1)?.toIntOrNull() ?: 0
            if (cl > 0 && code != 101 && cl <= 65536) {
                var left = cl
                while (left > 0) {
                    val c = i.read()
                    if (c < 0) break
                    left--
                }
            }
        }
        return first
    }
}

/** Channel direct-tcpip sshj dengan API sama seperti sebelumnya (inputStream, outputStream, connect, disconnect). */
class SshChan(private val cl: SSHClient, private val host: String, private val port: Int) {
    @Volatile private var dc: DirectConnection? = null
    private fun d(): DirectConnection = dc ?: throw IOException("Channel belum terbuka")
    val inputStream: InputStream = object : InputStream() {
        override fun read(): Int = d().inputStream.read()
        override fun read(b: ByteArray, off: Int, len: Int): Int = d().inputStream.read(b, off, len)
        override fun available(): Int = dc?.inputStream?.available() ?: 0
    }
    val outputStream: OutputStream = object : OutputStream() {
        override fun write(b: Int) { d().outputStream.write(b) }
        override fun write(b: ByteArray, off: Int, len: Int) { d().outputStream.write(b, off, len) }
        override fun flush() { dc?.outputStream?.flush() }
    }
    fun connect(@Suppress("UNUSED_PARAMETER") timeoutMs: Int) {
        dc = cl.newDirectConnection(host, port)
    }
    fun disconnect() { try { dc?.close() } catch (e: Exception) { } }
}
