package com.alfy.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.Network
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.widget.RemoteViews
import java.net.Inet4Address
import java.net.NetworkInterface
import org.json.JSONObject
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class VpnSvc : VpnService() {
    companion object {
        const val ACT_START = "com.alfy.tunnel.START"
        const val ACT_STOP = "com.alfy.tunnel.STOP"
        const val ACT_RECONNECT = "com.alfy.tunnel.RECONNECT"
        const val EXTRA = "cfg"
        private const val BC_RECONNECT = "com.alfy.tunnel.BC_RECONNECT"
        private const val BC_STOP = "com.alfy.tunnel.BC_STOP"
        private const val CH = "alfy_status"
        private const val NID = 1
    }

    @Volatile private var gen = 0
    @Volatile private var kick = false
    @Volatile private var wdGen = -1
    @Volatile private var wdStreak = 0
    @Volatile private var wdLast = 0L
    @Volatile private var worker: Thread? = null
    @Volatile private var lastCfg: Config? = null
    private var tun: ParcelFileDescriptor? = null
    private var link: TunnelLink? = null
    private var stack: TunStack? = null
    private var proxy: HttpProxyServer? = null
    private var hud: Hud? = null
    private var wl: PowerManager.WakeLock? = null
    @Volatile private var baseInfo = "Menghubungkan…"
    @Volatile private var cfgName = "AlfyTunnel"
    @Volatile private var lastSig = ""
    private val reconLock = Any()
    private var chMade = false
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var netSeen = false
    private val netH = Handler(Looper.getMainLooper())
    private val netKick = Runnable { fastReconnect() }
    private val stopPi by lazy {
        PendingIntent.getBroadcast(
            this, 20, Intent(BC_STOP).setPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
    private val reconPi by lazy {
        PendingIntent.getBroadcast(
            this, 10, Intent(BC_RECONNECT).setPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
    private val openPi by lazy {
        PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private val actRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                BC_RECONNECT -> requestHardReset()
                BC_STOP -> shutdown()
            }
        }
    }
    private var rxReg = false

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        hud = Hud(this)
        regNet()
        try {
            val f = IntentFilter().apply { addAction(BC_RECONNECT); addAction(BC_STOP) }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(actRx, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(actRx, f)
            rxReg = true
        } catch (e: Exception) { }
    }

    private fun requestHardReset() {
        val cfg = lastCfg
        if (cfg != null && Bus.status.value != St.IDLE) {
            Thread { performHardReset(cfg) }.also { it.isDaemon = true; it.start() }
        }
    }

    private fun fastReconnect() {
        if (worker?.isAlive == true && Bus.status.value != St.IDLE) {
            Bus.log("Jaringan berubah, sambung ulang cepat")
            kick = true
            try { link?.close() } catch (e: Exception) { }
        }
    }

    private fun regNet() {
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (!netSeen) { netSeen = true; return }
                    netH.removeCallbacks(netKick)
                    netH.postDelayed(netKick, 400)
                }
                override fun onLost(network: Network) {
                    netH.removeCallbacks(netKick)
                    netH.postDelayed(netKick, 400)
                }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
        } catch (e: Exception) { }
    }

    private fun unregNet() {
        netH.removeCallbacks(netKick)
        try { netCb?.let { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } } catch (e: Exception) { }
        netCb = null
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACT_START) {
            fg("Menghubungkan…")
            val cfg = try {
                Config.fromJson(JSONObject(i?.getStringExtra(EXTRA) ?: ""))
            } catch (e: Exception) {
                null
            }
            if (cfg == null) {
                Bus.log("Config tidak valid")
                shutdown()
            } else if (worker?.isAlive != true) {
                cfgName = cfg.name.ifBlank { "AlfyTunnel" }
                lastCfg = cfg
                val g = ++gen
                worker = Thread { run(cfg, g) }.also { it.start() }
            }
        } else if (i?.action == ACT_RECONNECT) {
            requestHardReset()
        } else if (i == null) {
            // Restart oleh sistem (START_STICKY): wajib startForeground lagi, lalu lanjutkan config terakhir
            fg("Menghubungkan…")
            val cfg = lastCfg
            if (cfg != null && worker?.isAlive != true) {
                val g = ++gen
                worker = Thread { run(cfg, g) }.also { it.start() }
            } else if (cfg == null) {
                shutdown()
            }
        } else {
            shutdown()
        }
        return START_STICKY
    }

    // HARD RESET: bersihkan total worker, TUN, Stack, Link lalu mulai ulang. Layanan tetap hidup.
    // Wajib dipanggil dari thread background (ada Thread.sleep).
    private fun performHardReset(cfg: Config) {
        synchronized(reconLock) {
            Bus.log("Hard reset koneksi")
            netH.post { try { android.widget.Toast.makeText(applicationContext, "Menyambung ulang…", android.widget.Toast.LENGTH_SHORT).show() } catch (e: Exception) { } }
            try { note("Menyambung ulang…") } catch (e: Exception) { }
            // Naikkan gen dulu agar worker lama tidak memanggil shutdown() saat di-interrupt
            val mine = ++gen
            kick = false
            Bus.status.value = St.RECONNECTING
            val oldWorker = worker
            try { worker?.interrupt() } catch (e: Exception) { }
            try { proxy?.stop() } catch (e: Exception) { }
            proxy = null
            try { tun?.close() } catch (e: Exception) { }
            tun = null
            try { stack?.stop() } catch (e: Exception) { }
            stack = null
            try { link?.close() } catch (e: Exception) { }
            link = null
            try { oldWorker?.join(1500) } catch (e: InterruptedException) { }
            try { Thread.sleep(2000) } catch (e: InterruptedException) { }
            if (gen != mine) return
            // Sisa dari worker lama yang sempat menulis ulang sebelum berhenti
            try { tun?.close() } catch (e: Exception) { }
            tun = null
            try { stack?.stop() } catch (e: Exception) { }
            stack = null
            val g = ++gen
            worker = Thread { run(cfg, g) }.also { it.start() }
        }
    }

    // Active Watchdog: probe lewat tunnel (DNS-over-TCP ke 8.8.8.8:53 via kanal SSH).
    // Ping exec tidak dipakai karena app dikecualikan dari VPN (ping akan lewat jaringan asli, bukan tunnel).
    private fun probeOnce(l: TunnelLink, connMs: Int = 2000, joinMs: Long = 5000): Boolean {
        val ok = java.util.concurrent.atomic.AtomicBoolean(false)
        val ch = arrayOfNulls<SshChan>(1)
        val t = Thread {
            try {
                val c = l.open("8.8.8.8", 53)
                ch[0] = c
                c.connect(connMs)
                val q = byteArrayOf(
                    0, 29, 0x12, 0x34, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0,
                    6, 'g'.code.toByte(), 'o'.code.toByte(), 'o'.code.toByte(), 'g'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(),
                    3, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(), 0, 0, 1, 0, 1
                )
                c.outputStream.write(q)
                c.outputStream.flush()
                val b = ByteArray(4)
                if (c.inputStream.read(b, 0, 4) > 0) ok.set(true)
            } catch (e: Throwable) {
            }
        }.also { it.isDaemon = true; it.start() }
        try { t.join(joinMs) } catch (e: InterruptedException) { }
        try { ch[0]?.disconnect() } catch (e: Exception) { }
        return ok.get()
    }

    private fun startWatchdog(l: TunnelLink, g: Int) {
        if (wdGen == g) return
        wdGen = g
        Thread {
            var fails = 0
            var streak = wdStreak
            var lastRecon = wdLast
            try {
                while (gen == g) {
                    Thread.sleep(6000)
                    if (gen != g) break
                    if (Bus.status.value != St.CONNECTED || !l.alive) { fails = 0; continue }
                    if (probeOnce(l)) {
                        fails = 0
                    } else {
                        fails++
                        Bus.log("Watchdog: probe gagal ($fails/2)")
                        if (fails >= 2) {
                            // Pengaman 1: probe tambahan dengan timeout longgar (anti false-positive)
                            if (gen != g) break
                            if (probeOnce(l, 10000, 10000)) {
                                Bus.log("Watchdog: probe tambahan berhasil, batal sambung ulang")
                                fails = 0
                                continue
                            }
                            if (gen != g || Bus.status.value != St.CONNECTED || !l.alive) { fails = 0; continue }
                            Bus.log("Watchdog: koneksi mati, paksa sambung ulang")
                            fails = 0
                            // Pengaman 2: anti reconnect-loop (exponential backoff)
                            val now = System.currentTimeMillis()
                            streak = if (lastRecon != 0L && now - lastRecon < 60000) streak + 1 else 1
                            lastRecon = now
                            wdStreak = streak
                            wdLast = now
                            if (streak >= 3) {
                                val back = minOf(120000L, 10000L shl minOf(streak - 3, 4))
                                Bus.log("Watchdog: reconnect beruntun ($streak), jeda ${back / 1000} detik")
                                var w = 0L
                                while (w < back && gen == g) { Thread.sleep(1000); w += 1000 }
                            }
                            if (gen != g) break
                            val cfg = lastCfg
                            if (cfg != null) performHardReset(cfg)
                            break
                        }
                    }
                }
            } catch (e: InterruptedException) {
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun run(cfg: Config, g: Int) {
        Bus.status.value = St.CONNECTING
        Bus.muted = false
        startLog()
        val l: TunnelLink = if (cfg.useSlowDns) {
            Bus.log("Jalur SlowDNS (DNS tunneling) aktif, NS=${cfg.dnsNs.trim()}")
            SlowDnsLink(this, cfg)
        } else {
            SshLink(this, cfg)
        }
        link = l
        var attempt = 0
        try {
            while (gen == g) {
                try {
                    l.connect()
                    if (gen != g) break
                    val existing = stack
                    if (tun == null || existing == null) {
                        val t = build(cfg) ?: throw IOException("Gagal membuat antarmuka VPN (izin dicabut?)")
                        if (gen != g) { try { t.close() } catch (e: Exception) { }; break }
                        tun = t
                        val s = TunStack(FileInputStream(t.fileDescriptor), FileOutputStream(t.fileDescriptor), l)
                        stack = s
                        Thread { s.loop() }.also { it.isDaemon = true }.start()
                    }
                    if (Prefs.hotspot.value && Prefs.hotspotMode.value == 1 && proxy == null) {
                        proxy = HttpProxyServer(l).also { it.start() }
                    }
                    Bus.status.value = St.CONNECTED
                    attempt = 0
                    note("Terhubung")
                    Bus.log("Connected")
                    hud?.start()
                    startWatchdog(l, g)
                    while (gen == g && l.alive) Thread.sleep(1500)
                    if (gen == g) Bus.log("Koneksi SSH terputus")
                } catch (e: InterruptedException) {
                    break
                } catch (e: Throwable) {
                    Bus.log("Gagal: ${e.message ?: e.javaClass.simpleName}")
                }
                l.close()
                if (gen != g) break
                stack?.reset()
                attempt++
                Bus.status.value = St.RECONNECTING
                note("Menyambung ulang…")
                val w = minOf(30, attempt * 3)
                Bus.log("Coba lagi dalam $w detik (percobaan $attempt)")
                for (k in 0 until w * 2) {
                    if (gen != g) break
                    if (kick) { kick = false; break }
                    Thread.sleep(500)
                }
            }
        } catch (e: InterruptedException) {
        }
        if (gen == g) shutdown()
    }

    private fun build(cfg: Config): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("AlfyTunnel")
            .setMtu(1500)
            .setBlocking(true)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
        if (Prefs.hotspot.value && Prefs.hotspotMode.value == 0) {
            // Subnet klien hotspot/USB tethering diarahkan ke TUN agar paket klien masuk TunStack
            for (net in listOf("192.168.42.0", "192.168.43.0", "192.168.49.0")) {
                try { b.addRoute(net, 24) } catch (e: Exception) { }
            }
            Bus.log("Hotspot sharing aktif (rute 192.168.42/43/49.x)")
        }
        if (cfg.dnsOn) {
            b.addDnsServer(cfg.dns1.trim())
            if (cfg.dns2.isNotBlank()) b.addDnsServer(cfg.dns2.trim())
        }
        try {
            b.addDisallowedApplication(packageName)
        } catch (e: Exception) {
        }
        return b.establish()
    }

    @Synchronized
    private fun shutdown() {
        gen++
        worker?.interrupt()
        try { link?.close() } catch (e: Exception) { }
        link = null
        hud?.stop()
        try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) { }
        wl = null
        lastSig = ""
        try { proxy?.stop() } catch (e: Exception) { }
        proxy = null
        stack?.stop()
        stack = null
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        if (Bus.status.value != St.IDLE) Bus.log("Terputus")
        Bus.status.value = St.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        shutdown()
    }

    override fun onDestroy() {
        unregNet()
        if (rxReg) { try { unregisterReceiver(actRx) } catch (e: Exception) { }; rxReg = false }
        if (Bus.status.value != St.IDLE) shutdown()
        super.onDestroy()
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            if (!chMade) {
                nm.createNotificationChannel(NotificationChannel(CH, "Status VPN", NotificationManager.IMPORTANCE_LOW))
                chMade = true
            }
            b = Notification.Builder(this, CH)
        } else {
            b = Notification.Builder(this)
        }
        val (d, w, m) = Usage.totals()
        val sp = Prefs.notifSpeed.value
        val on = Prefs.notifOn.value
        val now = System.currentTimeMillis()
        fun cs(t: String, base: Int): CharSequence = if (on) rainbowText(t, sp, now, IntArray(0), base) else t
        val l1 = cs(Mon.infoLine(), 0)
        val l3 = cs("Data hari ini: ${Usage.fmtBytes(d)}", 8)
        val l4 = cs("Minggu ini: ${Usage.fmtBytes(w)} \u2022 Bulan ini: ${Usage.fmtBytes(m)}", 8)
        val title = cs(cfgName, 0)
        val act = cs("PUTUS", 0)
        lastSig = sigNow()
        // Android 12+ membuang span warna di notifikasi standar; view kustom mempertahankannya
        val rv = RemoteViews(packageName, R.layout.notif)
        rv.setTextViewText(R.id.n_speed, title)
        rv.setTextViewText(R.id.n_info, l1)
        rv.setTextViewText(R.id.n_usage, l3)
        rv.setTextViewText(R.id.n_week, l4)
        val rs = RemoteViews(packageName, R.layout.notif_small)
        rs.setTextViewText(R.id.n_speed, title)
        rs.setTextViewText(R.id.n_info, l1)
        rs.setTextViewText(R.id.n_usage, l3)
        return b.setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(l1)
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(rs)
            .setCustomBigContentView(rv)
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_refresh), "Sambung Ulang", reconPi).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), act, stopPi).build())
            .build()
    }

    private fun sigNow(): String {
        val (d, w, m) = Usage.totals()
        val tk = if (Prefs.notifAnim()) System.currentTimeMillis() / 400 else 0L
        return "$cfgName|$baseInfo|$d|$w|$m|${Mon.infoLine()}|${Prefs.notifOn.value}|${Prefs.notifSpeed.value}|$tk"
    }

    fun refreshNotif() {
        try {
            if (lastSig == sigNow()) return
            getSystemService(NotificationManager::class.java).notify(NID, notif())
        } catch (e: Exception) { }
    }

    private fun startLog() {
        var vn = "-"
        var vc = 0L
        try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            vn = pi.versionName ?: "-"
            vc = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        } catch (e: Exception) {
        }
        Bus.log(
            "Running on ${Build.MANUFACTURER.lowercase()} ${Build.MODEL} (${Build.HARDWARE}), Android ${Build.VERSION.RELEASE} " +
                "(${Build.ID}) API ${Build.VERSION.SDK_INT}. Version $vn Build $vc."
        )
        try {
            val w = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlfyTunnel:tunnel")
            w.setReferenceCounted(false)
            w.acquire()
            wl = w
            Bus.log("Wakelock acquired")
        } catch (e: Exception) { }
        Bus.log("Local ip, " + localIp())
    }

    private fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback || ni.name.startsWith("tun")) continue
                for (a in ni.inetAddresses.toList()) if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress ?: "-"
            }
        } catch (e: Exception) { }
        return "-"
    }

    private fun fg(t: String) {
        baseInfo = t
        val n = notif()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(NID, n)
        }
    }

    private fun note(t: String) {
        baseInfo = t
        getSystemService(NotificationManager::class.java).notify(NID, notif())
    }
}
