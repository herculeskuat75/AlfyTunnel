package com.alfy.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.widget.RemoteViews
import java.net.Inet4Address
import java.net.NetworkInterface
import org.json.JSONObject
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class VpnSvc : VpnService() {
    companion object {
        const val ACT_START = "com.alfy.tunnel.START"
        const val ACT_STOP = "com.alfy.tunnel.STOP"
        const val EXTRA = "cfg"
        private const val CH = "alfy_status"
        private const val NID = 1
    }

    @Volatile private var gen = 0
    private var worker: Thread? = null
    private var tun: ParcelFileDescriptor? = null
    private var link: SshLink? = null
    private var stack: TunStack? = null
    private var hud: Hud? = null
    private var wl: PowerManager.WakeLock? = null
    @Volatile private var baseInfo = "Menghubungkan…"
    @Volatile private var cfgName = "AlfyTunnel"
    @Volatile private var lastSig = ""
    private var chMade = false
    private val stopPi by lazy {
        PendingIntent.getService(
            this, 0, Intent(this, VpnSvc::class.java).setAction(ACT_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
    private val openPi by lazy {
        PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    }

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        hud = Hud(this)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACT_START) {
            fg("Menghubungkan…")
            val cfg = try {
                Config.fromJson(JSONObject(i?.getStringExtra(EXTRA) ?: ""))
            } catch (e: Exception) {
                null
            }
            if (cfg == null) {
                Bus.log("Config tidak valid")
                shutdown()
            } else if (worker?.isAlive != true) {
                cfgName = cfg.name.ifBlank { "AlfyTunnel" }
                val g = ++gen
                worker = Thread { run(cfg, g) }.also { it.start() }
            }
        } else {
            shutdown()
        }
        return START_NOT_STICKY
    }

    private fun run(cfg: Config, g: Int) {
        Bus.status.value = St.CONNECTING
        Bus.muted = false
        startLog()
        val l = SshLink(this, cfg)
        link = l
        var attempt = 0
        try {
            while (gen == g) {
                try {
                    l.connect()
                    if (gen != g) break
                    val existing = stack
                    if (tun == null || existing == null) {
                        val t = build(cfg) ?: throw IOException("Gagal membuat antarmuka VPN (izin dicabut?)")
                        tun = t
                        val s = TunStack(FileInputStream(t.fileDescriptor), FileOutputStream(t.fileDescriptor), l)
                        stack = s
                        Thread { s.loop() }.also { it.isDaemon = true }.start()
                    }
                    Bus.status.value = St.CONNECTED
                    attempt = 0
                    note("Terhubung")
                    Bus.log("Connected")
                    hud?.start()
                    while (gen == g && l.alive) Thread.sleep(1500)
                    if (gen == g) Bus.log("Koneksi SSH terputus")
                } catch (e: InterruptedException) {
                    break
                } catch (e: Throwable) {
                    Bus.log("Gagal: ${e.message ?: e.javaClass.simpleName}")
                }
                l.close()
                if (gen != g) break
                stack?.reset()
                attempt++
                Bus.status.value = St.RECONNECTING
                note("Menyambung ulang…")
                val w = minOf(30, attempt * 3)
                Bus.log("Coba lagi dalam $w detik (percobaan $attempt)")
                for (k in 0 until w * 2) {
                    if (gen != g) break
                    Thread.sleep(500)
                }
            }
        } catch (e: InterruptedException) {
        }
        if (gen == g) shutdown()
    }

    private fun build(cfg: Config): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("AlfyTunnel")
            .setMtu(1500)
            .setBlocking(true)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
        if (cfg.dnsOn) {
            b.addDnsServer(cfg.dns1.trim())
            if (cfg.dns2.isNotBlank()) b.addDnsServer(cfg.dns2.trim())
        }
        try {
            b.addDisallowedApplication(packageName)
        } catch (e: Exception) {
        }
        return b.establish()
    }

    @Synchronized
    private fun shutdown() {
        gen++
        worker?.interrupt()
        try { link?.close() } catch (e: Exception) { }
        link = null
        hud?.stop()
        try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) { }
        wl = null
        lastSig = ""
        stack?.stop()
        stack = null
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        if (Bus.status.value != St.IDLE) Bus.log("Terputus")
        Bus.status.value = St.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        shutdown()
    }

    override fun onDestroy() {
        if (Bus.status.value != St.IDLE) shutdown()
        super.onDestroy()
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            if (!chMade) {
                nm.createNotificationChannel(NotificationChannel(CH, "Status VPN", NotificationManager.IMPORTANCE_LOW))
                chMade = true
            }
            b = Notification.Builder(this, CH)
        } else {
            b = Notification.Builder(this)
        }
        val (d, w, m) = Usage.totals()
        val dbmT = Mon.dbmText(Mon.dbm.value)
        val l1 = rainbowText("Hari ini ${Usage.fmtBytes(d)} · $dbmT", 3f, 0L, IntArray(0), 0)
        val l2 = rainbowText("Minggu ini ${Usage.fmtBytes(w)} · Bulan ini ${Usage.fmtBytes(m)}", 3f, 0L, IntArray(0), 8)
        val big = android.text.SpannableStringBuilder().append(l1).append("\n").append(l2)
        val title = rainbowText(cfgName, 3f, 0L, IntArray(0), 0)
        lastSig = "$cfgName|$baseInfo|$d|$w|$m|$dbmT"
        return b.setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(l1)
            .setSubText(baseInfo)
            .setStyle(Notification.BigTextStyle().bigText(big))
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "PUTUS", stopPi).build())
            .build()
    }

    fun refreshNotif() {
        try {
            val (d, w, m) = Usage.totals()
            if (lastSig == "$cfgName|$baseInfo|$d|$w|$m|${Mon.dbmText(Mon.dbm.value)}") return
            getSystemService(NotificationManager::class.java).notify(NID, notif())
        } catch (e: Exception) { }
    }

    private fun startLog() {
        var vn = "-"
        var vc = 0L
        try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            vn = pi.versionName ?: "-"
            vc = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        } catch (e: Exception) {
        }
        Bus.log(
            "Running on ${Build.MANUFACTURER.lowercase()} ${Build.MODEL} (${Build.HARDWARE}), Android ${Build.VERSION.RELEASE} " +
                "(${Build.ID}) API ${Build.VERSION.SDK_INT}. Version $vn Build $vc."
        )
        try {
            val w = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlfyTunnel:tunnel")
            w.setReferenceCounted(false)
            w.acquire()
            wl = w
            Bus.log("Wakelock acquired")
        } catch (e: Exception) { }
        Bus.log("Local ip, " + localIp())
    }

    private fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback || ni.name.startsWith("tun")) continue
                for (a in ni.inetAddresses.toList()) if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress ?: "-"
            }
        } catch (e: Exception) { }
        return "-"
    }

    private fun fg(t: String) {
        baseInfo = t
        val n = notif()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(NID, n)
        }
    }

    private fun note(t: String) {
        baseInfo = t
        getSystemService(NotificationManager::class.java).notify(NID, notif())
    }
}
